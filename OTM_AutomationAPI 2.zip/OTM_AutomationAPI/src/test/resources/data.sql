INSERT INTO userauthentication (userid , role,emailid, module) VALUES
  ('ADMIN1000', 'Approver', 'ULF.ABD', 'creation,cancellation,modification'),
  ('Deja', 'Vu', 'xyz@email.com', 'creation,cancellation,modification'),
  ('Caption', 'America', 'cap@marvel.com', 'creation,cancellation,modification');
  
 INSERT INTO USER_DETAILS (USERID , DEPOT_ID,SHIPMENT_TYPE, DETAILS_ID) VALUES
  ('ADMIN1000', 'ULF.CHK','POB', 1);
  
  INSERT INTO SHIPMENT_REQUEST_CREATION(REQUEST_NUMBER,USERNAME ) VALUES
  ('090620200243','ADMIN1000');