package com.unilever.otmbulkautomation;

import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.unilever.otmbulkautomation.controller.AuthenticationController;
import com.unilever.otmbulkautomation.model.AuthenticationRequest;

@SpringBootTest
public class OtmBulkAutomationApplicationTests {

	@Autowired
	AuthenticationController authenticationController;

	public String token;

	@BeforeEach
	public void testUserAuthentication() {
		AuthenticationRequest authenticationRequest = new AuthenticationRequest();
		authenticationRequest.setSecretId("OTMBulkAutomationID");
		authenticationRequest.setSecretKey("OTMBulkAutomationKoderSecretKey");
		authenticationRequest.setUsername("ADMIN1000");
		ResponseEntity<Map<Object, Object>> signin = authenticationController.signin(authenticationRequest);
		token = "Bearer " + signin.getBody().get("token");
	}
}
