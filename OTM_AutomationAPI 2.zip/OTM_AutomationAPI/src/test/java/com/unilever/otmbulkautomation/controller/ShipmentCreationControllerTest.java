package com.unilever.otmbulkautomation.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.service.OTMService;
import com.unilever.otmbulkautomation.service.ShipmentCreationService;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;

public class ShipmentCreationControllerTest extends OtmBulkAutomationApplicationTests {

	@Autowired
	ShipmentCreationController shipmentCreationController;
	
	@Mock
	DBServletRestUtil restUtil;
	
	@Autowired
	DBServletRestUtil dBServletRestUtil;
	
	@Mock
	RestTemplate restTemplate;
	
	@Autowired
	ShipmentCreationService shipmentCreationService;
	
	@Autowired
	ShipmentCreationFacade shipmentCreationServiceFacade;
	
	@Autowired
	OTMService oTMService;
	
	@Mock
	private ShipmentCreationRequestRepository repository;

	
	@Test
	public void testShipmentCreationControllerWithType() throws Exception {
		getMocks();
		ResponseEntity<Object> orderRelsese = shipmentCreationController.createShipment(new HashSet<String>() {{add("ULF.CHK");}}, getCreationMetaData());
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}
	
	@Test
	public void testShipmentCreationControllerWithOutType() throws Exception {
		getMocks();
		OrderReleasesSchemaWrapper creationMetaData = getCreationMetaData();
		creationMetaData.setOrderReleaseType(null);
		ResponseEntity<Object> orderRelsese = shipmentCreationController.createShipment(new HashSet<String>() {{add("ULF.CHK");}},creationMetaData);
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}		

	@Test
	public void testShipmentCreationControllerWithError() throws Exception {
		getMocks();
		OrderReleasesSchemaWrapper creationMetaData = getCreationMetaData();
		when(restUtil.postInsertQueryToDBServlet(any(String.class),any(String.class))).thenReturn("");
		ResponseEntity<Object> orderRelsese = shipmentCreationController.createShipment(new HashSet<String>() {{add("ULF.CHK");}}, creationMetaData);
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}
	
	@Test
	public void testShipmentCreationControllerWithInsertionError() throws Exception {
		ReflectionTestUtils.setField(dBServletRestUtil, "restTemplate", restTemplate);
		ReflectionTestUtils.setField(shipmentCreationService, "repository", repository);
		ReflectionTestUtils.setField(shipmentCreationServiceFacade, "restUtil", dBServletRestUtil);
		ReflectionTestUtils.setField(shipmentCreationServiceFacade, "repository", repository);
		when(repository.getShipmentRequestValue()).thenReturn(1l);

		ResponseEntity<String> responseEntity = new ResponseEntity<String>("<dbxml:xml2sql xmlns:dbxml=\"http://xmlns.oracle.com/apps/otm/DBXML\"><SuccessCount>1</SuccessCount><ErrorCount>0</ErrorCount><ElapsedTime>5</ElapsedTime><TimePerTransaction>5</TimePerTransaction></dbxml:xml2sql>", HttpStatus.OK);
		when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		
		ResponseEntity<Object> orderRelsese = shipmentCreationController.createShipment(new HashSet<String>() {{add("ULF.CHK");}}, getCreationMetaData());
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}
	
	private OrderReleasesSchemaWrapper getCreationMetaData(){
		User user = new User();
		user.setUsername("ADMIN1000");
		SecurityContextImpl context = new SecurityContextImpl();
		context.setAuthentication(new UsernamePasswordAuthenticationToken(user, "", null));
		SecurityContextHolder.setContext(context);
		
		OrderReleasesSchemaWrapper orderReleasesSchemaWrapper = new OrderReleasesSchemaWrapper();
		orderReleasesSchemaWrapper.setOrderReleaseType(OTMConstants.SECONDARY_OUTBOUND_DELIVERY);
		OrderReleases orderReleases = new OrderReleases();
		orderReleases.setAttribute1("");
		orderReleases.setCity("");
		orderReleases.setCluster("");
		orderReleases.setDestinationLocationGID("");
		orderReleases.setDestinationLocationName("");
		orderReleases.setEarlyPickupDate("");
		orderReleases.setLateDeliveryDate("");
		orderReleases.setLatePickupDate("");
		orderReleases.setMaterialGroup("");
		orderReleases.setMaxServiceTime("");
		orderReleases.setRemark("");
		orderReleases.setShipWithGroup("");
		orderReleases.setSourceLocationGID("");
		orderReleases.setSourceLocationName("");
		orderReleases.setStatusTypeGID("");
		orderReleases.setStatusValueGID("");
		orderReleases.setTotalDeclaredValue("");
		orderReleases.setTotalDeclaredValueGID("");
		orderReleases.setTotalVolume("");
		orderReleases.setTotalWeight("");
		orderReleases.setTotalVolumeUOMCode("");
		orderReleases.setTotalWeightUOMCode("");
		orderReleases.setOrderReleaseGID("ULF.65800097198");
		orderReleases.setCrRequestId("ULF.65800097198");
		orderReleases.setLocationAttribute1("CD");
		orderReleases.setSelectable(true);
		orderReleases.setRemarks(new ArrayList());
		orderReleasesSchemaWrapper.setOrderReleases(new ArrayList(){{add(orderReleases);}});
		orderReleases.setOrderReleaseTypeGID(OTMConstants.SECONDARY_OUTBOUND_DELIVERY);
		return orderReleasesSchemaWrapper;
	}
	
	private void getMocks() {
		ReflectionTestUtils.setField(oTMService, "restUtil", restUtil);
		ReflectionTestUtils.setField(shipmentCreationService, "repository", repository);
		ReflectionTestUtils.setField(shipmentCreationServiceFacade, "restUtil", restUtil);
		ReflectionTestUtils.setField(shipmentCreationServiceFacade, "repository", repository);
		ReflectionTestUtils.setField(dBServletRestUtil, "restTemplate", restTemplate);
		String respost = "1";
		String resget = new String("http://xmlns.oracle.com/apps/otm/DBXML\" Version=\"20B\"><dbxml:TRANSACTION_SET><LOCATION_REFNUM LOCATION_REFNUM_VALUE=\"0000-0000\"/></dbxml:TRANSACTION_SET></dbxml:xml2sql>");

		String maxget = "<dbxml:xml2sql xmlns:dbxml=\"http://xmlns.oracle.com/apps/otm/DBXML\" Version=\"20B\"><dbxml:TRANSACTION_SET><PROCESS_CONTROL_REQUEST PROCESS_CONTROL_REQUEST_ID=\"418914\"/></dbxml:TRANSACTION_SET></dbxml:xml2sql>";
		when(restUtil.postGetQueryToDBServlet(Matchers.contains("PROCESS_CONTROL_REQUEST"),any(String.class))).thenReturn(maxget);

		when(restUtil.postGetQueryToDBServlet(Matchers.contains("LOCATION_REFNUM"),any(String.class))).thenReturn(resget);
		when(restUtil.postInsertQueryToDBServlet(any(String.class),any(String.class))).thenReturn(respost);

		when(repository.getShipmentRequestValue()).thenReturn(1l);
	}
	
	


}
