package com.unilever.otmbulkautomation.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;

public class OrderReleaseControllerTest extends OtmBulkAutomationApplicationTests {

	@Autowired
	OrderReleaseController orderReleaseController;
	
	@Autowired
	DBServletRestUtil dBServletRestUtil;
	
	@Mock
	RestTemplate restTemplate;

	
	@Test
	public void testOrderReleaseControllerWithNoResult() throws Exception {
		ReflectionTestUtils.setField(dBServletRestUtil, "restTemplate", restTemplate);
		ResponseEntity<String> responseEntity = new ResponseEntity<String>("", HttpStatus.OK);
		when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		ResponseEntity<Object> orderRelsese = orderReleaseController.getOrderRelsese(new HashSet<String>(),
				OTMConstants.SECONDARY_OUTBOUND_DELIVERY, new ArrayList<String>());
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}
	
	@Test
	public void testOrderReleaseControllerWithResult() throws Exception {
		ReflectionTestUtils.setField(dBServletRestUtil, "restTemplate", restTemplate);
		ResponseEntity<String> responseEntity = new ResponseEntity<String>("<dbxml:xml2sql xmlns:dbxml=\"http://xmlns.oracle.com/apps/otm/DBXML\" Version=\"20B\"><dbxml:TRANSACTION_SET><ORDER_RELEASE ORDER_RELEASE_GID=\"ULF.5799635727\" ORDER_RELEASE_TYPE_GID=\"ULF.SECONDARY_OUTBOUND_DELIVERY\" STATUS_TYPE_GID=\"ULF.PLANNING\" EARLY_PICKUP_DATE=\"2020-05-31 18:30:01.0\" LATE_PICKUP_DATE=\"2020-06-02 18:29:59.0\" LATE_DELIVERY_DATE=\"2020-06-03 18:29:59.0\" STATUS_VALUE_GID=\"ULF.PLANNING_NEW\" SOURCE_LOCATION_GID=\"ULF.CHK\" SOURCE_LOCATION_NAME=\"CHIKKABALLAPUR\" DEST_LOCATION_GID=\"ULF.430811\" DESTINATION_LOCATION_NAME=\"METRO C&amp;C INDIA PVT LTD\" LOCATION_ATTRIBUTE1=\"01\" CITY=\"K010\" SHIP_WITH_GROUP=\"TESTMTAPPMOCK002\" ATTRIBUTE1=\"P\" TOTAL_WEIGHT=\"580.008000000000038198777474462985992431\" TOTAL_WEIGHT_UOM_CODE=\"GRM\" TOTAL_VOLUME=\"3128.159999999999854480847716331481933593\" TOTAL_VOLUME_UOM_CODE=\"CMQ\" TOTAL_DECLARED_VALUE=\"1838.99000000000000909494701772928237915\" TOTAL_DECLARED_VALUE_GID=\"INR\" MAX_SERVICE_TIME=\"2\" MATERIAL_GROUP1=\"U1 PP\"/></dbxml:TRANSACTION_SET></dbxml:xml2sql>", HttpStatus.OK);
		when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		ResponseEntity<Object> orderRelsese = orderReleaseController.getOrderRelsese(new HashSet<String>(),
				OTMConstants.SECONDARY_OUTBOUND_DELIVERY, new ArrayList<String>());
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));

	}
	
	@Test
	public void testOrderReleaseControllerWithNoData() throws Exception {
		ReflectionTestUtils.setField(dBServletRestUtil, "restTemplate", restTemplate);
		ResponseEntity<String> responseEntity = new ResponseEntity<String>("<dbxml:xml2sql xmlns:dbxml=\"http://xmlns.oracle.com/apps/otm/DBXML\" Version=\"20B\"><dbxml:TRANSACTION_SET>NO DATA</dbxml:TRANSACTION_SET></dbxml:xml2sql>", HttpStatus.OK);
		when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		ResponseEntity<Object> orderRelsese = orderReleaseController.getOrderRelsese(new HashSet<String>(),
				OTMConstants.SECONDARY_OUTBOUND_DELIVERY, new ArrayList<String>());
		 Assertions.assertEquals(true, Objects.nonNull(orderRelsese));
	}



}
