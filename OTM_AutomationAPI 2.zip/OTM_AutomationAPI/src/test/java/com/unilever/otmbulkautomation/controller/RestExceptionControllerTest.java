package com.unilever.otmbulkautomation.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;
import com.unilever.otmbulkautomation.security.InvalidJwtAuthenticationException;

public class RestExceptionControllerTest extends OtmBulkAutomationApplicationTests {

	@Autowired
	RestExceptionHandler restExceptionHandler;
	@Test
	public void testBadCredentialsException() throws Exception{
		restExceptionHandler.badCredentials(new BadCredentialsException(""), null) ;
		restExceptionHandler.invalidJwtAuthentication(new InvalidJwtAuthenticationException(""), null);
		restExceptionHandler.illegalStateException(new IllegalStateException(""), null);
		restExceptionHandler.exception(new Exception(""), null);
	}
}
