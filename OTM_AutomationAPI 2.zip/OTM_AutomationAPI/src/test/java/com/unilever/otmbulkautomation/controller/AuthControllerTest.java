package com.unilever.otmbulkautomation.controller;

import static org.mockito.Mockito.when;

import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;
import com.unilever.otmbulkautomation.model.AuthenticationRequest;
import com.unilever.otmbulkautomation.security.JwtTokenProvider;

public class AuthControllerTest extends OtmBulkAutomationApplicationTests {

	@Autowired
	AuthenticationController authenticationController;
	
	@Autowired
	JwtTokenProvider jwtTokenProvider;
	
	@Mock
	HttpServletRequest request;

	@Test
	public void testUserAuthentication() {
		AuthenticationRequest authenticationRequest = new AuthenticationRequest();
		authenticationRequest.setSecretId("OTMBulkAutomationID");
		authenticationRequest.setSecretKey("OTMBulkAutomationKoderSecretKey");
		authenticationRequest.setUsername("ADMIN1000");
		ResponseEntity<Map<Object, Object>> signin = authenticationController.signin(authenticationRequest);
		Assertions.assertEquals(true, Objects.nonNull(signin));
		when(request.getHeader("Authorization")).thenReturn("Bearer "+signin.getBody().get("token"));
		
		String resolveToken = jwtTokenProvider.resolveToken(request);
		jwtTokenProvider.validateToken(resolveToken);
		Authentication authentication = jwtTokenProvider.getAuthentication(resolveToken);
		Assertions.assertEquals(true, Objects.nonNull(authentication));

	}

	@Test
	public void testUserAuthenticationFailureException() {
		AuthenticationRequest authenticationRequest = new AuthenticationRequest();
		authenticationRequest.setSecretId("");
		authenticationRequest.setSecretKey("");
		authenticationRequest.setUsername("ADMIN1000");
		try {
		authenticationController.signin(authenticationRequest);
		}catch(BadCredentialsException e) {
			Assertions.assertEquals(true, Objects.nonNull(e));
		}
	}

}
