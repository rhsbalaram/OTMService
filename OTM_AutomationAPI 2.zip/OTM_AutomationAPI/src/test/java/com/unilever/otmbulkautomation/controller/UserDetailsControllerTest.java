package com.unilever.otmbulkautomation.controller;

import java.util.Objects;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;
import com.unilever.otmbulkautomation.domain.User;

public class UserDetailsControllerTest extends OtmBulkAutomationApplicationTests{
	@Autowired
	UserDetailsController controller;
	
	@Test
	public void testUserDetails() {
		User user = new User();
		user.setUsername("ADMIN1000");
		SecurityContextImpl context = new SecurityContextImpl();
		context.setAuthentication(new UsernamePasswordAuthenticationToken(user, "", null));
		SecurityContextHolder.setContext(context);
		ResponseEntity<Object> userDetails = controller.getUserDetails(null);
		Assertions.assertEquals(true, Objects.nonNull(userDetails));
	}
}
