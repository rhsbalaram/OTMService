package com.unilever.otmbulkautomation.controller;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.FileCopyUtils;

import com.unilever.otmbulkautomation.OtmBulkAutomationApplicationTests;

public class OTMControllerTest extends OtmBulkAutomationApplicationTests {

	@Autowired
	OTMController OTMController;
	
	@Autowired
	ResourceLoader resourceLoader;
	
	@Test
	public void testOTMResponse() throws IOException {
		OTMController.updateShipmentStatus(new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/OTMResponse.xml").getInputStream())));
	}
}
