package com.unilever.otmbulkautomation.schema;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SAVED_QUERY")
public class SavedQuery
{
	@JacksonXmlProperty(isAttribute = true, localName = "SAVED_QUERY_GID")
    private String savedQueryGID;
	@JacksonXmlProperty(isAttribute = true, localName = "USE_IN_FINDER")
    private String useInFinder;
	@JacksonXmlProperty(isAttribute = true, localName = "IS_HIDDEN_FOR_MILESTONES")
    private String isHiddenForMilestones;
	@JacksonXmlProperty(isAttribute = true, localName = "SAVED_QUERY_XID")
    private String saveQueryXID;
	@JacksonXmlProperty(isAttribute = true, localName = "QUERY_NAME")
    private String queryName;
	@JacksonXmlProperty(isAttribute = true, localName = "IS_CONDITION")
    private String isCondition;
	@JacksonXmlProperty(isAttribute = true, localName = "SQL_FIND_ALL")
    private String sqlFindAll;
	@JacksonXmlProperty(isAttribute = true, localName = "USER_QUERY_NAME")
    private String userQueryName;
	@JacksonXmlProperty(isAttribute = true, localName = "SQL_CHECK_ONE")
    private String sqlCheckOne;
	@JacksonXmlProperty(isAttribute = true, localName = "DOMAIN_NAME")
    private String domainName;
}