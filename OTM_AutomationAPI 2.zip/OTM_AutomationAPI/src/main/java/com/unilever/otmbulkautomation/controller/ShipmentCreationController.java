package com.unilever.otmbulkautomation.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.service.ShipmentCreationService;
import com.unilever.otmbulkautomation.service.ShipmentRequestService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/user")
@Log4j2
public class ShipmentCreationController {

	@Autowired
	ShipmentCreationService shipmentCreationService;
	
	@Autowired
	ShipmentRequestService shipmentRequestService;
	
	@Autowired
	UserRepository users;

	@PostMapping(value = "/shipment")
	public ResponseEntity createShipment(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestBody OrderReleasesSchemaWrapper orderReleasesSchema) {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		ShipmentCreationRequest createShipment = shipmentCreationService.createShipment(username, sourceLocation, orderReleasesSchema);
		return new ResponseEntity<>(createShipment, HttpStatus.CREATED);
	}
	
	@GetMapping(value = "/shipment")
	public ResponseEntity getShipments(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("shipment") String shipment, @RequestParam("shipmentType") String shipmentType, @RequestParam("requestDate") String requestDate,  @RequestParam("requestId") String requestId) {
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		List<ShipmentCreationRequest> createdShipments = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Creation");
		List<ShipmentCreationRequest> createdShipments2 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Bulk Creation");
		createdShipments.addAll(createdShipments2);
		return new ResponseEntity<>(createdShipments, HttpStatus.OK);
	}
	
	@GetMapping(value = "/shipment/detail")
	public ResponseEntity getShipmentdetails(@RequestParam("requestId") String requestId) {
		SchemaWrapper shipmentDetailsFromOtm = shipmentRequestService.getShipmentDetailsFromOtm(requestId);
		return new ResponseEntity<>(shipmentDetailsFromOtm, HttpStatus.OK);
	}
}
