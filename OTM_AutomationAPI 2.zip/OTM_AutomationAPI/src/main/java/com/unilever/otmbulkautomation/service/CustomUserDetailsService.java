package com.unilever.otmbulkautomation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.domain.UserDetail;
import com.unilever.otmbulkautomation.repository.UserDetailRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.security.JwtProperties;

@Component
public class CustomUserDetailsService implements UserDetailsService {

	private UserRepository users;

	@Autowired
	UserDetailRepository depot;

	@Autowired
	private JwtProperties properties;

	public CustomUserDetailsService(UserRepository users) {
		this.users = users;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> findByUsername = this.users.findByUsername(username);
		if (findByUsername.isPresent()) {
			User user = findByUsername.get();
			user.setPassword(properties.getSecretId() + properties.getSecretKey());
			return user;
		} else
			throw new UsernameNotFoundException("Username: " + username + " not found");
	}

	public void importAuthData(List<User> users) {
		this.users.saveAll(users);
	}

	public void importDepotData(List<UserDetail> depots) {
		depot.saveAll(depots);
	}
}
