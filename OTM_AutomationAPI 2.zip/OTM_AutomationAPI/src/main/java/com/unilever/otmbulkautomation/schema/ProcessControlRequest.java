package com.unilever.otmbulkautomation.schema;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "PROCESS_CONTROL_REQUEST")
public class ProcessControlRequest
{	@JacksonXmlProperty(isAttribute = true, localName = "PROCESS_CONTROL_REQUEST_ID")
    private String processControlRequestId;
	@JacksonXmlProperty(isAttribute = true, localName = "TOPIC_PARAMETERS")
    private String topicParameters;
	@JacksonXmlProperty(isAttribute = true, localName = "TOPIC_ALIAS_GID")
    private String topicAliasGid;
	@JacksonXmlProperty(isAttribute = true, localName = "DOMAIN_NAME")
    private String domainName;
	@JacksonXmlProperty(isAttribute = true, localName = "NEXT_PROCESS_TIME")
    private String nextProcessTime;
}