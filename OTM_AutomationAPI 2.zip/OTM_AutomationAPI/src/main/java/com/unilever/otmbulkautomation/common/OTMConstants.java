package com.unilever.otmbulkautomation.common;

public class OTMConstants {

	public static final String SECONDARY_OUTBOUND_DELIVERY = "ULF.SECONDARY_OUTBOUND_DELIVERY";
	public static final String PRIMARY_OUTBOUND_DELIVERY = "ULF.PRIMARY_OUTBOUND_DELIVERY";
	public static final String SECONDARY_DIRECT_DISPATCH_DELIVERY = "ULF.SECONDARY_DIRECT_DISPATCH_DELIVERY";
	public static final String MAX_SERVICE_TIME_REMARK = "Early pick-up date, Max service time is less than Late delivery date.";
	public static final String LATE_PICKUP_DATE_REMARK = "Late pick-up date in not equal to next day of Early pick-up date.";
	public static final String PLANNING_NEW = "ULF.PLANNING_NEW";
	public static final String PLANNING_FAILED = "ULF.PLANNING_PLANNED - FAILED";
	public static final String PLANNING_OUT_OF_DATE = "ULF.PLANNING_ITEM OUT OF DATE";
	public static final String PLANNING_FINAL = "ULF.PLANNING_PLANNED - FINAL";
	public static final String PLANNING_PARTIAL = "ULF.PLANNING_EXECUTED - PARTIAL";
	public static final String PLANNING_UNSCHEDULED = "ULF.PLANNING_UNSCHEDULED";
	public static final String CUSTUMER_TYPE_CD = "CD";
	public static final String CUSTUMER_TYPE_MT = "01";
	public static final String CUSTUMER_TYPE_MT1 = "1";
	public static final String CUSTUMER_TYPE_GT = "GT";
	public static final String BULK_CREATION = "Bulk Creation";
	public static final String SHIPMENT_CREATION_REQUEST_SEQ = "SHIPMENT_CREATION_REQUEST_SEQ";
	public static final String REQUESTER = "Requester";
	public static final String APPROVER = "Approver";
	public static final String APPROVED = "Approved";
	public static final String REJECTED = "Rejected";
	public static final String TENDER_NOCALL = "ULF.TENDER CALL_NO CALL";
	public static final String TENDER_CALL_TENDER = "TENDER CALL_TENDER";
	public static final String TENDER_CALL_CANCEL = "ULF.TENDER CALL_CANCEL";
	public static final String IN_PROGRESS = "In Progress";
	public static final String OPEN = "Open";
	public static final String COMPLETED = "Completed";
	public static final String APPROVAL_PENDING = "Pending for approval";
	public static final String ENROUTE_NOT_STARTED = "ULF.ENROUTE_NOT STARTED";

}
