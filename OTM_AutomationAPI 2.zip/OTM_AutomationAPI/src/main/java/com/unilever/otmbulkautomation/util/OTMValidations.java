package com.unilever.otmbulkautomation.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAssign;
import com.unilever.otmbulkautomation.schema.ShipmentAssignSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentCancellation;
import com.unilever.otmbulkautomation.schema.ShipmentCancellationSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentStop;
import com.unilever.otmbulkautomation.schema.ShipmentStopSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentXlane;
import com.unilever.otmbulkautomation.schema.ShipmentXlaneSchemaWrapper;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class OTMValidations {

	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	ShipmentCreationRequestRepository shipmentCreationRequestRepository;
	
	@Autowired
	ShipmentCreationRequestLogRepository shipmentCreationRequestLogRepository;
	
	@Autowired
	OTMShipmentConstants otmShipmentConstants;

	public void OtmExtractDataValidations(SchemaWrapper dbServletMappedPojo, String orderReleaseTypeGID) {
		log.info("Starting OtmExtractDataValidations");
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<OrderReleases> orderReleases = ((OrderReleasesSchemaWrapper) dbServletMappedPojo).getOrderReleases();
			Set<String> requestIds = new HashSet<>();
			List<OrderReleases> validOrderRelease = orderReleases.stream().filter(orderRelease -> {
				boolean isValid = true;

				if (Objects.nonNull(orderRelease.getEarlyPickupDate())) {
					// Validation a.EARLY_PICKUP_DATE+MAX_SERVICE_TIME <= LATE_DELIVERY_DATE (POB
					// AND DD)
					if (!OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseTypeGID)
							&& Objects.nonNull(orderRelease.getMaxServiceTime())
							&& StringUtils.isNumeric(orderRelease.getMaxServiceTime())
							&& Objects.nonNull(orderRelease.getLateDeliveryDate())) {
						if (!dateUtil.isLessThanOrEqual(orderRelease.getEarlyPickupDate(),
								Integer.valueOf(orderRelease.getMaxServiceTime()),
								orderRelease.getLateDeliveryDate())) {
							orderRelease.getRemarks().add(OTMConstants.MAX_SERVICE_TIME_REMARK);
							isValid = false;
						}
					}
					// Valildation b. LATE_PICKUP_DATE = EARLY_PICKUP_DATE +1
					if (Objects.nonNull(orderRelease.getLatePickupDate()) && !dateUtil
							.isEqual(orderRelease.getEarlyPickupDate(), 1, orderRelease.getLatePickupDate())) {
						orderRelease.getRemarks().add(OTMConstants.LATE_PICKUP_DATE_REMARK);
						isValid = false;
					}
				}
				// Validation c.To Gray our or Selectable
				if (Objects.nonNull(orderRelease.getStatusValueGID())) {
					setShipmentPlanningSelectable(orderRelease);
				}
				if(Objects.nonNull(orderRelease.getCrRequestId())) {
					requestIds.add(orderRelease.getCrRequestId());
				}
				if(Objects.nonNull(orderRelease.getAssRequestId())) {
					requestIds.add(orderRelease.getAssRequestId());
				}
				if(Objects.nonNull(orderRelease.getUnassRequestId())) {
					requestIds.add(orderRelease.getUnassRequestId());
				}
				return isValid;
			}).collect(Collectors.toList());
			if(!CollectionUtils.isEmpty(requestIds)) {
				//handle if requestids are more than 1000
				List<ShipmentCreationRequest> requests = shipmentCreationRequestRepository.findRequestNumberByRequestNumberInAndStatusIn(requestIds, new ArrayList<String>() {{add(OTMConstants.OPEN);add(OTMConstants.IN_PROGRESS);add(OTMConstants.APPROVAL_PENDING);}});
				if (!CollectionUtils.isEmpty(requests)) {
					List<String> reqNums = requests.stream().map(req -> req.getRequestNumber())
							.collect(Collectors.toList());
					validOrderRelease = validOrderRelease.stream().filter(validorder -> {
						if (Objects.nonNull(validorder.getCrRequestId()) && reqNums.contains(validorder.getCrRequestId())) {
							return false;
						}
						if (Objects.nonNull(validorder.getAssRequestId()) && reqNums.contains(validorder.getAssRequestId())) {
							return false;
						}
						if (Objects.nonNull(validorder.getUnassRequestId()) && reqNums.contains(validorder.getUnassRequestId())) {
							return false;
						}
						return true;
					}).collect(Collectors.toList());
				}
				
			}
			((OrderReleasesSchemaWrapper) dbServletMappedPojo).setOrderReleases(validOrderRelease);

		}
		log.info("END OtmExtractDataValidations");
	}

	public void setShipmentPlanningSelectable(OrderReleases orderRelease) {
		switch (orderRelease.getStatusValueGID()) {
		case OTMConstants.PLANNING_NEW:
			if(Objects.nonNull(orderRelease.getCrRequestId())){
				orderRelease.setSelectable(false);
			} else {
				orderRelease.setSelectable(true);
			}
			break;
		case OTMConstants.PLANNING_UNSCHEDULED:
		case OTMConstants.PLANNING_FAILED:
			orderRelease.setSelectable(true);
			break;
		case OTMConstants.PLANNING_FINAL:
			if(Objects.nonNull(orderRelease.getCrRequestId())){
				orderRelease.setSelectable(false);
			} 
			break;
		case OTMConstants.PLANNING_PARTIAL:
			orderRelease.setSelectable(false);
			break;
		default:
			log.warn("Unknow Shipment Planning Type Value : {} ", orderRelease.getStatusValueGID());

		}
	}
	
	
	public void valideShipmentApproval(SchemaWrapper dbServletMappedPojo, String module) {
		
		List<String> moduleList = new ArrayList<>();

		if (StringUtils.containsIgnoreCase(module, "creation")) {
			moduleList.add(otmShipmentConstants.getShipmentCreatePending());
		}
		if (StringUtils.containsIgnoreCase(module, "cancellation")) {
			moduleList.add(otmShipmentConstants.getShipmentCancelPending());

		}
		if (StringUtils.containsIgnoreCase(module, "modification")) {
			moduleList.add(otmShipmentConstants.getShipmentAssignPending());
			moduleList.add(otmShipmentConstants.getShipmentUnassignPending());
			moduleList.add(otmShipmentConstants.getShipmentEquipmentPending());
		}
		
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<ShipmentApproval> validShipments = new ArrayList<>();
			List<ShipmentApproval> shipments = ((ShipmentApprovalSchemaWrapper) dbServletMappedPojo).getShipments();
			Set<String> shipmentids = shipments.stream()
					.filter(sht -> (Objects.nonNull(sht) && Objects.nonNull(sht.getAttribute11())))
					.map(ship -> ship.getAttribute11()).collect(Collectors.toSet());
			List<ShipmentCreationRequest> requestNumbers = shipmentCreationRequestRepository
					.findRequestNumberByRequestNumberInAndNotStatus(shipmentids/*, new ArrayList<String>() {{add(OTMConstants.APPROVED);add(OTMConstants.REJECTED);}}*/);
			List<ShipmentCreationRequestLog> findByRequestNumberIn = shipmentCreationRequestLogRepository.findByRequestNumberIn(shipmentids);
			Map<String,String> shpmtRequest = new HashMap<String,String>();
			Map<String,String> requestLog = new HashMap<String,String>();
			Map<String,String> requestMap = new HashMap<String,String>();

			findByRequestNumberIn.forEach(req ->{
				requestLog.put(req.getRequestNumber(), req.getOrdersNumbers());
			});
			requestNumbers.forEach(shpmtreq -> {
				shpmtRequest.put(shpmtreq.getRequestNumber(), shpmtreq.getReasons());
				requestMap.put(shpmtreq.getRequestNumber(), shpmtreq.getRequestType());
			});
			shipments.forEach(shipment -> {
				if (Objects.nonNull(shipment) && shpmtRequest.containsKey(shipment.getAttribute11()) && Objects.nonNull(shipment.getRefValue())/* && moduleList.contains(shipment.getRefValue())*/) {
					shipment.setReason(shpmtRequest.get(shipment.getAttribute11()));
					if(otmShipmentConstants.getShipmentUnassignPending().equals(shipment.getRefValue()) && requestLog.containsKey(shipment.getAttribute11())){
						String logdata = requestLog.get(shipment.getAttribute11());
						String[] splitdata = logdata.split(",");
						List<String> shipmentordIds = Arrays.asList(splitdata);
						shipmentordIds.forEach(id -> {
							String[] ordship = id.split("-");
							if(ordship.length>2) {
								if(ordship[0].equals(shipment.getShipmentGID())) {
									String[] splitValue = ordship[1].split(":");
									if(splitValue.length>1) {
										shipment.setPlannedWeight(splitValue[0]);
										shipment.setPlannedVolume(splitValue[1]);
									}
								}
							}
						});
					}
					if(otmShipmentConstants.getShipmentEquipmentPending().equals(shipment.getRefValue()) && requestLog.containsKey(shipment.getAttribute11())) {
						String logdata = requestLog.get(shipment.getAttribute11());
						String[] split = logdata.split("-");
						shipment.setRefValue(requestMap.get(shipment.getAttribute11()));
						if(split.length>1) {
							String values = split[1];
							String[] props = values.split(":");
							if(props.length>1) {
								shipment.setPlannedEqup(props[0]);
								shipment.setPlannedServ(props[1]);
							}
						}
					}
					if(otmShipmentConstants.getShipmentAssignPending().equals(shipment.getRefValue()) && requestLog.containsKey(shipment.getAttribute11())) {
						String wght = "";
						 String volume = "";
						 String equp = "";
							String logdata = requestLog.get(shipment.getAttribute11());
						 if(Objects.nonNull(logdata)) {
							 String[] split = logdata.split("-");
							 if(split.length>2) {
								String plannedvalues =  split[2];
								String[] split2 = plannedvalues.split(":");
								if(split2.length>2) {
									wght = split2[0];
									volume = split2[1];
									equp = split2[2];
									if (Objects.nonNull(wght) && NumberUtils.isCreatable(wght)) {
										wght =""+ Float.parseFloat(wght) / 1000000f;
									}
									if (Objects.nonNull(volume) && NumberUtils.isCreatable(volume)) {
										volume =""+ Float.parseFloat(volume) / 1000000f;
									}
								}
							 }
						 }
						 shipment.setPlannedWeight(shipment.getTotalWeight());
						 shipment.setPlannedVolume(shipment.getTotalVolume());
						 shipment.setPlannedEqup(shipment.getFirstEquipmnetGroupGID());
						 shipment.setTotalVolume(volume);
						 shipment.setTotalWeight(wght);
						 shipment.setFirstEquipmnetGroupGID(equp);
					}
					if (OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(shipment.getShipmentType()) && otmShipmentConstants.getShipmentCreatePending().equals(shipment.getRefValue())
							&& dateUtil.isEqualOrGreaterThanCurrent(shipment.getCreatedDate(), 0)) {
						validShipments.add(shipment);
					} else if (dateUtil.isEqualOrGreaterThanCurrent(shipment.getCreatedDate(), 1)) {
						validShipments.add(shipment);
					}
				}
			});
			((ShipmentApprovalSchemaWrapper) dbServletMappedPojo).setShipments(validShipments);
		}
	}
	
	public void valideShipmentForCancellation(SchemaWrapper dbServletMappedPojo) {
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<ShipmentCancellation> shipments = ((ShipmentCancellationSchemaWrapper) dbServletMappedPojo).getShipments();
			
			List<ShipmentCancellation> validShipments = shipments.stream()
					.filter(sht -> (Objects.nonNull(sht) && Objects.isNull(sht.getRefNum()) && StringUtils.equals("ULF."+OTMConstants.TENDER_CALL_TENDER, sht.getTenderStatus())))
					.collect(Collectors.toList());
			Set<String> requestids = validShipments.stream().filter(valid -> Objects.nonNull(valid.getAttribute11())).map(validshp -> validshp.getAttribute11()).collect(Collectors.toSet());
			if(!CollectionUtils.isEmpty(requestids)) {
				List<ShipmentCreationRequest> shipmentCreations = shipmentCreationRequestRepository.findRequestNumberByRequestNumberInAndNotStatus(requestids);
				if(!CollectionUtils.isEmpty(shipmentCreations)) {
					List<String> invalidShipments = shipmentCreations.stream().filter(creation -> (StringUtils.equals(OTMConstants.IN_PROGRESS, creation.getStatus())|| StringUtils.equals(OTMConstants.OPEN, creation.getStatus()))).map(shpcre -> shpcre.getRequestNumber()).collect(Collectors.toList());
					if(!CollectionUtils.isEmpty(invalidShipments)) {
						List<ShipmentCancellation> validForCancellation = validShipments.stream().filter(validshp -> !invalidShipments.contains(validshp.getAttribute11())).collect(Collectors.toList());
						validShipments = validForCancellation;
					}
				}
			}
			((ShipmentCancellationSchemaWrapper) dbServletMappedPojo).setShipments(validShipments);
		}
	}
	
	public void valideShipmentForAssign(SchemaWrapper dbServletMappedPojo) {
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<ShipmentAssign> shipments = ((ShipmentAssignSchemaWrapper) dbServletMappedPojo).getShipments();
			
			List<ShipmentAssign> validShipments = shipments.stream()
					.filter(sht -> (Objects.nonNull(sht) && Objects.isNull(sht.getRefNum()) && StringUtils.equals("ULF."+OTMConstants.TENDER_CALL_TENDER, sht.getTenderStatus())))
					.collect(Collectors.toList());
			Set<String> requestids = validShipments.stream().filter(valid -> Objects.nonNull(valid.getAttribute11())).map(validshp -> validshp.getAttribute11()).collect(Collectors.toSet());
			if(!CollectionUtils.isEmpty(requestids)) {
				List<ShipmentCreationRequest> shipmentCreations = shipmentCreationRequestRepository.findRequestNumberByRequestNumberInAndStatusIn(requestids, new ArrayList<String>() {{add(OTMConstants.OPEN);add(OTMConstants.IN_PROGRESS);}});
				if(!CollectionUtils.isEmpty(shipmentCreations)) {
					List<String> invalidShipments = shipmentCreations.stream().map(shpcre -> shpcre.getRequestNumber()).collect(Collectors.toList());
					if(!CollectionUtils.isEmpty(invalidShipments)) {
						List<ShipmentAssign> validForCancellation = validShipments.stream().filter(validshp -> !invalidShipments.contains(validshp.getAttribute11())).collect(Collectors.toList());
						validShipments = validForCancellation;
					}
				}
			}
			((ShipmentAssignSchemaWrapper) dbServletMappedPojo).setShipments(validShipments);
		}
	}
	
	public boolean shipmentAssignmentValidation(SchemaWrapper dbServletMappedPojo, SchemaWrapper shipmentStopSch, Set<String> sourceLocationGIDs, Set<String> destLocationGIDs) {
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			ShipmentXlaneSchemaWrapper shipmentXlaneSchemaWrapper = ((ShipmentXlaneSchemaWrapper) dbServletMappedPojo);
			List<ShipmentStop> shipmentStops = null;
			List<ShipmentXlane> shipmentXlanes = shipmentXlaneSchemaWrapper.getShipmentXlane();
			if (Objects.nonNull(shipmentStopSch) && Objects.isNull(shipmentStopSch.getError())) {
				shipmentStops = ((ShipmentStopSchemaWrapper) shipmentStopSch).getShipmentStop();
			}
			if (!CollectionUtils.isEmpty(shipmentXlanes)) {
				ShipmentXlane shipmentXlane = shipmentXlanes.get(0);
				String sourceLocGid = shipmentXlane.getSourceLocGid();
				if (Objects.nonNull(sourceLocGid)) {
					for (String sourceLoc : sourceLocationGIDs) {
						if (!StringUtils.equals(sourceLoc, sourceLocGid)) {
							dbServletMappedPojo.setError("All source locations not matched");
							return false;
						}
					}
				} else {
					String sourceRegionGid = shipmentXlane.getSourceRegionGid();
					if (Objects.nonNull(sourceRegionGid) && !CollectionUtils.isEmpty(shipmentStops)) {
						if (Objects.nonNull(shipmentXlane.getPickUpStopConstraint())
								&& NumberUtils.isCreatable(shipmentXlane.getPickUpStopConstraint())) {
							Set<String> picks = new HashSet<>();
							shipmentStops.forEach(shipstop -> {
								if ("P".equals(shipstop.getStopType())) {
									picks.add(shipstop.getLocationGid());
								}
							});
							Integer pickConstraint = Integer.valueOf(shipmentXlane.getPickUpStopConstraint());
							pickConstraint = pickConstraint - picks.size();
							if (!CollectionUtils.isEmpty(picks)) {
								picks.stream().forEach(pick -> {
									if (sourceLocationGIDs.contains(pick)) {
										sourceLocationGIDs.remove(pick);
									}
								});
							}
							if (sourceLocationGIDs.size() > pickConstraint) {
								dbServletMappedPojo.setError("All source locations are greater than source constraints");
								return false;
							}
						}
					} else {
						return false;
					}
				}
				String destLocationGid = shipmentXlane.getDestLocationGid();
				if (Objects.nonNull(destLocationGid)) {
					for (String destLoc : destLocationGIDs) {
						if (!StringUtils.equals(destLoc, destLocationGid)) {
							dbServletMappedPojo.setError("All destination locations not matched");

							return false;
						}
					}
					return true;
				} else {
					String destRegionGid = shipmentXlane.getDestRegionGid();
					if (Objects.nonNull(destRegionGid) && !CollectionUtils.isEmpty(shipmentStops)) {
						if (Objects.nonNull(shipmentXlane.getDeliveryStopContraint())
								&& NumberUtils.isCreatable(shipmentXlane.getDeliveryStopContraint())) {
							Set<String> drops = new HashSet<>();
							shipmentStops.forEach(shipstop -> {
								if ("D".equals(shipstop.getStopType())) {
									drops.add(shipstop.getLocationGid());
								}
							});
							Integer dropConstraint = Integer.valueOf(shipmentXlane.getDeliveryStopContraint());
							dropConstraint = dropConstraint - drops.size();
							if (!CollectionUtils.isEmpty(drops)) {
								drops.stream().forEach(drop -> {
									if (destLocationGIDs.contains(drop)) {
										destLocationGIDs.remove(drop);
									}
								});
							}
							if (destLocationGIDs.size() > dropConstraint) {
								dbServletMappedPojo.setError("All source locations are greater than source constraints");
								return false;
							} 
							return true;
						} else {
							return true;
						}
					} else {
						return false;
					}
				}
			}
		}
		return false;
	}
	
	public void assignValidation(SchemaWrapper dbServletMappedPojo, String orderReleaseTypeGID) {
		log.info("Starting assignValidation");
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<OrderReleases> orderReleases = ((OrderReleasesSchemaWrapper) dbServletMappedPojo).getOrderReleases();
			Set<String> requestIds = new HashSet<>();
			List<OrderReleases> validOrderRelease = orderReleases.stream().filter(orderRelease -> {
				String status = orderRelease.getStatusValueGID();
				if(Objects.nonNull(status) && (StringUtils.equals(OTMConstants.PLANNING_NEW, status) || StringUtils.equals(OTMConstants.PLANNING_UNSCHEDULED, status))) {
					//
					
					if (Objects.nonNull(orderRelease.getEarlyPickupDate())) {
						// Validation a.EARLY_PICKUP_DATE+MAX_SERVICE_TIME <= LATE_DELIVERY_DATE (POB
						// AND DD)
						if (!OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseTypeGID)
								&& Objects.nonNull(orderRelease.getMaxServiceTime())
								&& StringUtils.isNumeric(orderRelease.getMaxServiceTime())
								&& Objects.nonNull(orderRelease.getLateDeliveryDate())) {
							if (!dateUtil.isLessThanOrEqual(orderRelease.getEarlyPickupDate(),
									Integer.valueOf(orderRelease.getMaxServiceTime()),
									orderRelease.getLateDeliveryDate())) {
								return false;
							}
						}
						// Valildation b. LATE_PICKUP_DATE = EARLY_PICKUP_DATE +1
						if (Objects.nonNull(orderRelease.getLatePickupDate()) && !dateUtil
								.isEqual(orderRelease.getEarlyPickupDate(), 1, orderRelease.getLatePickupDate())) {
							return false;
						}
					}
					if(Objects.nonNull(orderRelease.getCrRequestId())) {
						requestIds.add(orderRelease.getCrRequestId());
					}
					if(Objects.nonNull(orderRelease.getAssRequestId())) {
						requestIds.add(orderRelease.getAssRequestId());
					}
					if(Objects.nonNull(orderRelease.getUnassRequestId())) {
						requestIds.add(orderRelease.getUnassRequestId());
					}
					return true;
					//
					
				} else return false;

				
			}).collect(Collectors.toList());
			if(!CollectionUtils.isEmpty(requestIds)) {
				//handle if requestids are more than 1000
				List<ShipmentCreationRequest> requests = shipmentCreationRequestRepository.findRequestNumberByRequestNumberInAndStatusIn(requestIds, new ArrayList<String>() {{add(OTMConstants.OPEN);add(OTMConstants.IN_PROGRESS);add(OTMConstants.APPROVAL_PENDING);}});
				if (!CollectionUtils.isEmpty(requests)) {
					List<String> reqNums = requests.stream().map(req -> req.getRequestNumber())
							.collect(Collectors.toList());
					validOrderRelease = validOrderRelease.stream().filter(validorder -> {
						if (Objects.nonNull(validorder.getCrRequestId()) && reqNums.contains(validorder.getCrRequestId())) {
							return false;
						}
						if (Objects.nonNull(validorder.getAssRequestId()) && reqNums.contains(validorder.getAssRequestId())) {
							return false;
						}
						if (Objects.nonNull(validorder.getUnassRequestId()) && reqNums.contains(validorder.getUnassRequestId())) {
							return false;
						}
						return true;
					}).collect(Collectors.toList());
				}
				
			}
			
			((OrderReleasesSchemaWrapper) dbServletMappedPojo).setOrderReleases(validOrderRelease);

		}
		log.info("END assignValidation");
	}
	
	public void unassignValidation(SchemaWrapper dbServletMappedPojo, String orderReleaseTypeGID) {
		log.info("Starting unassignValidation");
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<OrderReleases> orderReleases = ((OrderReleasesSchemaWrapper) dbServletMappedPojo).getOrderReleases();
			Set<String> requestIds = new HashSet<>();
			List<OrderReleases> validOrderRelease = orderReleases.stream().filter(orderRelease -> {
				String status = orderRelease.getStatusValueGID();
					//
				  if(!StringUtils.equals("ULF."+OTMConstants.TENDER_CALL_TENDER, orderRelease.getShipmentStatusGid()) && !StringUtils.equals(OTMConstants.ENROUTE_NOT_STARTED, orderRelease.getShipmentEnrouteGid())) {
					  return false;
				  }
					
					if (Objects.nonNull(orderRelease.getEarlyPickupDate())) {
						// Validation a.EARLY_PICKUP_DATE+MAX_SERVICE_TIME <= LATE_DELIVERY_DATE (POB
						// AND DD)
						if (!OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseTypeGID)
								&& Objects.nonNull(orderRelease.getMaxServiceTime())
								&& StringUtils.isNumeric(orderRelease.getMaxServiceTime())
								&& Objects.nonNull(orderRelease.getLateDeliveryDate())) {
							if (!dateUtil.isLessThanOrEqual(orderRelease.getEarlyPickupDate(),
									Integer.valueOf(orderRelease.getMaxServiceTime()),
									orderRelease.getLateDeliveryDate())) {
								return false;
							}
						}
						// Valildation b. LATE_PICKUP_DATE = EARLY_PICKUP_DATE +1
						if (Objects.nonNull(orderRelease.getLatePickupDate()) && !dateUtil
								.isEqual(orderRelease.getEarlyPickupDate(), 1, orderRelease.getLatePickupDate())) {
							return false;
						}
					}
					if(Objects.nonNull(orderRelease.getCrRequestId())) {
						requestIds.add(orderRelease.getCrRequestId());
					}
					if(Objects.nonNull(orderRelease.getAssRequestId())) {
						requestIds.add(orderRelease.getAssRequestId());

					}
					if(Objects.nonNull(orderRelease.getUnassRequestId())) {
						requestIds.add(orderRelease.getUnassRequestId());
					}
					return true;
					//
			}).collect(Collectors.toList());
			if(!CollectionUtils.isEmpty(requestIds)) {
				//handle if requestids are more than 1000
				List<ShipmentCreationRequest> requests = shipmentCreationRequestRepository.findRequestNumberByRequestNumberInAndStatusIn(requestIds, new ArrayList<String>() {{add(OTMConstants.OPEN);add(OTMConstants.IN_PROGRESS);add(OTMConstants.APPROVAL_PENDING);}});
				if (!CollectionUtils.isEmpty(requests)) {
					List<String> reqNums = requests.stream().map(req -> req.getRequestNumber())
							.collect(Collectors.toList());
					Set<String> shipids = new HashSet<>();

					validOrderRelease = validOrderRelease.stream().filter(validorder -> {
						if (Objects.nonNull(validorder.getCrRequestId()) && reqNums.contains(validorder.getCrRequestId())) {
							return false;
						}
						if (Objects.nonNull(validorder.getAssRequestId()) && reqNums.contains(validorder.getAssRequestId())) {
							shipids.add(validorder.getShipmentGid());
							return false;
						}
						if (Objects.nonNull(validorder.getUnassRequestId()) && reqNums.contains(validorder.getUnassRequestId())) {
							shipids.add(validorder.getShipmentGid());
							return false;
						}
						return true;
					}).collect(Collectors.toList());
					validOrderRelease = validOrderRelease.stream().filter(valid -> {
						if(Objects.nonNull(valid.getShipmentGid())&&shipids.contains(valid.getShipmentGid())) {
							return false;
						}
						return true;
					}).collect(Collectors.toList());
				}
				
			}
			
			((OrderReleasesSchemaWrapper) dbServletMappedPojo).setOrderReleases(validOrderRelease);

		}
		log.info("END assignValidation");
	}
}
