package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.BulkPlan;
import com.unilever.otmbulkautomation.schema.BulkPlanSchemaWrapper;
import com.unilever.otmbulkautomation.schema.LocationRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderAttributeUpdate;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAttributesUpdates;
import com.unilever.otmbulkautomation.schema.ShipmentStatusSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class OTMService {
	
	@Autowired
	ShipmentCreationRequestRepository repository;
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	@Autowired
	OTMShipmentConstants otmShipmentConstants;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	DBServletPojoMapper mapper;

	@Autowired
	DBServletRestUtil restUtil;
	
	@Autowired
	OTMDateUtil dateutil;
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Value("${otm.emailShipment.query}")
	private String shipmentEmailGetQuery;
	
	@Value("${otm.emailApproval.check.query}")
	private String approvalCheckQuery;
	
	@Value("${otm.bulkplan.query}")
	private String bulkPlanQuery;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	EmailUtil emailUtil;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;
	
	@Autowired
	ShipmentUnassignService shipmentUnassignService;
	
	@Autowired
	ShipmentEqchangeService shipmentEqchangeService;
	
	ObjectMapper objMapper = new ObjectMapper();
	
	public void updateShipmentCreationStatus(String otmResponse) {
		String requestId = otmUtil.getRequestId(otmResponse);
		log.info("Got Response with Request id : {}", requestId);
		if(Objects.nonNull(requestId)) {
			ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
			if(Objects.nonNull(shipment)) {
				log.info("Found shipment for Request id : {}", requestId);
				if (!StringUtils.equals(OTMConstants.BULK_CREATION, shipment.getRequestType())) {
					Integer numberOfShipments = shipment.getNumberOfShipments();
						String shipmentCount = otmUtil.getShipmentCount(otmResponse);
						if (StringUtils.isNumeric(shipmentCount)) {
							shipment.setNumberOfShipments(Integer.valueOf(shipmentCount));
						}
					
				} else {
					shipment.setNumberOfShipments(getShipmentStatusFromBulkPlan(requestId));  
				}
				String secureResource = otmUtil.getSecureResource(otmResponse);
				String tenderCall = otmUtil.getTenderCall(otmResponse);
				String shipmentType = otmUtil.getShipmentType(tenderCall, secureResource);
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "OTM response for req id : "+requestId + " with : "+ shipmentType, "INFO"));
				if(Objects.nonNull(shipmentType)) {
					String shpType = shipment.getShipmentStatus();
					if(Objects.isNull(shpType) || "FTL".equals(shpType)) {
						shipment.setShipmentStatus(shipmentType);
					} 
					if("LTL".equals(shipmentType)) {
						String shipmentId = otmUtil.getShipmentId(otmResponse);
						ShipmentApprovalSchemaWrapper approvalShipmentsFromOtm = getApprovalShipmentsFromOtm(new ArrayList<String>() {{add(shipmentId);}});
						List<ShipmentApproval> shipments = approvalShipmentsFromOtm.getShipments();
						if(!CollectionUtils.isEmpty(shipments)) {
							ShipmentApproval shipmentApproval = shipments.get(0);
							shipmentApproval.setReason(shipment.getReasons());
							String sourceLocationGID = shipmentApproval.getSourceLocationGID();
							String shpmtType = commonUtil.getShipmentType(shipmentApproval.getShipmentType());
							List<User> users = userRepo.findBySourceLocation(new ArrayList<String>(){{add(sourceLocationGID);add(sourceLocationGID.replaceAll("ULF.", ""));}}, "Approver", shpmtType);
							if (!CollectionUtils.isEmpty(users)) {
								List<String> emails = users.stream().map(user -> user.getEmailId()).collect(Collectors.toList());
								try {
									shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>(){{add(shipmentApproval.getShipmentGID());}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentCreatePending(), "I");
									for(User user : users) {
										String module = user.getModule();
									//	if (Objects.nonNull(module) && StringUtils.containsIgnoreCase(module, "creation")) {
											emailUtil.sendEmailWithAttachment(
													"OTM LTL Shipment - Action", otmUtil.getEmail(shipmentApproval,
															user.getUsername(), shipment.getImage()),
													user.getEmailId());
									//	}
									}
									logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "sending Email with req id : "+requestId + " for users : "+ emails , "INFO"));
								}catch (Exception e) {  
									log.error("Error sending email to : {} with exception : {}", emails.toArray(), e.getMessage());
									logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error sending Email with req id : "+requestId + " for users : "+ emails + e.getMessage(), "ERROR"));
								}
							}
						}
						//mail
					}
					shipment.setResponses(Objects.isNull(shipment.getResponses()) ? shipmentType : shipment.getResponses() + "," + shipmentType);
					if((Objects.nonNull(shipment.getNumberOfShipments()) && shipment.getNumberOfShipments().equals(shipment.getResponses().split(",").length)) || StringUtils.equals("Completed", shipment.getStatus())) {
						if("FTL".equals(shipment.getShipmentStatus())) {
							shipment.setStatus("Completed");
						} else {
							shipment.setStatus(OTMConstants.APPROVAL_PENDING);
						}
						
					} else if(StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus()) || StringUtils.equals(OTMConstants.APPROVAL_PENDING, shipment.getStatus())){
						
					} else {
						shipment.setStatus(OTMConstants.IN_PROGRESS);
					}
				}
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Responses for req id : "+requestId + " with :  "+ shipment.getResponses() + "count : "+ shipment.getNumberOfShipments(), "INFO"));
				//Date currentDate = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).getTime();
				repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
			}
		}
	}

	public void updateShipmentCancellationStatus(String otmResponse) {
		String requestId = otmUtil.getRequestId(otmResponse);
		String shipmentId = otmUtil.getShipmentId(otmResponse);
		log.info("Got Response with Request id : {}", requestId);
		if(Objects.nonNull(requestId) && Objects.nonNull(shipmentId)) {
			ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
			if(Objects.nonNull(shipment)) {
				//shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(otmShipmentConstants.getDomainName()+"."+shipmentId);}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentCancelPending(), "D");
				log.info("Found shipment for Request id : {}", requestId);
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "OTM response for shipment Cancellation id : "+requestId + " with shipment id: "+ shipmentId, "INFO"));
				shipment.setResponses(Objects.isNull(shipment.getResponses()) ? shipmentId : shipment.getResponses() + "," + shipmentId);
				if((Objects.nonNull(shipment.getNumberOfShipments()) && shipment.getNumberOfShipments().equals(shipment.getResponses().split(",").length)) || StringUtils.equals("Completed", shipment.getStatus())) {
					if(!StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus())){
						shipment.setStatus("Completed");
					}
				} 
//				else if(StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus())){
//					
//				} else {
//					shipment.setStatus(OTMConstants.IN_PROGRESS);
//				}
				
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Responses for req id : "+requestId + " with :  "+ shipment.getResponses() + "count : "+ shipment.getNumberOfShipments(), "INFO"));
				//Date currentDate = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).getTime();
				repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
			}
		}
	}
	
	public void updateShipmentUnAssignStatus(String otmResponse) {
		String requestId = otmUtil.getRequestId(otmResponse);
		String shipmentId = otmUtil.getShipmentId(otmResponse);
		log.info("Got Response with Request id : {}", requestId);
		if(Objects.nonNull(requestId) && Objects.nonNull(shipmentId)) {
			ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
			if(Objects.nonNull(shipment)) {
				//shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(otmShipmentConstants.getDomainName()+"."+shipmentId);}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentCancelPending(), "D");
				log.info("Found shipment for Request id : {}", requestId);
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "OTM response for shipment Unassign id : "+requestId + " with shipment id: "+ shipmentId, "INFO"));
				shipment.setResponses(Objects.isNull(shipment.getResponses()) ? shipmentId : shipment.getResponses() + "," + shipmentId);
				if((Objects.nonNull(shipment.getNumberOfShipments()) && shipment.getNumberOfShipments().equals(shipment.getResponses().split(",").length)) || StringUtils.equals("Completed", shipment.getStatus())) {
					if(!StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus())){
						shipment.setStatus("Completed");
					}
				} 
//				else if(StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus())){
//					
//				} else {
//					shipment.setStatus(OTMConstants.IN_PROGRESS);
//				}
				
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Responses for req id : "+requestId + " with :  "+ shipment.getResponses() + "count : "+ shipment.getNumberOfShipments(), "INFO"));
				//Date currentDate = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).getTime();
				repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
			}
		}
	}
	
	public void updateShipmentAssignStatus(String otmResponse) {
		String requestId = otmUtil.getRequestId(otmResponse);
		log.info("Got Response with Request id : {}", requestId);
		if(Objects.nonNull(requestId)) {
			ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
			if(Objects.nonNull(shipment)) {
				ShipmentCreationRequestLog reqLog = repositoryLog.findByRequestNumber(requestId);
				log.info("Found shipment for Request id : {}", requestId);
				String secureResource = otmUtil.getSecureResource(otmResponse);
				String tenderCall = otmUtil.getTenderCall(otmResponse);
				String shipmentType = otmUtil.getShipmentType(tenderCall, secureResource);
				String shipmentId = otmUtil.getShipmentId(otmResponse);
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "OTM response for Assign req id : "+requestId + " with : "+ shipmentType, "INFO"));
				if(Objects.nonNull(shipmentType)) {
					String shpType = shipment.getShipmentStatus();
					if(Objects.isNull(shpType) || "FTL".equals(shpType)) {
						shipment.setShipmentStatus(shipmentType);
					} 
					if("LTL".equals(shipmentType)) {
						ShipmentApprovalSchemaWrapper approvalShipmentsFromOtm = getApprovalShipmentsFromOtm(new ArrayList<String>() {{add(shipmentId);}});
						List<ShipmentApproval> shipments = approvalShipmentsFromOtm.getShipments();
						if(!CollectionUtils.isEmpty(shipments)) {
							ShipmentApproval shipmentApproval = shipments.get(0);
							shipmentApproval.setAttribute11(requestId);
							shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add("ULF."+shipmentId);}},
									otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentAssignPending(), "I");
							shipmentApproval.setReason(shipment.getReasons());
							String sourceLocationGID = shipmentApproval.getSourceLocationGID();
							String shpmtType = commonUtil.getShipmentType(shipmentApproval.getShipmentType());
							List<User> users = userRepo.findBySourceLocation(new ArrayList<String>(){{add(sourceLocationGID);add(sourceLocationGID.replaceAll("ULF.", ""));}}, "Approver", shpmtType);
							if (!CollectionUtils.isEmpty(users)) {
								List<String> emails = users.stream().map(user -> user.getEmailId()).collect(Collectors.toList());
								try {
									for (User user : users) {
										String module = user.getModule();
//										if (Objects.nonNull(module)
//												&& StringUtils.containsIgnoreCase(module, "modification")) {
											emailUtil.sendEmailWithAttachment("OTM Delivery Addition- Action", otmUtil
													.getEmailForAssign(shipmentApproval, user.getUsername(), reqLog),
													user.getEmailId());
									//	}
									}
									logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "sending Email with req id : "+requestId + " for users : "+ emails , "INFO"));
								} catch (Exception e) {  
									log.error("Error sending email to : {} with exception : {}", emails.toArray(), e.getMessage());
									logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error sending Email with req id : "+requestId + " for users : "+ emails + e.getMessage(), "ERROR"));
								}
							}
						}
						//mail
					}
					String responses = shipment.getResponses();
//					String[] split = responses.split(",");
//					List<String> array = new ArrayList<String>(Arrays.asList(split));
//					String response = "";
//					boolean isGid = false;
//					boolean isExecuted = false;
//					int count = 0;
//					String orderid = "";
//					
//					for (String res : array) {
//						if (!isGid) {
//							count++;
//						} else {
//							if (!isExecuted) {
//								orderid = res;
//								isExecuted = true;
//							}
//						}
//						if ("FTL".equals(res) || "LTL".equals(res) || isGid) {
//							response = StringUtils.isBlank(response) ? res : response + "," + res;
//						} else {
//							isGid = true;
//							response = StringUtils.isBlank(response) ? shipmentType : response + "," + shipmentType;
//						}
//					}
					String response = StringUtils.isBlank(responses) ? shipmentType : responses + "," + shipmentType;

					shipment.setResponses(response);
					if((Objects.nonNull(shipment.getNumberOfShipments()) && shipment.getNumberOfShipments().equals(1)) || StringUtils.equals("Completed", shipment.getStatus())) {
						if("FTL".equals(shipment.getShipmentStatus())) {
							shipment.setStatus("Completed");
							try {
//								shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add("ULF."+shipmentId);}},
//										otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentAssignPending(), "D");
								} catch(Exception e) {
									
								}
						} else {
							shipment.setStatus(OTMConstants.APPROVAL_PENDING);
						}
						
					} else if(StringUtils.equals(OTMConstants.REJECTED, shipment.getStatus()) || StringUtils.equals(OTMConstants.APPROVAL_PENDING, shipment.getStatus())){
						
					} else {
						shipment.setStatus(OTMConstants.IN_PROGRESS);
					}
					logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Responses for req id : "+requestId + " with :  "+ shipment.getResponses() + "count : "+ shipment.getNumberOfShipments(), "INFO"));
					//Date currentDate = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).getTime();
					repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
//					if(!StringUtils.isBlank(orderid)) {
//					try {
//						OrderAttributeUpdate attrUpdate = new OrderAttributeUpdate();
//						attrUpdate.setAttribute4(shipmentId);
//						attrUpdate.setOrderReleaseXid(orderid.replaceAll("ULF.", ""));
//						String update = objMapper.writeValueAsString(attrUpdate);
//						String rest = "orderReleases/" + orderid;
//						dbServletRestUtil.postQueryToRestOTM(rest, update);
//						} catch(Exception e) {
//							log.error("Error assining api update: {} with exception : {}", orderid, e.getMessage());
//							logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error assining api update for :"+ orderid +" with req id : "+requestId  + e.getMessage(), "ERROR"));
//						}
//					}
				}
				
			}
		}
	}
	
	public boolean getUserBlockingTime(List<String> depotids) {
		String query = MessageFormat.format(otmShipmentConstants.getUserBlockingQuery(),
				new Object[] { commonUtil.getCommaDelimiterString(depotids) });
		String dbString = restUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
		SchemaWrapper dbServletMappedPojo = mapper.getDBServletMappedPojo(dbString, LocationRefnumSchemaWrapper.class);
		try {
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			LocationRefnumSchemaWrapper locationrefValue = (LocationRefnumSchemaWrapper) dbServletMappedPojo;
			if(!CollectionUtils.isEmpty(locationrefValue.getLocationRefnums())){
				List<String> blockTimings = locationrefValue.getLocationRefnums().stream().map(refnum ->refnum.getLocationRefNumValue()).collect(Collectors.toList());
				for (String blockTime : blockTimings) {
					String[] blocktime = blockTime.split("-");
					int starthours = Integer.valueOf(blocktime[0]);
					int endhours = Integer.valueOf(blocktime[1]);
					int hours = dateutil.getCurrentISTHours();
					if(endhours > starthours && hours >= starthours && hours <= endhours) {
						return true;
					}
					if(endhours < starthours && (hours >= starthours || hours <= endhours)) {
						return true;
					}
				}
				
			}
		} 
		} catch(Exception e) {
			log.error("ERROR in getting blocking timings with exception : {}", e.getMessage());
		}
		return false;
	}
	
	public ShipmentApprovalSchemaWrapper getApprovalShipmentsFromOtm(List<String> shipmentIds) {
		if (Objects.nonNull(shipmentIds)) {
			String query = MessageFormat.format(shipmentEmailGetQuery,
						new Object[] {commonUtil.getCommaDelimiterString(shipmentIds).replaceAll("ULF.", "")});
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = mapper.getDBServletMappedPojo(dbString,  ShipmentApprovalSchemaWrapper.class);
			 if(Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 return (ShipmentApprovalSchemaWrapper)dbServletMappedPojo;
			 }
		} 
		return new ShipmentApprovalSchemaWrapper();
	}
	
	public String postStatusToOTM(String shipmentId,
			String status, String requestId, String userId) {
		StringBuffer state = new StringBuffer();
		if (OTMConstants.APPROVED.equals(status)) {
			state.append("SA");
		} else {
			state.append("SR");
		}
		ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
		if(Objects.nonNull(shipment)) {
			if (OTMConstants.REJECTED.equals(shipment.getStatus()) || OTMConstants.REJECTED.equals(status)) {
				shipment.setStatus(OTMConstants.REJECTED);
			}
			else if(Objects.nonNull(shipment.getResponses())) {
				shipment.setResponses(shipment.getResponses().replaceFirst("LTL", "FTL"));
				if (Objects.nonNull(shipment.getNumberOfShipments())
						&& shipment.getNumberOfShipments().equals(shipment.getResponses().split(",").length)
						&& !shipment.getResponses().contains("LTL")) {
					shipment.setStatus(OTMConstants.COMPLETED);
					shipment.setShipmentStatus("FTL");
				}
			}
			String track = shipmentId + ":" + userId + ":" + status;
			String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
			repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
			repository.updateShipmentApprovalTracking(requestId, approvalTracking, dateutil.getCurrentISTLocalDateTime());
		}
		logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Shipment status : "+ status + " with req id : "+requestId +" for shipment :"+shipmentId+ " status : " + shipment.getStatus() + " responses :"+ shipment.getResponses(), "INFO"));
		try {
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>(){{add(shipmentId);}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentCreatePending(), "D");
		}catch(Exception e){
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "DeleteShipmentRefnum : "+ e.getMessage() + " with shipmentgid id : "+shipmentId +" for refnum :"+otmShipmentConstants.getShipmentPendingGid()+ " value : " + otmShipmentConstants.getShipmentCreatePending(), "ERROR"));
		}
		return dbServletRestUtil.postShipmentStatusToWMServlet(shipmentId,
				state.toString(), dateutil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));

	}
	
	public String postAssignStatusToOTM(String shipmentId,
			String status, String requestId, String userId) {
		StringBuffer state = new StringBuffer();
		if (OTMConstants.APPROVED.equals(status)) {
			state.append("SA");
		} else {
			state.append("RV");
		}
		ShipmentCreationRequest shipment = repository.findByRequestNumber(requestId);
		if(Objects.nonNull(shipment)) {
			if (OTMConstants.REJECTED.equals(shipment.getStatus()) || OTMConstants.REJECTED.equals(status)) {
				shipment.setStatus(OTMConstants.REJECTED);
			}
			else if(Objects.nonNull(shipment.getResponses())) {
				shipment.setResponses(shipment.getResponses().replaceFirst("LTL", "FTL"));
				if (Objects.nonNull(shipment.getNumberOfShipments())
						&& shipment.getNumberOfShipments().equals(1)
						&& !shipment.getResponses().contains("LTL")) {
					shipment.setStatus(OTMConstants.COMPLETED);
					shipment.setShipmentStatus("FTL");
				}
			}
			String track = shipmentId + ":" + userId + ":" + status;
			String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
			repository.updateShipmentResponses(requestId, shipment.getResponses(), shipment.getStatus(), shipment.getShipmentStatus(), null, shipment.getNumberOfShipments(),dateutil.getCurrentISTLocalDateTime());
			repository.updateShipmentApprovalTracking(requestId, approvalTracking, dateutil.getCurrentISTLocalDateTime());
		}
		logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Shipment Assign status : "+ status + " with req id : "+requestId +" for shipment :"+shipmentId+ " status : " + shipment.getStatus() + " responses :"+ shipment.getResponses(), "INFO"));
		try {
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>(){{add(shipmentId);}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentAssignPending(), "D");
			
		}catch(Exception e){
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "DeleteShipmentRefnum : "+ e.getMessage() + " with shipmentgid id : "+shipmentId +" for refnum :"+otmShipmentConstants.getShipmentPendingGid()+ " value : " + otmShipmentConstants.getShipmentCreatePending(), "ERROR"));
		}
		
		if(OTMConstants.APPROVED.equals(status)) {
		return dbServletRestUtil.postShipmentStatusToWMServlet(shipmentId,
				state.toString(), dateutil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));
		} else {
			try {
				ShipmentAttributesUpdates attrUpdate = new ShipmentAttributesUpdates();
				attrUpdate.setAttribute11(requestId);
				attrUpdate.setAttribute12("ASSIGNREJECTED");
				attrUpdate.setShipmentXid(shipmentId.replaceAll("ULF.", ""));
				String update = objMapper.writeValueAsString(attrUpdate);
				String rest = "shipments/" + shipmentId;
				dbServletRestUtil.postQueryToRestOTM(rest, update);			
		}catch(Exception e){
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "ShipmentAttributesUpdates : "+ e.getMessage() + " with shipmentgid id : "+shipmentId +" for req id :"+requestId, "ERROR"));
			return "fail";
		}
		return "1";	
		}

	}
	
	public String getShipmentDetailsFromOtm(String shipmentId) {
		if (Objects.nonNull(shipmentId)) {
			String query = MessageFormat.format(approvalCheckQuery, new Object[] { shipmentId });
			String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentStatusSchemaWrapper.class);
			 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 ShipmentStatusSchemaWrapper srsw = (ShipmentStatusSchemaWrapper) dbServletMappedPojo;
				if (!CollectionUtils.isEmpty(srsw.getShipmentStatus())) {
					String statusValueGid = srsw.getShipmentStatus().get(0).getStatusValueGid();
					if (Objects.nonNull(statusValueGid)
							&& (StringUtils.equals(statusValueGid, OTMConstants.TENDER_NOCALL) ||  (StringUtils.equals(statusValueGid, OTMConstants.TENDER_CALL_CANCEL)))) {
						return statusValueGid;
					}
				}
			 }
		}
		 return "Action has been already taken.";
		 //return "ULF.TENDER CALL_NO CALL";
	 }
	
	public Integer getShipmentStatusFromBulkPlan(String reqestId) {
		if (Objects.nonNull(reqestId)) {
			String shpQueryName = "'SHPCRT"+reqestId;
			String query = MessageFormat.format(bulkPlanQuery, new Object[] { shpQueryName+"GT',"+shpQueryName+"CD',"+shpQueryName+"MT'" });
			String dbString = dbServletRestUtil.postGetQueryToDBServlet("BULK_PLAN", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString, BulkPlanSchemaWrapper.class);
			 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 BulkPlanSchemaWrapper srsw = (BulkPlanSchemaWrapper) dbServletMappedPojo;
				if (!CollectionUtils.isEmpty(srsw.getBulkPlans())) {
					List<BulkPlan> bulkPlans = srsw.getBulkPlans();
					int shipments = 0;
					for(BulkPlan bulkplan : bulkPlans) {
						if(StringUtils.equals("COMPLETED",bulkplan.getState())){
							String numOfShipments = bulkplan.getNumOfShipments();
							if(NumberUtils.isCreatable(numOfShipments)) {
								shipments += Integer.valueOf(numOfShipments);
							}
						} else {
							return null;
						}
					}
					return shipments;
				}
			 }
		}
		 return null;
	 }
	
	public String postCancellationByRequestId(String status,String requestId, String userId) {
		String html = "Referring shipment has been outdated.";
		ShipmentCreationRequest shpCreation = repository.findByRequestNumber(requestId);
		if(StringUtils.equals(shpCreation.getStatus(),OTMConstants.APPROVAL_PENDING)) {
			ShipmentCreationRequestLog shipLog = repositoryLog.findByRequestNumber(requestId);
			String ordersNumbers = shipLog.getOrdersNumbers();
			String[] split = ordersNumbers.split(",");
			List<String> shipmentIds = Arrays.asList(split);
			
			if (OTMConstants.APPROVED.equals(status)) {
				for(String shipmentId : shipmentIds) {
				dbServletRestUtil.postShipmentStatusToWMServlet(shipmentId,
						"SC", dateutil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));

				}
				repository.updateShipmentApprovalStatus(requestId, OTMConstants.IN_PROGRESS, dateutil.getCurrentISTLocalDateTime());
				html =  "Your Approval request is being processed";

			} else {
				repository.updateShipmentApprovalStatus(requestId, status, dateutil.getCurrentISTLocalDateTime());
				html = "Your Rejection request is being processed";
			}
			shipmentCreationFacade.createOrDeleteShipmentRefnum(shipmentIds, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentCancelPending(), "D");
			String approvalTracking = shpCreation.getApprovalTracking();
			for (String shipmentId : shipmentIds) {
				String track = shipmentId + ":" + userId + ":" + status;
			    approvalTracking = Objects.isNull(approvalTracking) ? track : approvalTracking + "," + track;
			}
			repository.updateShipmentApprovalTracking(requestId, approvalTracking, dateutil.getCurrentISTLocalDateTime());

		}
		return html;
	}
	
	public String postUnassignByRequestId(String status,String requestId, String userId) {
		String html = "Referring shipment has been outdated.";
		ShipmentCreationRequest shpCreation = repository.findByRequestNumber(requestId);
		if(StringUtils.equals(shpCreation.getStatus(),OTMConstants.APPROVAL_PENDING)) {
			ShipmentCreationRequestLog shipLog = repositoryLog.findByRequestNumber(requestId);
			String ordersNumbers = shipLog.getOrdersNumbers();
			String[] split = ordersNumbers.split(",");
			List<String> shipmentordIds = Arrays.asList(split);
			List<String> shipids = new ArrayList<>();
			List<String> ordids = new ArrayList<>();

			shipmentordIds.forEach(id -> {
				String[] ordship = id.split("-");
				if(ordship.length>2) {
					shipids.add(ordship[0]);
					ordids.add(ordship[2]);
				}
			});
			if (OTMConstants.APPROVED.equals(status)) {
				shipmentUnassignService.updateShipmentAndOrdersRequestId(requestId, shipids, ordids);
				repository.updateShipmentApprovalStatus(requestId, OTMConstants.IN_PROGRESS, dateutil.getCurrentISTLocalDateTime());
				html =  "Your Approval request is being processed";

			} else {
				repository.updateShipmentApprovalStatus(requestId, status, dateutil.getCurrentISTLocalDateTime());
				html = "Your Rejection request is being processed";
			}
			shipmentCreationFacade.createOrDeleteShipmentRefnum(shipids, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentUnassignPending(), "D");
			String approvalTracking = shpCreation.getApprovalTracking();
			for (String shipmentId : shipids) {
				String track = shipmentId + ":" + userId + ":" + status;
			    approvalTracking = Objects.isNull(approvalTracking) ? track : approvalTracking + "," + track;
			}
			repository.updateShipmentApprovalTracking(requestId, approvalTracking, dateutil.getCurrentISTLocalDateTime());

		}
		return html;
	}
	
	public String posteqChangeByRequestId(String status,String requestId, String userId, String shipid) {
		String html = "Referring shipment has been outdated.";
		ShipmentCreationRequest shpCreation = repository.findByRequestNumber(requestId);
		if(StringUtils.equals(shpCreation.getStatus(),OTMConstants.APPROVAL_PENDING)) {
			ShipmentCreationRequestLog shipLog = repositoryLog.findByRequestNumber(requestId);
			
			if (OTMConstants.APPROVED.equals(status)) {
				shipmentEqchangeService.updateShipmentAndOrdersRequestId(requestId, shipid);
				repository.updateShipmentApprovalStatus(requestId, OTMConstants.IN_PROGRESS, dateutil.getCurrentISTLocalDateTime());
				html =  "Your Approval request is being processed";

			} else {
				repository.updateShipmentApprovalStatus(requestId, status, dateutil.getCurrentISTLocalDateTime());
				html = "Your Rejection request is being processed";
			}
			shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipid);}}, otmShipmentConstants.getShipmentPendingGid(), otmShipmentConstants.getShipmentEquipmentPending(), "D");
			String approvalTracking = shpCreation.getApprovalTracking();
			
				String track = shipid + ":" + userId + ":" + status;
			    approvalTracking = Objects.isNull(approvalTracking) ? track : approvalTracking + "," + track;
			
			repository.updateShipmentApprovalTracking(requestId, approvalTracking, dateutil.getCurrentISTLocalDateTime());

		}
		return html;
	}
	
}
