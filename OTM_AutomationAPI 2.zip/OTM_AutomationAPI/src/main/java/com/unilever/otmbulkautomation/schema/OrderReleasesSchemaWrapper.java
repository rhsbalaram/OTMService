package com.unilever.otmbulkautomation.schema;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;
@Data
@JacksonXmlRootElement(localName="TRANSACTION_SET")
public class OrderReleasesSchemaWrapper extends SchemaWrapper{
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "ORDER_RELEASE")
    private List<OrderReleases> orderReleases;
	 
	@JsonInclude(Include.NON_NULL)
    private String orderReleaseType; 
	
	@JsonInclude(Include.NON_NULL)
	private String reason;
	
	@JsonInclude(Include.NON_NULL)
	private String image;
	
	@JsonInclude(Include.NON_NULL)
	private String shipmentXid;
}