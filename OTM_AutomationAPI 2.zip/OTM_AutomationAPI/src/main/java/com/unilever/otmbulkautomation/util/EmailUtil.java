package com.unilever.otmbulkautomation.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.http.HttpHost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.model.Email;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class EmailUtil {

	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	RestTemplate restTemplate ;
	HttpHeaders httpHeaders;
	
	@Autowired
	OTMDateUtil dateutil;

	@PostConstruct
	public void loadDBServletQueryFile() throws IOException {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(

				);
		this.restTemplate = new RestTemplate(requestFactory);
		this.httpHeaders = new HttpHeaders() {
			{
				setContentType(MediaType.APPLICATION_JSON);
			}
		};
	}
	
	public void sendEmail(String subject, String body, String... to) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(to);
		msg.setSubject(subject);
		msg.setText(body);
		javaMailSender.send(msg);

	}

	public void sendEmailWithAttachment(String subject, String body, String... to)
			throws MessagingException, UnsupportedEncodingException{
		try {
		MimeMessage msg = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(msg, true);
		helper.setFrom(new InternetAddress("oracle@unld02prd-pub.opc.oracleoutsourcing.com","Unilever.support"));
		//helper.setFrom("balaramrhs.friend@gmail.com");
		helper.setTo(to);
		helper.setSubject(subject);
		helper.setText(body, true);
		javaMailSender.send(msg);
		}catch(Exception e) {
			log.error("Error processing email user : {}, subject : {}, exception : {}", to, subject, e.getMessage());
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error sending Email with subject : "+subject + " for users : "+ to.toString() + e.getMessage(), "ERROR"));
		}

	}
	
//	public void sendEmailWithAttachment(String subject, String body, String to){
//		try {
//			sendEmailWithProxy( subject,  body,  to);
//		}catch(Exception e) {
//			log.error("Error processing email user : {}, subject : {}, exception : {}", to, subject, e.getMessage());
//			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error sending Email with subject : "+subject + " for users : "+ to + e.getMessage(), "ERROR"));
//		}
//
//	}
	
	public void sendEmailWithProxy(String subject, String body, String to) {
		
		Email email = new Email();
		email.setBody(body);
		email.setTo(to);
		email.setSubject(subject);
		HttpEntity<Email> request = 
			      new HttpEntity<Email>(email, httpHeaders);
		restTemplate.postForEntity("http://150.136.202.168/OTMAutomationAPI/v3/email", request, String.class);
		
	}
}