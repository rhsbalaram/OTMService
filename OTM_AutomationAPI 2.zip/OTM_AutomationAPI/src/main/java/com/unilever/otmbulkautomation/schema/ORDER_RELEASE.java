//package com.unilever.otmbulkautomation.schema;
//
//
//import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
//public class ORDER_RELEASE
//{
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String PICKUP_IS_APPT;
//
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TRANSPORT_HANDLING_UNIT_GID;
//
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String PRIORITY;
//
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_VOLUME;
//
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ORDER_RELEASE_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String OTM_VERSION;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String BUNDLING_TYPE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String EARLY_PICKUP_DATE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String LOC_AMOUNT_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_VOLUME_UOM_CODE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_WEIGHT;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String INSPECTION_REQUIRED;
//
//	@JacksonXmlProperty(
//		      isAttribute = true)
//	private String MARKED_FOR_PURGE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE1;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_TEMPLATE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String DEST_LOCATION_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_WEIGHT_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String DUTY_PAID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE9;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE8;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String LOC_AMOUNT_CURRENCY_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE7;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_DECLARED_VALUE_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_VOLUME_UOM_CODE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String CUSTOMER_UNITIZATION_REQUEST;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_SPLITTABLE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String BULK_PLAN_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ORDER_RELEASE_TYPE_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_LOC_STALE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_WEIGHT;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ON_RT_EXECUTION;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_WEIGHT_UOM_CODE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ORDER_RELEASE_XID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String LOC_AMOUNT;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_PRE_ENTERED_PU;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE10;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_VOLUME;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_WEIGHT_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_VOLUME;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String INDICATOR;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_VOLUME_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE_DATE10;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String SOURCE_LOCATION_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_VOLUME_UOM_CODE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_CONSOLIDATE_OR_EQUIPMENT;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_WEIGHT_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IMPORT_LICENSE_REQUIRED;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String LATE_PICKUP_DATE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_DECLARED_VALUE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ATTRIBUTE_DATE9;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String ASSIGNED_ITINERARY_GID;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_NET_VOLUME_BASE;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_ITEM_PACKAGE_COUNT;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_TOPOFF;
//	@JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_DECLARED_VALUE_BASE;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_SHIP_UNIT_COUNT;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String SECONDARY_T_WEIGHT_UOM_CODE;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String MUST_SHIP_THRU_X_DOCK;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_LOC_REQUIRED;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String DOMAIN_NAME;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String DELIVERY_IS_APPT;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String MUST_SHIP_THRU_POOL;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String MUST_SHIP_DIRECT;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_WEIGHT;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_VOLUME_BASE;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String TOTAL_WEIGHT_UOM_CODE;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String RELEASE_METHOD_GID;
//    @JacksonXmlProperty(
//		      isAttribute = true)
//    private String IS_KNOWN_SHIPPER;
//
//    public String getPICKUP_IS_APPT ()
//    {
//        return PICKUP_IS_APPT;
//    }
//
//    public void setPICKUP_IS_APPT (String PICKUP_IS_APPT)
//    {
//        this.PICKUP_IS_APPT = PICKUP_IS_APPT;
//    }
//
//    public String getTRANSPORT_HANDLING_UNIT_GID ()
//    {
//        return TRANSPORT_HANDLING_UNIT_GID;
//    }
//
//    public void setTRANSPORT_HANDLING_UNIT_GID (String TRANSPORT_HANDLING_UNIT_GID)
//    {
//        this.TRANSPORT_HANDLING_UNIT_GID = TRANSPORT_HANDLING_UNIT_GID;
//    }
//
//    public String getPRIORITY ()
//    {
//        return PRIORITY;
//    }
//
//    public void setPRIORITY (String PRIORITY)
//    {
//        this.PRIORITY = PRIORITY;
//    }
//
//    public String getTOTAL_NET_VOLUME ()
//    {
//        return TOTAL_NET_VOLUME;
//    }
//
//    public void setTOTAL_NET_VOLUME (String TOTAL_NET_VOLUME)
//    {
//        this.TOTAL_NET_VOLUME = TOTAL_NET_VOLUME;
//    }
//
//    public String getORDER_RELEASE_GID ()
//    {
//        return ORDER_RELEASE_GID;
//    }
//
//    public void setORDER_RELEASE_GID (String ORDER_RELEASE_GID)
//    {
//        this.ORDER_RELEASE_GID = ORDER_RELEASE_GID;
//    }
//
//    public String getOTM_VERSION ()
//    {
//        return OTM_VERSION;
//    }
//
//    public void setOTM_VERSION (String OTM_VERSION)
//    {
//        this.OTM_VERSION = OTM_VERSION;
//    }
//
//    public String getBUNDLING_TYPE ()
//    {
//        return BUNDLING_TYPE;
//    }
//
//    public void setBUNDLING_TYPE (String BUNDLING_TYPE)
//    {
//        this.BUNDLING_TYPE = BUNDLING_TYPE;
//    }
//
//    public String getEARLY_PICKUP_DATE ()
//    {
//        return EARLY_PICKUP_DATE;
//    }
//
//    public void setEARLY_PICKUP_DATE (String EARLY_PICKUP_DATE)
//    {
//        this.EARLY_PICKUP_DATE = EARLY_PICKUP_DATE;
//    }
//
//    public String getLOC_AMOUNT_BASE ()
//    {
//        return LOC_AMOUNT_BASE;
//    }
//
//    public void setLOC_AMOUNT_BASE (String LOC_AMOUNT_BASE)
//    {
//        this.LOC_AMOUNT_BASE = LOC_AMOUNT_BASE;
//    }
//
//    public String getTOTAL_VOLUME_UOM_CODE ()
//    {
//        return TOTAL_VOLUME_UOM_CODE;
//    }
//
//    public void setTOTAL_VOLUME_UOM_CODE (String TOTAL_VOLUME_UOM_CODE)
//    {
//        this.TOTAL_VOLUME_UOM_CODE = TOTAL_VOLUME_UOM_CODE;
//    }
//
//    public String getSECONDARY_T_WEIGHT ()
//    {
//        return SECONDARY_T_WEIGHT;
//    }
//
//    public void setSECONDARY_T_WEIGHT (String SECONDARY_T_WEIGHT)
//    {
//        this.SECONDARY_T_WEIGHT = SECONDARY_T_WEIGHT;
//    }
//
//    public String getINSPECTION_REQUIRED ()
//    {
//        return INSPECTION_REQUIRED;
//    }
//
//    public void setINSPECTION_REQUIRED (String INSPECTION_REQUIRED)
//    {
//        this.INSPECTION_REQUIRED = INSPECTION_REQUIRED;
//    }
//
//    public String getMARKED_FOR_PURGE ()
//    {
//        return MARKED_FOR_PURGE;
//    }
//
//    public void setMARKED_FOR_PURGE (String MARKED_FOR_PURGE)
//    {
//        this.MARKED_FOR_PURGE = MARKED_FOR_PURGE;
//    }
//
//    public String getATTRIBUTE1 ()
//    {
//        return ATTRIBUTE1;
//    }
//
//    public void setATTRIBUTE1 (String ATTRIBUTE1)
//    {
//        this.ATTRIBUTE1 = ATTRIBUTE1;
//    }
//
//    public String getIS_TEMPLATE ()
//    {
//        return IS_TEMPLATE;
//    }
//
//    public void setIS_TEMPLATE (String IS_TEMPLATE)
//    {
//        this.IS_TEMPLATE = IS_TEMPLATE;
//    }
//
//    public String getDEST_LOCATION_GID ()
//    {
//        return DEST_LOCATION_GID;
//    }
//
//    public void setDEST_LOCATION_GID (String DEST_LOCATION_GID)
//    {
//        this.DEST_LOCATION_GID = DEST_LOCATION_GID;
//    }
//
//    public String getSECONDARY_T_WEIGHT_BASE ()
//    {
//        return SECONDARY_T_WEIGHT_BASE;
//    }
//
//    public void setSECONDARY_T_WEIGHT_BASE (String SECONDARY_T_WEIGHT_BASE)
//    {
//        this.SECONDARY_T_WEIGHT_BASE = SECONDARY_T_WEIGHT_BASE;
//    }
//
//    public String getDUTY_PAID ()
//    {
//        return DUTY_PAID;
//    }
//
//    public void setDUTY_PAID (String DUTY_PAID)
//    {
//        this.DUTY_PAID = DUTY_PAID;
//    }
//
//    public String getATTRIBUTE9 ()
//    {
//        return ATTRIBUTE9;
//    }
//
//    public void setATTRIBUTE9 (String ATTRIBUTE9)
//    {
//        this.ATTRIBUTE9 = ATTRIBUTE9;
//    }
//
//    public String getATTRIBUTE8 ()
//    {
//        return ATTRIBUTE8;
//    }
//
//    public void setATTRIBUTE8 (String ATTRIBUTE8)
//    {
//        this.ATTRIBUTE8 = ATTRIBUTE8;
//    }
//
//    public String getLOC_AMOUNT_CURRENCY_GID ()
//    {
//        return LOC_AMOUNT_CURRENCY_GID;
//    }
//
//    public void setLOC_AMOUNT_CURRENCY_GID (String LOC_AMOUNT_CURRENCY_GID)
//    {
//        this.LOC_AMOUNT_CURRENCY_GID = LOC_AMOUNT_CURRENCY_GID;
//    }
//
//    public String getATTRIBUTE7 ()
//    {
//        return ATTRIBUTE7;
//    }
//
//    public void setATTRIBUTE7 (String ATTRIBUTE7)
//    {
//        this.ATTRIBUTE7 = ATTRIBUTE7;
//    }
//
//    public String getTOTAL_DECLARED_VALUE_GID ()
//    {
//        return TOTAL_DECLARED_VALUE_GID;
//    }
//
//    public void setTOTAL_DECLARED_VALUE_GID (String TOTAL_DECLARED_VALUE_GID)
//    {
//        this.TOTAL_DECLARED_VALUE_GID = TOTAL_DECLARED_VALUE_GID;
//    }
//
//    public String getSECONDARY_T_VOLUME_UOM_CODE ()
//    {
//        return SECONDARY_T_VOLUME_UOM_CODE;
//    }
//
//    public void setSECONDARY_T_VOLUME_UOM_CODE (String SECONDARY_T_VOLUME_UOM_CODE)
//    {
//        this.SECONDARY_T_VOLUME_UOM_CODE = SECONDARY_T_VOLUME_UOM_CODE;
//    }
//
//    public String getCUSTOMER_UNITIZATION_REQUEST ()
//    {
//        return CUSTOMER_UNITIZATION_REQUEST;
//    }
//
//    public void setCUSTOMER_UNITIZATION_REQUEST (String CUSTOMER_UNITIZATION_REQUEST)
//    {
//        this.CUSTOMER_UNITIZATION_REQUEST = CUSTOMER_UNITIZATION_REQUEST;
//    }
//
//    public String getIS_SPLITTABLE ()
//    {
//        return IS_SPLITTABLE;
//    }
//
//    public void setIS_SPLITTABLE (String IS_SPLITTABLE)
//    {
//        this.IS_SPLITTABLE = IS_SPLITTABLE;
//    }
//
//    public String getBULK_PLAN_GID ()
//    {
//        return BULK_PLAN_GID;
//    }
//
//    public void setBULK_PLAN_GID (String BULK_PLAN_GID)
//    {
//        this.BULK_PLAN_GID = BULK_PLAN_GID;
//    }
//
//    public String getORDER_RELEASE_TYPE_GID ()
//    {
//        return ORDER_RELEASE_TYPE_GID;
//    }
//
//    public void setORDER_RELEASE_TYPE_GID (String ORDER_RELEASE_TYPE_GID)
//    {
//        this.ORDER_RELEASE_TYPE_GID = ORDER_RELEASE_TYPE_GID;
//    }
//
//    public String getIS_LOC_STALE ()
//    {
//        return IS_LOC_STALE;
//    }
//
//    public void setIS_LOC_STALE (String IS_LOC_STALE)
//    {
//        this.IS_LOC_STALE = IS_LOC_STALE;
//    }
//
//    public String getTOTAL_NET_WEIGHT ()
//    {
//        return TOTAL_NET_WEIGHT;
//    }
//
//    public void setTOTAL_NET_WEIGHT (String TOTAL_NET_WEIGHT)
//    {
//        this.TOTAL_NET_WEIGHT = TOTAL_NET_WEIGHT;
//    }
//
//    public String getON_RT_EXECUTION ()
//    {
//        return ON_RT_EXECUTION;
//    }
//
//    public void setON_RT_EXECUTION (String ON_RT_EXECUTION)
//    {
//        this.ON_RT_EXECUTION = ON_RT_EXECUTION;
//    }
//
//    public String getTOTAL_NET_WEIGHT_UOM_CODE ()
//    {
//        return TOTAL_NET_WEIGHT_UOM_CODE;
//    }
//
//    public void setTOTAL_NET_WEIGHT_UOM_CODE (String TOTAL_NET_WEIGHT_UOM_CODE)
//    {
//        this.TOTAL_NET_WEIGHT_UOM_CODE = TOTAL_NET_WEIGHT_UOM_CODE;
//    }
//
//    public String getORDER_RELEASE_XID ()
//    {
//        return ORDER_RELEASE_XID;
//    }
//
//    public void setORDER_RELEASE_XID (String ORDER_RELEASE_XID)
//    {
//        this.ORDER_RELEASE_XID = ORDER_RELEASE_XID;
//    }
//
//    public String getLOC_AMOUNT ()
//    {
//        return LOC_AMOUNT;
//    }
//
//    public void setLOC_AMOUNT (String LOC_AMOUNT)
//    {
//        this.LOC_AMOUNT = LOC_AMOUNT;
//    }
//
//    public String getIS_PRE_ENTERED_PU ()
//    {
//        return IS_PRE_ENTERED_PU;
//    }
//
//    public void setIS_PRE_ENTERED_PU (String IS_PRE_ENTERED_PU)
//    {
//        this.IS_PRE_ENTERED_PU = IS_PRE_ENTERED_PU;
//    }
//
//    public String getATTRIBUTE10 ()
//    {
//        return ATTRIBUTE10;
//    }
//
//    public void setATTRIBUTE10 (String ATTRIBUTE10)
//    {
//        this.ATTRIBUTE10 = ATTRIBUTE10;
//    }
//
//    public String getSECONDARY_T_VOLUME ()
//    {
//        return SECONDARY_T_VOLUME;
//    }
//
//    public void setSECONDARY_T_VOLUME (String SECONDARY_T_VOLUME)
//    {
//        this.SECONDARY_T_VOLUME = SECONDARY_T_VOLUME;
//    }
//
//    public String getTOTAL_NET_WEIGHT_BASE ()
//    {
//        return TOTAL_NET_WEIGHT_BASE;
//    }
//
//    public void setTOTAL_NET_WEIGHT_BASE (String TOTAL_NET_WEIGHT_BASE)
//    {
//        this.TOTAL_NET_WEIGHT_BASE = TOTAL_NET_WEIGHT_BASE;
//    }
//
//    public String getTOTAL_VOLUME ()
//    {
//        return TOTAL_VOLUME;
//    }
//
//    public void setTOTAL_VOLUME (String TOTAL_VOLUME)
//    {
//        this.TOTAL_VOLUME = TOTAL_VOLUME;
//    }
//
//    public String getINDICATOR ()
//    {
//        return INDICATOR;
//    }
//
//    public void setINDICATOR (String INDICATOR)
//    {
//        this.INDICATOR = INDICATOR;
//    }
//
//    public String getSECONDARY_T_VOLUME_BASE ()
//    {
//        return SECONDARY_T_VOLUME_BASE;
//    }
//
//    public void setSECONDARY_T_VOLUME_BASE (String SECONDARY_T_VOLUME_BASE)
//    {
//        this.SECONDARY_T_VOLUME_BASE = SECONDARY_T_VOLUME_BASE;
//    }
//
//    public String getATTRIBUTE_DATE10 ()
//    {
//        return ATTRIBUTE_DATE10;
//    }
//
//    public void setATTRIBUTE_DATE10 (String ATTRIBUTE_DATE10)
//    {
//        this.ATTRIBUTE_DATE10 = ATTRIBUTE_DATE10;
//    }
//
//    public String getSOURCE_LOCATION_GID ()
//    {
//        return SOURCE_LOCATION_GID;
//    }
//
//    public void setSOURCE_LOCATION_GID (String SOURCE_LOCATION_GID)
//    {
//        this.SOURCE_LOCATION_GID = SOURCE_LOCATION_GID;
//    }
//
//    public String getTOTAL_NET_VOLUME_UOM_CODE ()
//    {
//        return TOTAL_NET_VOLUME_UOM_CODE;
//    }
//
//    public void setTOTAL_NET_VOLUME_UOM_CODE (String TOTAL_NET_VOLUME_UOM_CODE)
//    {
//        this.TOTAL_NET_VOLUME_UOM_CODE = TOTAL_NET_VOLUME_UOM_CODE;
//    }
//
//    public String getIS_CONSOLIDATE_OR_EQUIPMENT ()
//    {
//        return IS_CONSOLIDATE_OR_EQUIPMENT;
//    }
//
//    public void setIS_CONSOLIDATE_OR_EQUIPMENT (String IS_CONSOLIDATE_OR_EQUIPMENT)
//    {
//        this.IS_CONSOLIDATE_OR_EQUIPMENT = IS_CONSOLIDATE_OR_EQUIPMENT;
//    }
//
//    public String getTOTAL_WEIGHT_BASE ()
//    {
//        return TOTAL_WEIGHT_BASE;
//    }
//
//    public void setTOTAL_WEIGHT_BASE (String TOTAL_WEIGHT_BASE)
//    {
//        this.TOTAL_WEIGHT_BASE = TOTAL_WEIGHT_BASE;
//    }
//
//    public String getIMPORT_LICENSE_REQUIRED ()
//    {
//        return IMPORT_LICENSE_REQUIRED;
//    }
//
//    public void setIMPORT_LICENSE_REQUIRED (String IMPORT_LICENSE_REQUIRED)
//    {
//        this.IMPORT_LICENSE_REQUIRED = IMPORT_LICENSE_REQUIRED;
//    }
//
//    public String getLATE_PICKUP_DATE ()
//    {
//        return LATE_PICKUP_DATE;
//    }
//
//    public void setLATE_PICKUP_DATE (String LATE_PICKUP_DATE)
//    {
//        this.LATE_PICKUP_DATE = LATE_PICKUP_DATE;
//    }
//
//    public String getTOTAL_DECLARED_VALUE ()
//    {
//        return TOTAL_DECLARED_VALUE;
//    }
//
//    public void setTOTAL_DECLARED_VALUE (String TOTAL_DECLARED_VALUE)
//    {
//        this.TOTAL_DECLARED_VALUE = TOTAL_DECLARED_VALUE;
//    }
//
//    public String getATTRIBUTE_DATE9 ()
//    {
//        return ATTRIBUTE_DATE9;
//    }
//
//    public void setATTRIBUTE_DATE9 (String ATTRIBUTE_DATE9)
//    {
//        this.ATTRIBUTE_DATE9 = ATTRIBUTE_DATE9;
//    }
//
//    public String getASSIGNED_ITINERARY_GID ()
//    {
//        return ASSIGNED_ITINERARY_GID;
//    }
//
//    public void setASSIGNED_ITINERARY_GID (String ASSIGNED_ITINERARY_GID)
//    {
//        this.ASSIGNED_ITINERARY_GID = ASSIGNED_ITINERARY_GID;
//    }
//
//    public String getTOTAL_NET_VOLUME_BASE ()
//    {
//        return TOTAL_NET_VOLUME_BASE;
//    }
//
//    public void setTOTAL_NET_VOLUME_BASE (String TOTAL_NET_VOLUME_BASE)
//    {
//        this.TOTAL_NET_VOLUME_BASE = TOTAL_NET_VOLUME_BASE;
//    }
//
//    public String getTOTAL_ITEM_PACKAGE_COUNT ()
//    {
//        return TOTAL_ITEM_PACKAGE_COUNT;
//    }
//
//    public void setTOTAL_ITEM_PACKAGE_COUNT (String TOTAL_ITEM_PACKAGE_COUNT)
//    {
//        this.TOTAL_ITEM_PACKAGE_COUNT = TOTAL_ITEM_PACKAGE_COUNT;
//    }
//
//    public String getIS_TOPOFF ()
//    {
//        return IS_TOPOFF;
//    }
//
//    public void setIS_TOPOFF (String IS_TOPOFF)
//    {
//        this.IS_TOPOFF = IS_TOPOFF;
//    }
//
//    public String getTOTAL_DECLARED_VALUE_BASE ()
//    {
//        return TOTAL_DECLARED_VALUE_BASE;
//    }
//
//    public void setTOTAL_DECLARED_VALUE_BASE (String TOTAL_DECLARED_VALUE_BASE)
//    {
//        this.TOTAL_DECLARED_VALUE_BASE = TOTAL_DECLARED_VALUE_BASE;
//    }
//
//    public String getTOTAL_SHIP_UNIT_COUNT ()
//    {
//        return TOTAL_SHIP_UNIT_COUNT;
//    }
//
//    public void setTOTAL_SHIP_UNIT_COUNT (String TOTAL_SHIP_UNIT_COUNT)
//    {
//        this.TOTAL_SHIP_UNIT_COUNT = TOTAL_SHIP_UNIT_COUNT;
//    }
//
//    public String getSECONDARY_T_WEIGHT_UOM_CODE ()
//    {
//        return SECONDARY_T_WEIGHT_UOM_CODE;
//    }
//
//    public void setSECONDARY_T_WEIGHT_UOM_CODE (String SECONDARY_T_WEIGHT_UOM_CODE)
//    {
//        this.SECONDARY_T_WEIGHT_UOM_CODE = SECONDARY_T_WEIGHT_UOM_CODE;
//    }
//
//    public String getMUST_SHIP_THRU_X_DOCK ()
//    {
//        return MUST_SHIP_THRU_X_DOCK;
//    }
//
//    public void setMUST_SHIP_THRU_X_DOCK (String MUST_SHIP_THRU_X_DOCK)
//    {
//        this.MUST_SHIP_THRU_X_DOCK = MUST_SHIP_THRU_X_DOCK;
//    }
//
//    public String getIS_LOC_REQUIRED ()
//    {
//        return IS_LOC_REQUIRED;
//    }
//
//    public void setIS_LOC_REQUIRED (String IS_LOC_REQUIRED)
//    {
//        this.IS_LOC_REQUIRED = IS_LOC_REQUIRED;
//    }
//
//    public String getDOMAIN_NAME ()
//    {
//        return DOMAIN_NAME;
//    }
//
//    public void setDOMAIN_NAME (String DOMAIN_NAME)
//    {
//        this.DOMAIN_NAME = DOMAIN_NAME;
//    }
//
//    public String getDELIVERY_IS_APPT ()
//    {
//        return DELIVERY_IS_APPT;
//    }
//
//    public void setDELIVERY_IS_APPT (String DELIVERY_IS_APPT)
//    {
//        this.DELIVERY_IS_APPT = DELIVERY_IS_APPT;
//    }
//
//    public String getMUST_SHIP_THRU_POOL ()
//    {
//        return MUST_SHIP_THRU_POOL;
//    }
//
//    public void setMUST_SHIP_THRU_POOL (String MUST_SHIP_THRU_POOL)
//    {
//        this.MUST_SHIP_THRU_POOL = MUST_SHIP_THRU_POOL;
//    }
//
//    public String getMUST_SHIP_DIRECT ()
//    {
//        return MUST_SHIP_DIRECT;
//    }
//
//    public void setMUST_SHIP_DIRECT (String MUST_SHIP_DIRECT)
//    {
//        this.MUST_SHIP_DIRECT = MUST_SHIP_DIRECT;
//    }
//
//    public String getTOTAL_WEIGHT ()
//    {
//        return TOTAL_WEIGHT;
//    }
//
//    public void setTOTAL_WEIGHT (String TOTAL_WEIGHT)
//    {
//        this.TOTAL_WEIGHT = TOTAL_WEIGHT;
//    }
//
//    public String getTOTAL_VOLUME_BASE ()
//    {
//        return TOTAL_VOLUME_BASE;
//    }
//
//    public void setTOTAL_VOLUME_BASE (String TOTAL_VOLUME_BASE)
//    {
//        this.TOTAL_VOLUME_BASE = TOTAL_VOLUME_BASE;
//    }
//
//    public String getTOTAL_WEIGHT_UOM_CODE ()
//    {
//        return TOTAL_WEIGHT_UOM_CODE;
//    }
//
//    public void setTOTAL_WEIGHT_UOM_CODE (String TOTAL_WEIGHT_UOM_CODE)
//    {
//        this.TOTAL_WEIGHT_UOM_CODE = TOTAL_WEIGHT_UOM_CODE;
//    }
//
//    public String getRELEASE_METHOD_GID ()
//    {
//        return RELEASE_METHOD_GID;
//    }
//
//    public void setRELEASE_METHOD_GID (String RELEASE_METHOD_GID)
//    {
//        this.RELEASE_METHOD_GID = RELEASE_METHOD_GID;
//    }
//
//    public String getIS_KNOWN_SHIPPER ()
//    {
//        return IS_KNOWN_SHIPPER;
//    }
//
//    public void setIS_KNOWN_SHIPPER (String IS_KNOWN_SHIPPER)
//    {
//        this.IS_KNOWN_SHIPPER = IS_KNOWN_SHIPPER;
//    }
//
//    @Override
//    public String toString()
//    {
//        return "ClassPojo [PICKUP_IS_APPT = "+PICKUP_IS_APPT+", TRANSPORT_HANDLING_UNIT_GID = "+TRANSPORT_HANDLING_UNIT_GID+", PRIORITY = "+PRIORITY+", TOTAL_NET_VOLUME = "+TOTAL_NET_VOLUME+", ORDER_RELEASE_GID = "+ORDER_RELEASE_GID+", OTM_VERSION = "+OTM_VERSION+", BUNDLING_TYPE = "+BUNDLING_TYPE+", EARLY_PICKUP_DATE = "+EARLY_PICKUP_DATE+", LOC_AMOUNT_BASE = "+LOC_AMOUNT_BASE+", TOTAL_VOLUME_UOM_CODE = "+TOTAL_VOLUME_UOM_CODE+", SECONDARY_T_WEIGHT = "+SECONDARY_T_WEIGHT+", INSPECTION_REQUIRED = "+INSPECTION_REQUIRED+", MARKED_FOR_PURGE = "+MARKED_FOR_PURGE+", ATTRIBUTE1 = "+ATTRIBUTE1+", IS_TEMPLATE = "+IS_TEMPLATE+", DEST_LOCATION_GID = "+DEST_LOCATION_GID+", SECONDARY_T_WEIGHT_BASE = "+SECONDARY_T_WEIGHT_BASE+", DUTY_PAID = "+DUTY_PAID+", ATTRIBUTE9 = "+ATTRIBUTE9+", ATTRIBUTE8 = "+ATTRIBUTE8+", LOC_AMOUNT_CURRENCY_GID = "+LOC_AMOUNT_CURRENCY_GID+", ATTRIBUTE7 = "+ATTRIBUTE7+", TOTAL_DECLARED_VALUE_GID = "+TOTAL_DECLARED_VALUE_GID+", SECONDARY_T_VOLUME_UOM_CODE = "+SECONDARY_T_VOLUME_UOM_CODE+", CUSTOMER_UNITIZATION_REQUEST = "+CUSTOMER_UNITIZATION_REQUEST+", IS_SPLITTABLE = "+IS_SPLITTABLE+", BULK_PLAN_GID = "+BULK_PLAN_GID+", ORDER_RELEASE_TYPE_GID = "+ORDER_RELEASE_TYPE_GID+", IS_LOC_STALE = "+IS_LOC_STALE+", TOTAL_NET_WEIGHT = "+TOTAL_NET_WEIGHT+", ON_RT_EXECUTION = "+ON_RT_EXECUTION+", TOTAL_NET_WEIGHT_UOM_CODE = "+TOTAL_NET_WEIGHT_UOM_CODE+", ORDER_RELEASE_XID = "+ORDER_RELEASE_XID+", LOC_AMOUNT = "+LOC_AMOUNT+", IS_PRE_ENTERED_PU = "+IS_PRE_ENTERED_PU+", ATTRIBUTE10 = "+ATTRIBUTE10+", SECONDARY_T_VOLUME = "+SECONDARY_T_VOLUME+", TOTAL_NET_WEIGHT_BASE = "+TOTAL_NET_WEIGHT_BASE+", TOTAL_VOLUME = "+TOTAL_VOLUME+", INDICATOR = "+INDICATOR+", SECONDARY_T_VOLUME_BASE = "+SECONDARY_T_VOLUME_BASE+", ATTRIBUTE_DATE10 = "+ATTRIBUTE_DATE10+", SOURCE_LOCATION_GID = "+SOURCE_LOCATION_GID+", TOTAL_NET_VOLUME_UOM_CODE = "+TOTAL_NET_VOLUME_UOM_CODE+", IS_CONSOLIDATE_OR_EQUIPMENT = "+IS_CONSOLIDATE_OR_EQUIPMENT+", TOTAL_WEIGHT_BASE = "+TOTAL_WEIGHT_BASE+", IMPORT_LICENSE_REQUIRED = "+IMPORT_LICENSE_REQUIRED+", LATE_PICKUP_DATE = "+LATE_PICKUP_DATE+", TOTAL_DECLARED_VALUE = "+TOTAL_DECLARED_VALUE+", ATTRIBUTE_DATE9 = "+ATTRIBUTE_DATE9+", ASSIGNED_ITINERARY_GID = "+ASSIGNED_ITINERARY_GID+", TOTAL_NET_VOLUME_BASE = "+TOTAL_NET_VOLUME_BASE+", TOTAL_ITEM_PACKAGE_COUNT = "+TOTAL_ITEM_PACKAGE_COUNT+", IS_TOPOFF = "+IS_TOPOFF+", TOTAL_DECLARED_VALUE_BASE = "+TOTAL_DECLARED_VALUE_BASE+", TOTAL_SHIP_UNIT_COUNT = "+TOTAL_SHIP_UNIT_COUNT+", SECONDARY_T_WEIGHT_UOM_CODE = "+SECONDARY_T_WEIGHT_UOM_CODE+", MUST_SHIP_THRU_X_DOCK = "+MUST_SHIP_THRU_X_DOCK+", IS_LOC_REQUIRED = "+IS_LOC_REQUIRED+", DOMAIN_NAME = "+DOMAIN_NAME+", DELIVERY_IS_APPT = "+DELIVERY_IS_APPT+", MUST_SHIP_THRU_POOL = "+MUST_SHIP_THRU_POOL+", MUST_SHIP_DIRECT = "+MUST_SHIP_DIRECT+", TOTAL_WEIGHT = "+TOTAL_WEIGHT+", TOTAL_VOLUME_BASE = "+TOTAL_VOLUME_BASE+", TOTAL_WEIGHT_UOM_CODE = "+TOTAL_WEIGHT_UOM_CODE+", RELEASE_METHOD_GID = "+RELEASE_METHOD_GID+", IS_KNOWN_SHIPPER = "+IS_KNOWN_SHIPPER+"]";
//    }
//}
//			
