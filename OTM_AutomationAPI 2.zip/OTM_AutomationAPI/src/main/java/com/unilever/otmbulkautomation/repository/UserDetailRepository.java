package com.unilever.otmbulkautomation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unilever.otmbulkautomation.domain.UserDetail;

public interface UserDetailRepository extends JpaRepository<UserDetail, Long> {

}
