package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "REGION_DETAIL")
public class RegionDetail
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_GID")
    private String orderGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
    private String destLocGid;

	@JacksonXmlProperty(isAttribute = true, localName = "PLAN_TO_LOCATION_GID")
    private String planToLocGid;
	@JacksonXmlProperty(isAttribute = true, localName = "REGION_GID")
    private String regionGid;
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_GID")
    private String locGid;
	;
	
}