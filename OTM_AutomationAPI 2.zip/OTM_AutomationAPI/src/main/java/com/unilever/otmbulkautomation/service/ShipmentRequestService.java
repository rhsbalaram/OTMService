package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationSpecifications;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentResponseSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;

@Service
public class ShipmentRequestService {
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	
	@Value("${otm.shipment.details.getQuery}")
	private String shipmentDetailsQuery;

	
	@Autowired
	CommonUtils commonUtil;
	
	public List<ShipmentCreationRequest> getCreatedShipments(List<String> sourceLocations, String shipment, String shipmentType,
			String requestDate, String requestId, String requestType) {
		if(CollectionUtils.isEmpty(sourceLocations)/*|| StringUtils.isEmpty(shipment)*/) {
			throw new IllegalStateException("DepotIds and shipment required");
		}
		Specification<ShipmentCreationRequest> query;
		query = ShipmentCreationSpecifications.withdepotId(sourceLocations);//.and(ShipmentCreationSpecifications.withShipment(shipment));
		if(StringUtils.isNotEmpty(shipmentType)) {
			query = query.and(ShipmentCreationSpecifications.withShipmentType(shipmentType));
		}
		if(StringUtils.isNotEmpty(requestDate)) {
			query = query.and(ShipmentCreationSpecifications.withShipmentDate(requestDate));
		}
		if(StringUtils.isNotEmpty(requestId)) {
			query = query.and(ShipmentCreationSpecifications.withRequestId(requestId));
		}
		if(StringUtils.isNotEmpty(requestType)) {
			query = query.and(ShipmentCreationSpecifications.withRequestType(requestType));
		}
		return repository.findAll(Specification.where(query));
	}
	
	public SchemaWrapper getShipmentDetailsFromOtm(String requestId) {
		if (Objects.nonNull(requestId)) {
			String query = MessageFormat.format(shipmentDetailsQuery, new Object[] { requestId });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentResponseSchemaWrapper.class);
		} else {
			return null;
		}
	}
}
