package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentApprovalService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.approvalShipment.query}")
	private String shipmentApprovalGetQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	OTMService otmservice;
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
		
	public SchemaWrapper getApprovalShipmentsFromOtm(List<String> sourceLocationGIDs, List<String> shipmentType, String module) {
		
		if (Objects.nonNull(sourceLocationGIDs)) {
			String query = "";
			if(!CollectionUtils.isEmpty(sourceLocationGIDs)) {
				query = MessageFormat.format(shipmentApprovalGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2) , commonUtil.getCommaDelimiterString(shipmentType) });
			} else {
				return null;
			}
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentApprovalSchemaWrapper.class);
			 validations.valideShipmentApproval(dbServletMappedPojo, module);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public List<ShipmentApproval> postShipmentApproval(List<ShipmentApproval> approvals, String status, String userId){
		StringBuffer state = new StringBuffer();
		if(OTMConstants.APPROVED.equals(status)) {
			 state.append("SA");
		} else {
			state.append("SR");
		}
		approvals.forEach(approval -> {
			approval.setStatus(false);
			String transmission = otmservice.postStatusToOTM(approval.getShipmentGID(), status, approval.getAttribute11(), userId);
			//String transmission = dbServletRestUtil.postShipmentStatusToWMServlet(approval.getShipmentGID(), state.toString(), dateUtil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));
			if(StringUtils.isNumeric(transmission)) {
				approval.setStatus(true);
				//repository.updateShipmentApprovalStatus(approval.getAttribute11(),
				//		status, dateUtil.getCurrentISTLocalDateTime());
			} 
		});
		return approvals;
	}
	
	public List<ShipmentApproval> postAssignShipmentApproval(List<ShipmentApproval> approvals, String status, String userId){
		approvals.forEach(approval -> {
			approval.setStatus(false);
			String transmission = otmservice.postAssignStatusToOTM(approval.getShipmentGID(), status, approval.getAttribute11(), userId);
			//String transmission = dbServletRestUtil.postShipmentStatusToWMServlet(approval.getShipmentGID(), state.toString(), dateUtil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));
			if(StringUtils.isNumeric(transmission)) {
				approval.setStatus(true);
				//repository.updateShipmentApprovalStatus(approval.getAttribute11(),
				//		status, dateUtil.getCurrentISTLocalDateTime());
			} 
		});
		return approvals;
	}
	
}
