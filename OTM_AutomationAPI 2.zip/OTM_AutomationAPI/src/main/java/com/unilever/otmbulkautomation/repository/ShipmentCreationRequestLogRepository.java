package com.unilever.otmbulkautomation.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;

public interface ShipmentCreationRequestLogRepository extends JpaRepository<ShipmentCreationRequestLog, Long>, JpaSpecificationExecutor<ShipmentCreationRequest> {
	public ShipmentCreationRequestLog findByRequestNumber(String requestNumber);
	
	@Query("select s from ShipmentCreationRequestLog s where s.requestNumber in (:requestNumber)")
	public List<ShipmentCreationRequestLog> findByRequestNumberIn(@Param("requestNumber") Set<String> requestNumber);
	
}
