package com.unilever.otmbulkautomation.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.service.ShipmentAssignService;
import com.unilever.otmbulkautomation.service.ShipmentRequestService;

@RestController
@RequestMapping("/user/shipment")
public class ShipmentAssignController {
	
	@Autowired
	ShipmentAssignService shipmentAssignService;
	
	@Autowired
	ShipmentRequestService shipmentRequestService;
	
	
	@PostMapping("/assign/search")
	public ResponseEntity<Object> searchShipmentForAssign(@RequestBody OrderReleasesSchemaWrapper orders) throws Exception{
		SchemaWrapper orderReleasesFromOtm = shipmentAssignService.getShipmentsFromOtm(orders);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}
	
	@PostMapping("/assign/validate")
	public ResponseEntity<Object> getShipmentForAssign(@RequestBody OrderReleasesSchemaWrapper orders) throws Exception{
		String orderReleasesFromOtm = shipmentAssignService.validateShipmentsFromOtm(orders);
		Map<String,String> md = new HashMap();
		md.put("result", orderReleasesFromOtm);
		return new ResponseEntity(md,HttpStatus.OK);
	}
	
	@PostMapping("/assign/submit")
	public ResponseEntity<Object> submitShipmentForAssign(@RequestBody OrderReleasesSchemaWrapper orders) throws Exception{
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		 ShipmentCreationRequest createOrderAssginForShipment = shipmentAssignService.createOrderAssginForShipment(username, orders);
		return new ResponseEntity(createOrderAssginForShipment,HttpStatus.OK);
	}
	
	
	@GetMapping(value = "/assigned")
	public ResponseEntity getShipments(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("shipment") String shipment, @RequestParam("shipmentType") String shipmentType, @RequestParam("requestDate") String requestDate,  @RequestParam("requestId") String requestId) {
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		List<ShipmentCreationRequest> createdShipments = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Assign");
		return new ResponseEntity<>(createdShipments, HttpStatus.OK);
	}
	
	@GetMapping(value = "/modified")
	public ResponseEntity getModifiedShipments(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("shipment") String shipment, @RequestParam("shipmentType") String shipmentType, @RequestParam("requestDate") String requestDate,  @RequestParam("requestId") String requestId) {
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		List<ShipmentCreationRequest> reqs = new ArrayList<ShipmentCreationRequest>();
		List<ShipmentCreationRequest> createdShipments5 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Assign");
		List<ShipmentCreationRequest> createdShipments4 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Unassign");
		List<ShipmentCreationRequest> createdShipments1 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Truck Type Change");
		List<ShipmentCreationRequest> createdShipments2 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "TSP Change");
		List<ShipmentCreationRequest> createdShipments3 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Truck Type & TSP Change");
		reqs.addAll(createdShipments1);
		reqs.addAll(createdShipments2);
		reqs.addAll(createdShipments3);
		reqs.addAll(createdShipments4);
		reqs.addAll(createdShipments5);

		return new ResponseEntity<>(reqs, HttpStatus.OK);
	}
	
	@GetMapping(value = "/assigned/detail")
	public ResponseEntity getShipmentdetails(@RequestParam("requestId") String requestId) {
		SchemaWrapper shipmentDetailsFromOtm = shipmentAssignService.getShipmentAssignDetailsFromOtm(requestId);
		return new ResponseEntity<>(shipmentDetailsFromOtm, HttpStatus.OK);
	}

}
