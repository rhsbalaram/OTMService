//package com.unilever.otmbulkautomation.controller;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.unilever.otmbulkautomation.schema.SchemaWrapper;
//import com.unilever.otmbulkautomation.schema.ShipmentApproval;
//import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
//import com.unilever.otmbulkautomation.schema.ShipmentCancellationSchemaWrapper;
//import com.unilever.otmbulkautomation.service.ShipmentApprovalService;
//import com.unilever.otmbulkautomation.service.ShipmentCancellationService;
//
//@RestController
//@RequestMapping("admin/shipment/cancel")
//public class ShipmentCancelApprovalController {
//	
//	@Autowired
//	ShipmentCancellationService shipmentCancellationService;
//	
//	
////	@GetMapping("/approve")
////	public ResponseEntity<Object> getShipmentApproval(@RequestParam("sourceLocation") Set<String> sourceLocations) throws Exception{
////		List<String> sourceLocation = new ArrayList<>(sourceLocations);
////		SchemaWrapper orderReleasesFromOtm = shipmentApprovalService.getApprovalShipmentsFromOtm(sourceLocation);
////		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
////	}
//	
//	@PostMapping("/approve")
//	public ResponseEntity<Object> postShipmentApproval(@RequestBody ShipmentCancellationSchemaWrapper shipments) throws Exception{
//	String status = shipmentCancellationService.postCancellationByShipmentId(shipments);
//		shipments.setStatus(status);
//		 return new ResponseEntity(shipments,HttpStatus.OK);
//	}
//
//}
