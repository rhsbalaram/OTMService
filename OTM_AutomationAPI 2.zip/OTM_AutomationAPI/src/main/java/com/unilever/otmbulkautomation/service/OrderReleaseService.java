package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class OrderReleaseService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.orderrelease.type.getQuery}")
	private String orderReleaseTypeGetQuery;
	
	@Value("${otm.orderrelease.type.ids.getQuery}")
	private String orderReleaseTypeAndIdsGetQuery;
	
	@Value("${otm.orderrelease.ids.getQuery}")
	private String orderReleaseIdsGetQuery;
	
	
	@Value("${otm.orderrelease.unassign.getQuery}")
	private String orderReleaseUnassignGetQuery;
	
	@Value("${otm.orderrelease.unassignApproval.getQuery}")
	private String orderReleaseUnassignApprovalGetQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	public SchemaWrapper getOrderReleasesFromOtm(List<String> sourceLocationGIDs, String orderReleaseTypeGID, List<String> orderReleaseList) {
		if (Objects.nonNull(sourceLocationGIDs)) {
			String query = "";
			if(StringUtils.isNotBlank(orderReleaseTypeGID) && !CollectionUtils.isEmpty(orderReleaseList)) {
				query = MessageFormat.format(orderReleaseTypeAndIdsGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1), orderReleaseTypeGID, commonUtil.getCommaDelimiterString(orderReleaseList) });
			} else if(StringUtils.isNotBlank(orderReleaseTypeGID)) {
				//StringUtils.repeat(" ",(int)(Math.random()*100))
				String randomNumberQuery = "(select '"+Math.random()+"' from dual) AS RANDOM_TEXT,";
				query = MessageFormat.format(orderReleaseTypeGetQuery,
						new Object[] { "", commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1),  orderReleaseTypeGID});
			} else if(!CollectionUtils.isEmpty(orderReleaseList)) {
				query = MessageFormat.format(orderReleaseIdsGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1),  commonUtil.getCommaDelimiterString(orderReleaseList) });
			} else {
				return null;
			}
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  OrderReleasesSchemaWrapper.class);
			 validations.OtmExtractDataValidations(dbServletMappedPojo, orderReleaseTypeGID);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public SchemaWrapper getOrderReleasesFromOtmForAssignment(List<String> sourceLocationGIDs, String orderReleaseTypeGID, List<String> orderReleaseList) {
		if (Objects.nonNull(sourceLocationGIDs)) {
			String query = "";
			if(StringUtils.isNotBlank(orderReleaseTypeGID) && !CollectionUtils.isEmpty(orderReleaseList)) {
				query = MessageFormat.format(orderReleaseTypeAndIdsGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1), orderReleaseTypeGID, commonUtil.getCommaDelimiterString(orderReleaseList) });
			} else if(StringUtils.isNotBlank(orderReleaseTypeGID)) {
				//StringUtils.repeat(" ",(int)(Math.random()*100))
				String randomNumberQuery = "(select '"+Math.random()+"' from dual) AS RANDOM_TEXT,";
				query = MessageFormat.format(orderReleaseTypeGetQuery,
						new Object[] { "", commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1),  orderReleaseTypeGID});
			} else if(!CollectionUtils.isEmpty(orderReleaseList)) {
				query = MessageFormat.format(orderReleaseIdsGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1),  commonUtil.getCommaDelimiterString(orderReleaseList) });
			} else {
				return null;
			}
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  OrderReleasesSchemaWrapper.class);
			 validations.assignValidation(dbServletMappedPojo, orderReleaseTypeGID);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public SchemaWrapper getOrderReleasesFromOtmForUnAssignment(List<String> sourceLocationGIDs, String orderReleaseTypeGID, List<String> orderReleaseList) {
		if (Objects.nonNull(sourceLocationGIDs) && StringUtils.isNotBlank(orderReleaseTypeGID)) {
			String query = "";
			String ordList = "";
			if(!CollectionUtils.isEmpty(orderReleaseList)) {
				 ordList = "AND ORL.ORDER_RELEASE_XID IN ("+commonUtil.getCommaDelimiterString(orderReleaseList)+")";
			}
			query = MessageFormat.format(orderReleaseUnassignGetQuery,
					new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), dateUtil.getISTDateMinusDays(2), dateUtil.getISTDatePlusDays(1), orderReleaseTypeGID, ordList });
		
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  OrderReleasesSchemaWrapper.class);
			 validations.unassignValidation(dbServletMappedPojo, orderReleaseTypeGID);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public SchemaWrapper getOrderReleasesFromOtmForUnAssignmentApproval(List<String> orderReleaseList) {
		String query = "";
		String ordList = "";
		if (!CollectionUtils.isEmpty(orderReleaseList)) {
		
		query = MessageFormat.format(orderReleaseUnassignApprovalGetQuery,
				new Object[] { commonUtil.getCommaDelimiterString(orderReleaseList) });

		String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
		SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
				OrderReleasesSchemaWrapper.class);
		return dbServletMappedPojo;
		} return null;

	}
	
}
