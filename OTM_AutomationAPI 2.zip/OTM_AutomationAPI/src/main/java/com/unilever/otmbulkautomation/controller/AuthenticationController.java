package com.unilever.otmbulkautomation.controller;

import static org.springframework.http.ResponseEntity.ok;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.model.AuthenticationRequest;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.security.JwtTokenProvider;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	JwtTokenProvider jwtTokenProvider;

	@Autowired
	UserRepository users;

	@PostMapping("/signin")
	public ResponseEntity signin(@RequestBody AuthenticationRequest data) throws BadCredentialsException {

		try {
			String username = data.getUsername();
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(username, data.getSecretId() + data.getSecretKey()));
			String role = this.users.findByUsername(username)
					.orElseThrow(() -> new UsernameNotFoundException("Username " + username + "not found")).getRole();
			String token = jwtTokenProvider.createToken(username, role);
			Map<Object, Object> model = new HashMap<>();
			model.put("username", username);
			model.put("token", token);
			model.put("role", role);
			return ok(model);
		} catch (AuthenticationException e) {

			throw new BadCredentialsException("Invalid username/password supplied");
		}
	}

	@PostMapping(value = "/login", consumes = { MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			MediaType.MULTIPART_FORM_DATA_VALUE })
	public void login(AuthenticationRequest data, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws BadCredentialsException, IOException {

		try {
			String username = data.getUsername();
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(username, data.getSecretId() + data.getSecretKey()));
			String role = this.users.findByUsername(username)
					.orElseThrow(() -> new UsernameNotFoundException("Username " + username + "not found")).getRole();
			String token = jwtTokenProvider.createToken(username, role);
			String ip = httpServletRequest.getScheme()+"://"+httpServletRequest.getServerName() + "/OTMAutomate?token=" + token + "&username=" + username + "&role="
					+ role;
			//httpServletResponse.sets(HttpStatus.PERMANENT_REDIRECT);
			httpServletResponse.sendRedirect(ip);
		} catch (AuthenticationException e) {
			throw new BadCredentialsException("Invalid username/password supplied");
		}
	}

	@PostMapping(value = "/login")
	public void jsonLogin(@RequestBody AuthenticationRequest data, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws BadCredentialsException, IOException {
		login(data, httpServletRequest, httpServletResponse);
	}

	@GetMapping(value = "/login")
	public void getLogin(@RequestParam("username") String username, @RequestParam("secretId") String secretId,
			@RequestParam("secretKey") String secretKey, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) throws BadCredentialsException, IOException {
		AuthenticationRequest data = new AuthenticationRequest();
		data.setSecretId(secretId);
		data.setSecretKey(secretKey);
		data.setUsername(username);
		login(data, httpServletRequest, httpServletResponse);
	}

}
