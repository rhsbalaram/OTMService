package com.unilever.otmbulkautomation.schema;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "ORDER_RELEASE_REFNUM")
public class OrderReleaseRefnum
{
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_REFNUM_VALUE")
    private String orderReleaseRefnumValue;
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_REFNUM_QUAL_GID")
	private String orderReleaseRefnumQualGid;
	@JacksonXmlProperty(isAttribute = true, localName = "DOMAIN_NAME")
    private String domainName;
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_GID")
    private String orderReleaseGid;
}