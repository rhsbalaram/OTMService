package com.unilever.otmbulkautomation.schema;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;
@Data
@JacksonXmlRootElement(localName="TRANSACTION_SET")
public class LocationRefnumSchemaWrapper extends SchemaWrapper{
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "LOCATION_REFNUM")
    private List<LocationRefNum> locationRefnums;
}