package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "ORDER_RELEASE")
public class ShipmentResponse
{
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE")
    private String TOTAL_DECLARED_VALUE;

	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_ID")
    private String SHIPMENT_ID;

	@JacksonXmlProperty(isAttribute = true, localName = "ATTRIBUTE1")
    private String ATTRIBUTE1;

	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_REFNUM_VALUE")
    private String ORDER_RELEASE_REFNUM_VALUE;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
    private String DEST_LOCATION_GID;

	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_ATTRIBUTE1")
    private String LOCATION_ATTRIBUTE1;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME")
    private String TOTAL_VOLUME;

	@JacksonXmlProperty(isAttribute = true, localName = "DESTINATION_LOCATION_NAME")
    private String DESTINATION_LOCATION_NAME;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE_GID")
    private String TOTAL_DECLARED_VALUE_GID;

	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_STATUS")
    private String SHIPMENT_STATUS;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_GID")
    private String SOURCE_LOCATION_GID;

	@JacksonXmlProperty(isAttribute = true, localName = "EARLY_PICKUP_DATE")
    private String EARLY_PICKUP_DATE;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME_UOM_CODE")
    private String TOTAL_VOLUME_UOM_CODE;

	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_TYPE_GID")
    private String ORDER_RELEASE_TYPE_GID;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT")
    private String TOTAL_WEIGHT;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT_UOM_CODE")
    private String TOTAL_WEIGHT_UOM_CODE;

	@JacksonXmlProperty(isAttribute = true, localName = "LATE_PICKUP_DATE")
    private String LATE_PICKUP_DATE;

	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_STATUS")
    private String ORDER_STATUS;

	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_XID")
    private String ORDER_RELEASE_XID;
    
	@JacksonXmlProperty(isAttribute = true, localName = "SHIP_WITH_GROUP")
    private String SHIP_WITH_GROUP;

	@JacksonXmlProperty(isAttribute = true, localName = "LATE_DELIVERY_DATE")
    private String LATE_DELIVERY_DATE;

	@JacksonXmlProperty(isAttribute = true, localName = "REMARK")
    private String REMARK;
	
	@JacksonXmlProperty(isAttribute = true, localName = "CLUSTER_ID")
    private String CLUSTER_ID;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOWN")
    private String town;
	
	@JacksonXmlProperty(isAttribute = true, localName = "EQUIPMENT_ID")
    private String equipmentId;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SPLIT_STATUS")
    private String splitStatus;
}