package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "DUAL")
public class Dual
{
	@JacksonXmlProperty(isAttribute = true, localName = "OUTPUT")
    private String output;

}
