package com.unilever.otmbulkautomation.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.unilever.otmbulkautomation.domain.User;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);
    
	@Query("select u from User u JOIN u.locations l where l.depotId in (:sourceLocations) and l.shipmentType =:shipmentType and u.role =:role")
    List<User> findBySourceLocation(@Param("sourceLocations") List<String> sourceLocations, @Param("role") String role, @Param("shipmentType") String shipmentType);
	
}
