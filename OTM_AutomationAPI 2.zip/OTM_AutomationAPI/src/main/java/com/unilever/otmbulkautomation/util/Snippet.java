//package com.unilever.otmbulkautomation.util;
//
//import java.io.BufferedReader;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.net.URL;
//import java.net.URLEncoder;
//
//import javax.net.ssl.HttpsURLConnection;
//import javax.xml.bind.DatatypeConverter;
//
//public class Snippet {
//	public static void main(String[] args) {
//	    final Client client = new Client("ULF.INTEGRATION", "FusionQAXT@12", "");
//	    String sql ="SELECT     ORL.ORDER_RELEASE_GID,ORL.ORDER_RELEASE_TYPE_GID,ORR.STATUS_TYPE_GID,ORL.EARLY_PICKUP_DATE,ORL.LATE_PICKUP_DATE,ORL.LATE_DELIVERY_DATE,ORR.STATUS_VALUE_GID,ORL.SOURCE_LOCATION_GID,(SELECT LOCATION_NAME FROM LOCATION WHERE LOCATION_GID = ORL.SOURCE_LOCATION_GID) AS SOURCE_LOCATION_NAME,ORL.DEST_LOCATION_GID,(SELECT LOCATION_NAME FROM LOCATION WHERE LOCATION_GID = ORL.DEST_LOCATION_GID) AS DESTINATION_LOCATION_NAME, (SELECT ATTRIBUTE1 FROM LOCATION WHERE LOCATION_GID = ORL.DEST_LOCATION_GID) AS LOCATION_ATTRIBUTE1,(SELECT CITY FROM LOCATION WHERE LOCATION_GID = ORL.DEST_LOCATION_GID) AS CITY,ORL.SHIP_WITH_GROUP,ORL.ATTRIBUTE1,ORL.TOTAL_WEIGHT,ORL.TOTAL_WEIGHT_UOM_CODE, ORL.TOTAL_VOLUME, ORL.TOTAL_VOLUME_UOM_CODE,ORL.TOTAL_DECLARED_VALUE,ORL.TOTAL_DECLARED_VALUE_GID, (SELECT ORDER_RELEASE_REFNUM_VALUE FROM ORDER_RELEASE_REFNUM WHERE ORDER_RELEASE_REFNUM_QUAL_GID = 'ULF.MAX_SERVICE_TIME' AND ORDER_RELEASE_GID = ORL.ORDER_RELEASE_GID AND ROWNUM = 1) AS MAX_SERVICE_TIME, (SELECT ORDER_RELEASE_REFNUM_VALUE FROM ORDER_RELEASE_REFNUM WHERE ORDER_RELEASE_REFNUM_QUAL_GID = 'ULF.MANUAL_SHIPMENT_CREATION_REQUEST_ID' AND ORDER_RELEASE_GID = ORL.ORDER_RELEASE_GID AND ROWNUM = 1) AS REQUEST_ID , (SELECT IR.ITEM_REFNUM_VALUE FROM ITEM_REFNUM IR,ORDER_RELEASE_LINE ORL1,PACKAGED_ITEM PI WHERE ITEM_REFNUM_QUAL_GID = 'ULF.ULF_MATERIAL_GROUP' AND IR.ITEM_GID = PI.ITEM_GID AND PI.PACKAGED_ITEM_GID = ORL1.PACKAGED_ITEM_GID AND ORL1.ORDER_RELEASE_GID = ORL.ORDER_RELEASE_GID AND ROWNUM=1) AS MATERIAL_GROUP1, (SELECT XL.DEST_REGION_GID FROM X_LANE XL, REGION_DETAIL R WHERE R.REGION_GID = XL.DEST_REGION_GID AND R.LOCATION_GID = ORL.DEST_LOCATION_GID AND XL.X_LANE_GID IN (SELECT X_LANE_GID FROM RATE_GEO WHERE IS_ACTIVE = 'Y' AND EXPIRATION_DATE >=TRUNC(SYSDATE)) AND ROWNUM=1) AS CLUSTER_ID1,(SELECT REMARK_TEXT FROM ORDER_RELEASE_REMARK WHERE REMARK_QUAL_GID = 'ULF.ORDER_RELEASE_FAILURE_REASON' AND ORDER_RELEASE_GID = ORL.ORDER_RELEASE_GID) AS REMARK_ID_TEXT1 FROM ORDER_RELEASE ORL, ORDER_RELEASE_STATUS ORR WHERE ORL.ORDER_RELEASE_GID = ORR.ORDER_RELEASE_GID AND ORL.SOURCE_LOCATION_GID IN ('ULF.CHK') AND ORR.STATUS_TYPE_GID = 'ULF.PLANNING' AND ORR.STATUS_VALUE_GID NOT IN ('ULF.PLANNING_EXECUTED - FINAL')  AND TRUNC(ORL.EARLY_PICKUP_DATE+0.229166667) BETWEEN TRUNC(SYSDATE-3) AND TRUNC(SYSDATE+1) AND  ORL.ATTRIBUTE1 != 'CP' AND ORL.ORDER_RELEASE_TYPE_GID = 'ULF.SECONDARY_OUTBOUND_DELIVERY'";
//	    Response res;
//	    String jsonPrintString="";
//	    String cseq="";
//	    try {
//	        long a=System.currentTimeMillis();
//	        res = client.post(
//	                "https://otmgtm-test-a578804.otm.us2.oraclecloud.com/GC3/glog.integration.servlet.DBXMLServlet?command=xmlExport",
//	                "rootName=ORDER_RELEASE&sqlQuery="+ URLEncoder.encode(sql),
//	                "application/xml");
//	        String result = res.getBody().toString();
//	        long b=System.currentTimeMillis();
//	        System.out.println("---------Time took: "+(b-a));
//	        System.out.println("DBXML Servlet Result: "+result);
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }
//	}
//}
//
//class Client
//{
//    private String authToken;
//    private String baseUrl;
//    final String encoding = "UTF-8";
//    
//    public Client(final String user, final String password, final String url) {
//        this.baseUrl = url;
//        final String authString = String.valueOf(user) + ":" + password;
//        this.authToken = "Basic " + DatatypeConverter.printBase64Binary(authString.getBytes());
//    }
//    
//    public Client(final String token, final String url) {
//        this.authToken = token;
//        this.baseUrl = url;
//    }
//    
//    public Response post(final String uri, final String body, final String contentType) throws Exception {
//        return this.execute(uri, body, "POST", contentType);
//    }
//    
//    public Response execute(final String uri, final String body, final String method, final String contentType) throws Exception {
//        final Response response = new Response();
//        final URL url = new URL( String.valueOf(this.baseUrl) + uri);
//        final HttpsURLConnection conn = (HttpsURLConnection)url.openConnection();
//        conn.setRequestMethod(method.toString());
//        conn.setRequestProperty("Authorization", this.authToken);
//        conn.setDoInput(true);
//        conn.setRequestProperty("charset", "UTF-8");
//        conn.setUseCaches(false);
//        conn.setConnectTimeout(36000);
//        conn.setReadTimeout(36000);
//        conn.setDoOutput(true);
//        final OutputStream os = conn.getOutputStream();
//        os.write(body.getBytes("UTF-8"));
//        os.flush();
//        os.close();
//        final InputStream is = conn.getInputStream();
//        final BufferedReader rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
//        String line;
//        while ((line = rd.readLine()) != null) {
//            response.setBody(String.valueOf(response.getBody()) + line);
//        }
//        rd.close();
//        System.out.println(response.getBody());
//        response.setStatusCode(conn.getResponseCode());
//        conn.disconnect();
//        return response;
//    }
//}
//class Response
//{
//    private int statusCode;
//    private String body;
//    private String exception;
//    
//    public Response() {
//        this.body = "";
//    }
//    
//    public int getStatusCode() {
//        return this.statusCode;
//    }
//    
//    public void setStatusCode(final int statusCode) {
//        this.statusCode = statusCode;
//    }
//    
//    public String getBody() {
//        return this.body;
//    }
//    
//    public void setBody(final String body) {
//        this.body = body;
//    }
//    
//    public String getException() {
//        return this.exception;
//    }
//    
//    public void setException(final String exception) {
//        this.exception = exception;
//    }
//}
//
//
