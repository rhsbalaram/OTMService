package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "LOCATION_REFNUM")
public class LocationRefNum {
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_REFNUM_VALUE")
	private String LocationRefNumValue;
	
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_GID")
	private String locationGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
	private String shipmentGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_REFNUM_QUAL_GID")
	private String locationRefnumQualGid;
}
