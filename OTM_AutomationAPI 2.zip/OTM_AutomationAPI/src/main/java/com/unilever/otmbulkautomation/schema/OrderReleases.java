package com.unilever.otmbulkautomation.schema;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "ORDER_RELEASE")
public class OrderReleases {
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_GID")
	private String orderReleaseGID;
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_TYPE_GID")
	private String orderReleaseTypeGID;
	@JacksonXmlProperty(isAttribute = true, localName = "STATUS_TYPE_GID")
	private String statusTypeGID;
	@JacksonXmlProperty(isAttribute = true, localName = "EARLY_PICKUP_DATE")
	private String earlyPickupDate;
	@JacksonXmlProperty(isAttribute = true, localName = "LATE_PICKUP_DATE")
	private String latePickupDate;
	@JacksonXmlProperty(isAttribute = true, localName = "LATE_DELIVERY_DATE")
	private String lateDeliveryDate;
	@JacksonXmlProperty(isAttribute = true, localName = "STATUS_VALUE_GID")
	private String statusValueGID;
	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_GID")
	private String sourceLocationGID;
	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_NAME")
	private String sourceLocationName;
	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
	private String destinationLocationGID;
	@JacksonXmlProperty(isAttribute = true, localName = "DESTINATION_LOCATION_NAME")
	private String destinationLocationName;
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_ATTRIBUTE1")
	private String locationAttribute1;
	@JacksonXmlProperty(isAttribute = true, localName = "SHIP_WITH_GROUP")
	private String shipWithGroup;
	@JacksonXmlProperty(isAttribute = true, localName = "ATTRIBUTE1")
	private String attribute1;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT")
	private String totalWeight;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT_UOM_CODE")
	private String totalWeightUOMCode;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME")
	private String totalVolume;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME_UOM_CODE")
	private String totalVolumeUOMCode;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE")
	private String totalDeclaredValue;
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE_GID")
	private String totalDeclaredValueGID;
	@JacksonXmlProperty(isAttribute = true, localName = "MAX_SERVICE_TIME")
	private String maxServiceTime;
	@JacksonXmlProperty(isAttribute = true, localName = "CREATE_REQUEST_ID")
	private String crRequestId;
	@JacksonXmlProperty(isAttribute = true, localName = "ASSIGN_REQUEST_ID")
	private String assRequestId;
	@JacksonXmlProperty(isAttribute = true, localName = "UNASSIGN_REQUEST_ID")
	private String unassRequestId;
	@JacksonXmlProperty(isAttribute = true, localName = "CITY")
	private String city;
	@JacksonXmlProperty(isAttribute = true, localName = "MATERIAL_GROUP")
	private String materialGroup;
	@JacksonXmlProperty(isAttribute = true, localName = "CLUSTER_ID")
	private String cluster;
	@JacksonXmlProperty(isAttribute = true, localName = "REMARK_ID_TEXT")
	private String remark;
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_STATUS_GID")
	private String shipmentStatusGid;
	@JacksonXmlProperty(isAttribute = true, localName = "PLAN_TO_LOCATION_GID")
	private String planToLocation;
	@JacksonXmlProperty(isAttribute = true, localName = "PLAN_FROM_LOCATION_GID")
	private String planFromLocation;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
	private String shipmentGid;
	@JacksonXmlProperty(isAttribute = true, localName = "FIRST_EQUIPMENT_GROUP_GID")
	private String firstEqupmentGroupGid;
	@JacksonXmlProperty(isAttribute = true, localName = "SERVPROV_GID")
	private String serprovGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_ENROUTE_GID")
	private String shipmentEnrouteGid;
	
	private List<String> remarks = new ArrayList<String>();
	private Boolean selectable;
}
