package com.unilever.otmbulkautomation.schema;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;
@Data
@JacksonXmlRootElement(localName="TRANSACTION_SET")
public class ShipmentXlaneSchemaWrapper extends SchemaWrapper{
	@JacksonXmlElementWrapper(useWrapping=false)
	@JacksonXmlProperty(localName = "SHIPMENT")
    private List<ShipmentXlane> shipmentXlane;
	
	private String error;
}