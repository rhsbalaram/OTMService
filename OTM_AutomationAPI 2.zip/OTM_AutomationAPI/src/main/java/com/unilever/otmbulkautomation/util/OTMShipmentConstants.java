package com.unilever.otmbulkautomation.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
//@RefreshScope
public class OTMShipmentConstants {

	@Value("${ORDER_RELEASE_REFNUM_QUAL_GID}")
	private String orderReleaseRefNumQualGid;
	
	
	@Value("${ORDER_RELEASE_UNASSIGN_REFNUM_QUAL_GID}")
	private String orderReleaseUnassignRefNumQualGid;
	
	
	@Value("${ORDER_RELEASE_ASSIGN_REFNUM_QUAL_GID}")
	private String orderReleaseAssignRefNumQualGid;
	
	@Value("${DOMAIN_NAME}")
	private String domainName;

	@Value("${shipment.creation}")
	private String shipmentCreation;

	@Value("${QUERY_NAME}")
	private String queryName;

	@Value("${otm.saved.query}")
	private String otmSavedQuery;

	@Value("${otm.location.params.query}")
	private String locationParamsQuery;

	@Value("${otm.processControl.requestId}")
	private String maxProcessControlRequestIdQuery;

	@Value("${otm.processcontrol.cmd}")
	private String processControlCmd;

	@Value("${otm.processcontrol.partition.cmd}")
	private String processControlPartitionCmd;

	@Value("${otm.automation.username}")
	private String username;

	@Value("${TOPIC_ALIAS_GID}")
	private String topicAliasGID;

	@Value("${LOCATION_REFNUM_QUAL_GID}")
	private String locationRefnum;

	@Value("${otm.isPartitionRequired.query}")
	private String isPartitionRequiredQuery;

	@Value("${otm.userBlocking.query}")
	private String userBlockingQuery;

	@Value("${otm.partition.logic}")
	private boolean partitionLogicRequired;

	@Value("${otm.blocking.scenario.getMaxProcessControlRequestId}")
	private String maxProcessControlRequestIdScenario;

	@Value("${otm.shipmentrefnum.gid.pending}")
	private String shipmentPendingGid;

	@Value("${otm.shipmentrefnum.create.pending}")
	private String shipmentCreatePending;

	@Value("${otm.shipmentrefnum.cancel.pending}")
	private String shipmentCancelPending;

	@Value("${otm.shipmentrefnum.assign.pending}")
	private String shipmentAssignPending;

	@Value("${otm.shipmentrefnum.unassign.pending}")
	private String shipmentUnassignPending;
	
	@Value("${otm.shipmentrefnum.equipment.pending}")
	private String shipmentEquipmentPending;
	
	@Value("${otm.shipmentrefnum.gid.cancellation}")
	private String shipmentCancellationGid;
	
	@Value("${otm.shipmentrefnum.gid.assign}")
	private String shipmentAssignGid;
	
	
	@Value("${otm.shipmentrefnum.gid.unassign}")
	private String shipmentUnAssignGid;
	
	
	@Value("${otm.shipmentrefnum.gid.eqchange}")
	private String shipmentEqChangeGid;
	
	
	@Value("${otm.shipmentrefnum.gid.openmarket}")
	private String shipmentopenmarketGid;
	
	@Value("${otm.shipmentrefnum.gid.carrier}")
	private String shipmentcarrierGid;
	
	@Value("${otm.shipmentrefnum.gid.carriervalue}")
	private String shipmentcarrierValue;
	
	
	@Value("${otm.shipmentrefnum.gid.rategeogid}")
	private String shipmentRategeoGid;
}
