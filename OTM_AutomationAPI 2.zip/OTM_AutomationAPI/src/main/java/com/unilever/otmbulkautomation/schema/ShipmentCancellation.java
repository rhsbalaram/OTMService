package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT")
public class ShipmentCancellation
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "CREATED_DATE")
    private String insertedDate;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
    private String shipmentGid;

	@JacksonXmlProperty(isAttribute = true, localName = "FIRST_EQUIPMENT_GROUP_GID")
    private String equipmentGroupGid;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_GID")
    private String sourceLocationGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_NAME")
    private String destName;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
    private String destLoctionGid;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME_UOM_CODE")
    private String totalVolumeUomCode;

	@JacksonXmlProperty(isAttribute = true, localName = "SERVPROV_GID")
    private String servprovGid;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_NAME")
    private String soruceName;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT")
    private String totalWeight;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT_UOM_CODE")
    private String totalWeightUomCode;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME")
    private String totalVolume;

	@JacksonXmlProperty(isAttribute = true, localName = "TENDER_STATUS")
    private String tenderStatus;
	
	@JacksonXmlProperty(isAttribute = true, localName = "ATTRIBUTE11")
	private String attribute11;
	
	@JacksonXmlProperty(isAttribute = true, localName = "PENDING_APPROVAL")
	private String refNum;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE")
	private String totalDeclaredValue;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE_GID")
	private String totalDeclaredValueGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_TYPE")
	private String shipmentType;
	
	@JacksonXmlProperty(isAttribute = true, localName = "CLUSTER_ID")
	private String clusterId;
	
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_ATTRIBUTE")
	private String locationAttribute;
}