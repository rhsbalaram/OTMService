package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT")
public class ShipmentStatus
{
	@JacksonXmlProperty(isAttribute = true, localName = "STATUS_VALUE_GID")
    private String statusValueGid;

}