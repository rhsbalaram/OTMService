package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "EQUIPMENT_GROUP")
public class EquipmentGroupUnAssign
{
	
	
	@JacksonXmlProperty(isAttribute = true, localName = "EQUIPMENT_GROUP_GID")
    private String equipmentGroupGid;

	@JacksonXmlProperty(isAttribute = true, localName = "EFFECTIVE_WEIGHT")
    private String effWeight;

	@JacksonXmlProperty(isAttribute = true, localName = "EFFECTIVE_WEIGHT_UOM_CODE")
    private String effWeightUomCode;

	@JacksonXmlProperty(isAttribute = true, localName = "EFFECTIVE_VOLUME")
    private String effVolume;
	
	@JacksonXmlProperty(isAttribute = true, localName = "EFFECTIVE_VOLUME_UOM_CODE")
    private String effVolumeUomCode;

	
}