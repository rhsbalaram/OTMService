package com.unilever.otmbulkautomation.schema;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT")
public class ShipmentApproval
{
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
    private String shipmentGID;

	@JacksonXmlProperty(isAttribute = true, localName = "FIRST_EQUIPMENT_GROUP_GID")
    private String firstEquipmnetGroupGID;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_GID")
    private String sourceLocationGID;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
    private String DestLocationGID;

	@JacksonXmlProperty(isAttribute = true, localName = "SERVPROV_GID")
    private String servprovGID;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_NAME")
    private String sourceName;

	@JacksonXmlProperty(isAttribute = true, localName = "ATTRIBUTE11")
    private String attribute11;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT")
    private String totalWeight;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME")
    private String totalVolume;

	@JacksonXmlProperty(isAttribute = true, localName = "DESTINATION_NAME")
    private String destinationName;

	@JacksonXmlProperty(isAttribute = true, localName = "NUM_STOP")
    private String numStops;

	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_TYPE")
    private String shipmentType;
	
	@JacksonXmlProperty(isAttribute = true, localName = "CREATED_DATE")
	private String createdDate;
	
	@JacksonXmlProperty(isAttribute = true, localName = "CLUSTER_ID")
	private String clusterId;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOWN")
	private String town;
	
	@JacksonXmlProperty(isAttribute = true, localName = "REF_VALUE")
	private String refValue;
	
	private String reason;
	
	private boolean status;
	
	private String plannedWeight;

	private String plannedVolume;
	
	private String plannedEqup;

	private String plannedServ;
	
	private List<OrderReleases> orderReleases;


}