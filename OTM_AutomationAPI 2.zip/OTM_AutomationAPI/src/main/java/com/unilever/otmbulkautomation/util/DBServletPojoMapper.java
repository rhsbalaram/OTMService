package com.unilever.otmbulkautomation.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class DBServletPojoMapper {
	
	XmlMapper xmlMapper = new XmlMapper();
	{
		xmlMapper.setSerializationInclusion(Include.NON_NULL);
		xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public SchemaWrapper getDBServletMappedPojo(String dbString, Class<? extends SchemaWrapper> schemaClass)  {
		try {
			SchemaWrapper schemaWrapper = schemaClass.newInstance();
			if (StringUtils.containsIgnoreCase(dbString, "<error>")) {
				String error = dbString.replaceAll("(?i)(?s)(.*?)<error>(.*?)</error>(?s)(.*)", "$2");
				log.error("Error in DBServletExecution : {}", error);
				schemaWrapper.setError(error);
				return schemaWrapper;
			} else if (StringUtils.containsIgnoreCase(dbString, "<dbxml:TRANSACTION_SET>")) {
				String transactionSet = dbString.replaceAll(
						"(?i).*?<dbxml:TRANSACTION_SET>(.*?)</dbxml:TRANSACTION_SET>.*",
						"<TRANSACTION_SET>" + "$1" + "</TRANSACTION_SET>");
				// xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				// false);
				if(StringUtils.containsIgnoreCase(transactionSet, "<TRANSACTION_SET>NO DATA</TRANSACTION_SET>")) {
					log.warn("Transaction Set has NO DATA");
					schemaWrapper.setError("NO DATA");
					return schemaWrapper;
				}
				schemaWrapper = xmlMapper.readValue(transactionSet, schemaClass);

				return schemaWrapper;
			}
		} catch (Exception e) {
			log.error("Error parsing DBServlet xml : {} with Exception : {}", dbString, e);
		}
		SchemaWrapper schemaWrapper = new SchemaWrapper();
		schemaWrapper.setError("UnIdentified Error");
		return schemaWrapper;
	}
	
	public String getDBServletMappedXml(SchemaWrapper schema) {
		try {
			return xmlMapper.writeValueAsString(schema);
		} catch (Exception e) {
			log.error("Error parsing DBServlet POJO Exception : {}", e);
		}
		return null;
	}
}
