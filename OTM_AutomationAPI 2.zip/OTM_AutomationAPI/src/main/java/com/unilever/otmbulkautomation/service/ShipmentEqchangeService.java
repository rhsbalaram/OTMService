package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.Dual;
import com.unilever.otmbulkautomation.schema.DualSchemaWrapper;
import com.unilever.otmbulkautomation.schema.EqShipmentStop;
import com.unilever.otmbulkautomation.schema.EqShipmentStopSchemaWrapper;
import com.unilever.otmbulkautomation.schema.EquipmentGroupUnAssign;
import com.unilever.otmbulkautomation.schema.EquipmentGroupUnAssignSchemaWrapper;
import com.unilever.otmbulkautomation.schema.LocationRefNum;
import com.unilever.otmbulkautomation.schema.LocationRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.RateGeo;
import com.unilever.otmbulkautomation.schema.RateGeoSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ServprovSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAttributeUpdate;
import com.unilever.otmbulkautomation.schema.ShipmentAttributesUpdates;
import com.unilever.otmbulkautomation.schema.ShipmentCancellation;
import com.unilever.otmbulkautomation.schema.ShipmentCancellationSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentRefnum;
import com.unilever.otmbulkautomation.schema.ShipmentRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentUnAssign;
import com.unilever.otmbulkautomation.schema.ShipmentUnAssignSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentEqchangeService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.eqchange.equipment.details.getQuery}")
	private String equipmentChangeQuery;
	
	@Value("${otm.shipmentrefNum.getQuery}")
	private String shipmentrefNumGetQuery;
	
	@Value("${otm.unassign.shipment.getQuery}")
	private String shipmentUnassignGetQuery;
	
	
	@Value("${otm.unassign.equipmentgroup.getQuery}")
	private String equipmentgroupUnassignGetQuery;
	
	
	@Value("${otm.eqchange.shipstop.getQuery}")
	private String equipmentShpmtStopGetQuery;
	
	@Value("${otm.unassign.locationrefnum.getQuery}")
	private String locRefnumUnassignGetQuery;
	
	
	@Value("${otm.orderrelease.refnum.query}")
	private String ordRefnumUnassignGetQuery;
	
	
	@Value("${otm.eqchange.details.getQuery}")
	private String shipmentEqChangeDetailsQuery;
	
	@Value("${otm.eqchange.openmarket.getQuery}")
	private String openMarketQuery;
	
	@Value("${otm.loadability.check.query1}")
	private String loadabilityCheckQuery1;
	
	@Value("${otm.loadabilty.check.query2}")
	private String loadabilityCheckQuery2;
	
	
	@Value("${otm.loadabilty.percentage.query}")
	private String loadabilityPercentageCheck;
	
	@Value("${otm.loadabilty.percentage.query1}")
	private String loadabilityPercentageCheck1;
	
	@Value("${otm.loadabilty.percentage.query2}")
	private String loadabilityPercentageCheck2;
	
	@Value("${otm.loadabilty.ordertype.query}")
	private String loadabilityordertype;
	
	@Value("${otm.loadabilty.lastloc.query}")
	private String loadabilitylastLoc;
	
	@Value("${otm.loadabilty.planparam.query}")
	private String loadabilityPlanparam;
	
	@Value("${otm.loadabilty.utiliz.query}")
	private String loadabilityUtilz;
	
	
	
	@Value("${otm.loadabilty.ptl.query}")
	private String loadabilityPtlCheck;
	
	@Value("${otm.loadabilty.orders.shipmentcount.query}")
	private String loadabilityOrderShipmentCountQuery;
	
	@Value("${otm.loadability.shipment.droppoints.query}")
	private String loadabilityShipmentDropQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	OTMService otmservice;
	
	@Autowired
	OTMShipmentConstants otmShpConstants;
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;
	
	@Autowired
	OrderReleaseService orderReleaseService;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	UserRepository userRepo;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	@Autowired
	DBServletPojoMapper mapper;
	
	@Autowired
	DBServletRestUtil restUtil;
	
	ObjectMapper objMapper = new ObjectMapper();
		
	
	public ShipmentCreationRequest postShipmentForApproval(String username, RateGeoSchemaWrapper rateGeo) {
		String reason = rateGeo.getReason();
		String eqmtGroupGid = rateGeo.getEqmtGroupGid();
		String servprovGid = rateGeo.getServprovGid();
		List<RateGeo> rateGeos = rateGeo.getRateGeo();
		ShipmentCancellation shipment = rateGeo.getShipment();
		ShipmentCreationRequest shipmentCreationRequest = new ShipmentCreationRequest();
		List<String> ordgids = new ArrayList<>();
		String type = "";
		String mail = "";
		String shipids = shipment.getShipmentGid();
		String orderReleaseType = shipment.getShipmentType(); //shipment.getAttribute11();
		try {
			if (!CollectionUtils.isEmpty(rateGeo.getRateGeo()) && Objects.nonNull(shipment)) {
				RateGeo actualrateGeo = null;
				if(StringUtils.isBlank(servprovGid) ||StringUtils.isBlank(eqmtGroupGid)) {
					String equipmentGroupGid = shipment.getEquipmentGroupGid();
					String servid = shipment.getServprovGid();
					if(StringUtils.isBlank(eqmtGroupGid)) {
						type = "Truck Type Change";
						mail = "OTM Truck Type Change - Action";
						for(RateGeo rate : rateGeos) {
							if(StringUtils.equals(equipmentGroupGid, rate.getEquipmentGroupProfileGid())) {
								actualrateGeo = rate;
								eqmtGroupGid=rate.getEquipmentGroupProfileGid();
							}
						}
					} else {
						type = "TSP Change";
						mail = "OTM Service Provider Change - Action";
						for(RateGeo rate : rateGeos) {
							if(StringUtils.equals(servid, rate.getServprovGid())) {
								actualrateGeo = rate;
								servprovGid = rate.getServprovGid();
							}
						}
					}
				} else {
					actualrateGeo = rateGeo.getRateGeo().get(0);
					type = "Truck Type & TSP Change";
					mail = "OTM Truck Type & Service Provider Change - Action";
				}
			
					String query = MessageFormat.format(equipmentShpmtStopGetQuery, new Object[] { eqmtGroupGid, shipment.getShipmentGid() });
					String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_STOP", query);
					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							EqShipmentStopSchemaWrapper.class);
					if (Objects.isNull(dbServletMappedPojo.getError())) {
						List<EqShipmentStop> eqShipmentStop = ((EqShipmentStopSchemaWrapper) dbServletMappedPojo)
								.getEqShipmentStop();
						for(EqShipmentStop eq : eqShipmentStop) {
							if(StringUtils.equals(eq.getStopType(), "D") &&StringUtils.equals(eq.getEquimentGroupProfileGid(), actualrateGeo.getRateGeoGid()) && !StringUtils.equals(eq.getEqupmentGid(), eqmtGroupGid)) {
								 shipmentCreationRequest.setFailureReason("Shipment Validation Fail");
								 return shipmentCreationRequest;
							}
						}

					}

//				boolean needApproval = true;
//				String loadabilityPercentageRefNum = getLoadabilityPercentageRefNum(shipment.getShipmentType());
//				if (StringUtils.isNotBlank(loadabilityPercentageRefNum)) {
//					query = MessageFormat.format(locRefnumUnassignGetQuery,
//							new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {
//								{
//									add(shipment.getSourceLocationGid());
//								}
//							}), loadabilityPercentageRefNum });
//					dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
//					dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
//							LocationRefnumSchemaWrapper.class);
//					if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
//						List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
//								.getLocationRefnums();
//						LocationRefNum locationRefNum = locationRefnums.get(0);
//						if (Objects.nonNull(locationRefNum)) {
//							///
//						}
//					}
//				}
				/*************************new loadability code***********************/
					ShipmentUnAssign shipmentdata = null;
						 query = MessageFormat.format(shipmentUnassignGetQuery,
								new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {{add(shipids);}}) });
						 dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
						 dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								ShipmentUnAssignSchemaWrapper.class);
						List<String> gids = new ArrayList<>();
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							List<ShipmentUnAssign> shipments = ((ShipmentUnAssignSchemaWrapper) dbServletMappedPojo)
									.getShipments();
							if (!CollectionUtils.isEmpty(shipments)) {
								shipmentdata = shipments.get(0);
							}
						}
					
					Float loadCal = getLoadabiltyCalculation(shipids, eqmtGroupGid, shipmentdata);
					boolean needApproval = false;
					boolean needLoadabilityCheck = false;
					//***** new loadability logic 
					
						 query = MessageFormat.format(loadabilityCheckQuery1,
								new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {{add(shipids);}}) });
						 dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
						 dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								DualSchemaWrapper.class);
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							 query = MessageFormat.format(loadabilityCheckQuery2,
									new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {{add(shipids);}}) });
							 dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
							 dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
									DualSchemaWrapper.class);
							if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
								needLoadabilityCheck = true;
							}
						}
					
				if (needLoadabilityCheck && Objects.nonNull(shipmentdata)) {
					Map<String, String> loadabilityPercentage = new HashMap();
					if (OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseType)) {
						getLoadabilityPercentage(shipids, loadabilityPercentageCheck, loadabilityPercentage);
						// PTL check
						boolean ptlCheck = false;

						query = MessageFormat.format(loadabilityPtlCheck,
								new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {
									{
										add(shipids);
									}
								}) });
						dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
						dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								DualSchemaWrapper.class);
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							ptlCheck = true;
						}

						if (ptlCheck) {

							Map<String, String> pertmap = loadabilityPercentage;
							if (pertmap.containsKey("ULF.MINIMUM_CASE_LOAD")) {
								String pertage = pertmap.get("ULF.MINIMUM_CASE_LOAD");
								if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
									float percentage = Float.parseFloat(pertage);
									String totalShipUnitCount = shipmentdata.getTotalShipUnitCount();
									if (Objects.nonNull(totalShipUnitCount)
											&& NumberUtils.isCreatable(totalShipUnitCount)) {
										float remShipUnit = Float.parseFloat(totalShipUnitCount);
										if (remShipUnit < percentage) {
											needApproval = true;
										}
									}
								}
							}

						} else {
							boolean dropCheck = true;
							float customDecValue = 0f;
							float loadPercentage = 0f;

							Map<String, String> pertmap = loadabilityPercentage;
							if (pertmap.containsKey("ULF.ULF_CUST_DELCARED_VALUE")) {
								String pertage = pertmap.get("ULF.ULF_CUST_DELCARED_VALUE");
								if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
									customDecValue = Float.parseFloat(pertage);
								}
							}
							if (pertmap.containsKey("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE")) {
								String pertage = pertmap.get("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE");
								if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
									loadPercentage = Float.parseFloat(pertage);
								}
							}
							if (customDecValue == 0f && loadPercentage == 0f) {
								dropCheck = false;
							}

							if (dropCheck) {

								Map<String, Set<String>> dropmap = new HashMap();
								query = MessageFormat.format(loadabilityShipmentDropQuery, new Object[] { shipids });
								dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
								dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
										LocationRefnumSchemaWrapper.class);
								Set<String> refgids = new HashSet<>();
								Set<String> destgids = new HashSet<>();

								if (Objects.nonNull(dbServletMappedPojo)
										&& Objects.isNull(dbServletMappedPojo.getError())) {
									List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
											.getLocationRefnums();
									if (!CollectionUtils.isEmpty(locationRefnums)) {

										locationRefnums.forEach(refnum -> {
											refgids.add(refnum.getLocationGid());
										});
										// List<OrderReleases> list = unAssignmentOrders.get(shipid);
										// if (!CollectionUtils.isEmpty(list)) {
										// list.forEach(ord -> {
										// destgids.add(ord.getDestinationLocationGID());
										// });
										// gids.removeAll(destgids);
										// if (gids.size() > 1) {
										// dropCheck = false;
										// }
										// }
										if (gids.size() > 1) {
											dropCheck = false;
										}
									}
								}

							}
							if (dropCheck) {

								if (Objects.nonNull(loadCal)) {

									Float perVal = loadCal;
									Float decareVal = 0f;
									if (Objects.nonNull(shipmentdata.getTotalDeclaredValue())
											&& NumberUtils.isCreatable(shipmentdata.getTotalDeclaredValue())) {
										decareVal = Float.parseFloat(shipmentdata.getTotalDeclaredValue());
									}
									if (perVal < loadPercentage && decareVal < customDecValue) {
										needApproval = true;

									}
								}

							} else {
								getLoadabilityPercentage(shipids, loadabilityPercentageCheck1, loadabilityPercentage);
								float solp = 0f;
								float solmp = 0f;
								float mainper = 0f;
								float maxpert = 0f;
								pertmap = loadabilityPercentage;
								if (pertmap.containsKey("ULF.ULF_SOB_BULK_PLAN_LOADABILITY")) {
									String pertage = pertmap.get("ULF.ULF_SOB_BULK_PLAN_LOADABILITY");
									if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
										solp = Float.parseFloat(pertage);
									}
								}
								if (pertmap.containsKey("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE")) {
									String pertage = pertmap.get("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE");
									if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
										solmp = Float.parseFloat(pertage);
									}
								}
								mainper = solp;
								if (solp == 0f) {
									mainper = solmp;
								}

								if (Objects.nonNull(loadCal)) {

									if (pertmap
											.containsKey("ULF.ULF_SECONDARY_OUTBOUND_MAX_LOADABILITY_PERCENTAGE")) {
										String maxper = pertmap
												.get("ULF.ULF_SECONDARY_OUTBOUND_MAX_LOADABILITY_PERCENTAGE");
										if (Objects.nonNull(maxper) && NumberUtils.isCreatable(maxper)) {
											maxpert = Float.parseFloat(maxper);
										}
									}
									if ((loadCal < mainper && maxpert == 0f) || (loadCal < mainper && loadCal < maxpert)) {
										
										needApproval = true;

									}
								}

							}
						}
					} else {
						getLoadabilityPercentage(shipids, loadabilityPercentageCheck2, loadabilityPercentage);
						float plp = 0f;
						Float perVal = loadCal;

						Map<String, String> pertmap = loadabilityPercentage;
						if (pertmap.containsKey("ULF.ULF_PALLET_LOADABILITY_PERCENT")) {
							String pertage = pertmap.get("ULF.ULF_PALLET_LOADABILITY_PERCENT");
							if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
								plp = Float.parseFloat(pertage);
							}
						}
						String orderType = "";
						List<Dual> dual = null;
						Dual dualObj = null;
						query = MessageFormat.format(loadabilityordertype, new Object[] { shipids });
						dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
						dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								DualSchemaWrapper.class);
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
							dualObj = dual.get(0);
							if (Objects.nonNull(dualObj)) {
								orderType = dualObj.getOutput();
							}
						}
						query = MessageFormat.format(loadabilitylastLoc, new Object[] { shipids });
						dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
						dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								DualSchemaWrapper.class);
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
							dualObj = dual.get(0);
							if (Objects.nonNull(dualObj)) {
								String lastpickup = dualObj.getOutput();
								query = MessageFormat.format(loadabilityPlanparam,
										new Object[] { shipids, lastpickup });
								dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
								dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
										DualSchemaWrapper.class);
								if (Objects.nonNull(dbServletMappedPojo)
										&& Objects.isNull(dbServletMappedPojo.getError())) {
									dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
									dualObj = dual.get(0);
									if (Objects.nonNull(dualObj)) {
										String loadpercentage = dualObj.getOutput();
										ShipmentUnAssign shipmentUnAssign = shipmentdata;

										if (Objects.nonNull(shipmentUnAssign)
												&& "ULF.ULF_PLANNING_PARAMETER_ERU"
														.equals(shipmentUnAssign.getPlanningParameterSetGid())
												&& OTMConstants.PRIMARY_OUTBOUND_DELIVERY.equals(orderReleaseType)
												&& orderType.equals("PT")) {
											query = MessageFormat.format(loadabilityUtilz, new Object[] { shipids });
											dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
											dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
													DualSchemaWrapper.class);
											if (Objects.nonNull(dbServletMappedPojo)
													&& Objects.isNull(dbServletMappedPojo.getError())) {
												dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
												dualObj = dual.get(0);
												if (Objects.nonNull(dualObj)) {
													String eruPerctge = dualObj.getOutput();
													if (Objects.nonNull(eruPerctge)
															&& NumberUtils.isCreatable(eruPerctge)) {
														float euperVal = Float.parseFloat(eruPerctge) * 100;
														if (euperVal < plp) {
															if (Objects.nonNull(loadpercentage)
																	&& NumberUtils.isCreatable(loadpercentage)) {
																float loadperVal = Float.parseFloat(loadpercentage)
																		* 100;
																if (perVal < loadperVal) {
																	needApproval = true;
																}
															}
														}
													}
												}
											}
										} else {
											if (Objects.nonNull(loadpercentage)
													&& NumberUtils.isCreatable(loadpercentage)) {
												float loadperVal = Float.parseFloat(loadpercentage) * 100;
												if (perVal < loadperVal) {
													needApproval = true;
												}
											}
										}
									}
								}
							}
						}

					}
				}
					/**************************************************************/

				shipmentCreationRequest.setUsername(username);
				shipmentCreationRequest.setStatus(OTMConstants.OPEN);
				if (needApproval) {
					shipmentCreationRequest.setStatus(OTMConstants.APPROVAL_PENDING);
				}
				shipmentCreationRequest.setRequestType(type);
				shipmentCreationRequest.setReasons(reason);
				LocalDateTime currentISTLocalDateTime = dateUtil.getCurrentISTLocalDateTime();
				shipmentCreationRequest.setCreatedDateTime(currentISTLocalDateTime);
				shipmentCreationRequest.setModifiedDateTime(currentISTLocalDateTime);
				shipmentCreationRequest.setNumberOfOrders(1);
				shipmentCreationRequest.setNumberOfShipments(1);
				String shipmentRequestId = commonUtil
						.getSequencePrefix(String.valueOf(repository.getShipmentRequestValue()));
				shipmentCreationRequest.setRequestNumber(shipmentRequestId);

				shipmentCreationRequest.setDepotId(shipment.getSourceLocationGid());
				shipmentCreationRequest.setShipmentType(shipment.getShipmentType());

				ShipmentCreationRequestLog shipmentlog = new ShipmentCreationRequestLog();
				shipmentlog.setRequestNumber(shipmentRequestId);
				shipmentlog.setOrdersNumbers(shipment.getShipmentGid()+"-"+eqmtGroupGid+":"+servprovGid);
				repositoryLog.save(shipmentlog);
				repository.save(shipmentCreationRequest);
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"EQCHANGE creation with req id : " + shipmentRequestId + " shipments : " + shipment.getShipmentGid(), "INFO"));
				deleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}}, otmShpConstants.getShipmentEqChangeGid());
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}},
						otmShpConstants.getShipmentEqChangeGid(), shipmentRequestId, "I");
				deleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}}, otmShpConstants.getShipmentRategeoGid());
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}},
						otmShpConstants.getShipmentRategeoGid(), actualrateGeo.getRateGeoGid(), "I");
				if(Objects.nonNull(rateGeo.getOpenMarket())) {
					deleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}}, otmShpConstants.getShipmentcarrierGid());

					shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}},
							otmShpConstants.getShipmentcarrierGid(), otmShpConstants.getShipmentcarrierValue(), "I");
					deleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}}, otmShpConstants.getShipmentopenmarketGid());

					shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}},
							otmShpConstants.getShipmentopenmarketGid(), rateGeo.getOpenMarket(), "I");
				}
				if (needApproval) {
					updateShipmentRequestId(shipmentRequestId, shipment.getShipmentGid());
					shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipment.getShipmentGid());}},
							otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentEquipmentPending(), "I");
					String shpmtType = commonUtil.getShipmentType(shipment.getShipmentType());
					List<User> users = userRepo.findBySourceLocation(new ArrayList<String>() {{add(shipment.getSourceLocationGid().replace("ULF.", ""));}}, "Approver", shpmtType);
					ShipmentApprovalSchemaWrapper approvalShipmentsFromOtm = otmservice
							.getApprovalShipmentsFromOtm(new ArrayList<String>() {{add(shipment.getShipmentGid());}});

					if (!CollectionUtils.isEmpty(users)
							&& !CollectionUtils.isEmpty(approvalShipmentsFromOtm.getShipments())) {
						List<String> emails = users.stream().map(user -> user.getEmailId())
								.collect(Collectors.toList());
						ShipmentApproval shipmentApproval = approvalShipmentsFromOtm.getShipments().get(0);
						shipmentApproval.setReason(reason);
						shipmentApproval.setAttribute11(shipmentRequestId);
						for (User user : users) {
							String module = user.getModule();
							//if (Objects.nonNull(module) && StringUtils.containsIgnoreCase(module, "modification")) {
								emailUtil.sendEmailWithAttachment(mail, otmUtil.getEmailForEQChange(shipmentApproval,
										user.getUsername(), eqmtGroupGid, servprovGid, type), user.getEmailId());
							//}
						}
						logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
								"sending Email for EqChange req id : " + shipmentRequestId + " for users : " + emails,
								"INFO"));

					}
				}

				else {
					updateShipmentAndOrdersRequestId(shipmentRequestId, shipment.getShipmentGid());
				}

			}
		} catch (Exception e) {
			shipmentCreationRequest.setStatus("Failed");
			shipmentCreationRequest.setFailureReason("Unassign Creation Error");
			repository.updateShipmentResponses(shipmentCreationRequest.getRequestNumber(), null,
					shipmentCreationRequest.getStatus(), null, shipmentCreationRequest.getFailureReason(),
					shipmentCreationRequest.getNumberOfShipments(), dateUtil.getCurrentISTLocalDateTime());
			logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
					"Error  for Unassignment req id : " + shipmentCreationRequest.getRequestNumber() + e.getMessage(),
					"ERROR"));
		}
		return shipmentCreationRequest;
	}
		
	
	private String getLoadabilityPercentageRefNum(String orderType) {
		switch(orderType) {
		case OTMConstants.SECONDARY_OUTBOUND_DELIVERY: return "ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE";
		case OTMConstants.PRIMARY_OUTBOUND_DELIVERY: return "ULF.ULF_PRIMARY_OUTBOUND_LOADABILITY_PERCENTAGE";
		case OTMConstants.SECONDARY_DIRECT_DISPATCH_DELIVERY: return "ULF.ULF_DIRECT_DISPATCH_LOADABILITY_PERCENTAGE";
		default : return "";
		}
	}
	
	private float getFractionValue(String code) {
		switch(code) {
		case "GRM": return 1000000f;
		case "KG": return 1000f;
		case "CMQ": return 1000000f;
		case "DMQ": return 1000f;
		case "HLT": return 10f;
		default : return 1000000f;
		}
	}
	
	private void deleteShipmentRefnum(List<String> shipgids, String gid) {
		String refquery = MessageFormat.format(shipmentrefNumGetQuery,
				new Object[] { commonUtil.getCommaDelimiterString(shipgids),
						gid });
		String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", refquery);
		SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,
				ShipmentRefnumSchemaWrapper.class);
		if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
			List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo)
					.getShipmentRefnums();
			if (!CollectionUtils.isEmpty(shipmentRefnums)) {
				String dbServletMappedXml = mapper
						.getDBServletMappedXml(((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo));
				String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D",
						dbServletMappedXml);
				if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
					log.error("Error Deleting the " + otmShpConstants.getShipmentEqChangeGid()
							+ " shipmentids : " + shipgids);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
							"Error Deleting the " + otmShpConstants.getShipmentEqChangeGid()
									+ " shipmentids : " + shipgids,
							"ERROR"));
				}
			}
		}
	}
	
	
	
	public void updateShipmentAndOrdersRequestId(String shipmentRequestId, String shipids) {
			try {
				ShipmentAttributesUpdates attrUpdate = new ShipmentAttributesUpdates();
				attrUpdate.setAttribute11(shipmentRequestId);
				attrUpdate.setAttribute12("EQCHANGE");
				attrUpdate.setShipmentXid(shipids.replaceAll("ULF.", ""));
				String update = objMapper.writeValueAsString(attrUpdate);
				String rest = "shipments/" + shipids;
				dbServletRestUtil.postQueryToRestOTM(rest, update);
			} catch (Exception e) {
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"Error Updating attribute11 rest :" + shipids + " requestid : " + shipmentRequestId,
						"ERROR"));
			}
		
	}
	
	public void updateShipmentRequestId(String shipmentRequestId, String shipids) {
		
		
			try {
				ShipmentAttributeUpdate attrUpdate = new ShipmentAttributeUpdate();
				attrUpdate.setAttribute11(shipmentRequestId);
				attrUpdate.setShipmentXid(shipids.replaceAll("ULF.", ""));
				String update = objMapper.writeValueAsString(attrUpdate);
				String rest = "shipments/" + shipids;
				dbServletRestUtil.postQueryToRestOTM(rest, update);
			} catch (Exception e) {
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"Error Updating attribute11 rest :" + shipids + " requestid : " + shipmentRequestId,
						"ERROR"));
			}
		
	}
	
	public SchemaWrapper getOrderForShipmentUnAssign(String reqestId, String shipmentid) {
		ShipmentCreationRequestLog findByRequestNumber = repositoryLog.findByRequestNumber(reqestId);
		if(Objects.nonNull(findByRequestNumber)) {
			String ordersNumbers = findByRequestNumber.getOrdersNumbers();
			String[] split = ordersNumbers.split(",");
			List<String> shipmentordIds = Arrays.asList(split);
			for(String id : shipmentordIds) {
				String[] ordship = id.split("-");
				if(ordship.length>2) {
					if(ordship[0].equals(shipmentid)) {
						String[] orders = ordship[2].split(":");
						List<String> ordersList = Arrays.asList(orders);
						return orderReleaseService.getOrderReleasesFromOtmForUnAssignmentApproval(ordersList);
					}
				}
			}
		}
		return null;
	}
	
	public List<ShipmentApproval> postEqchangeByShipment(List<ShipmentApproval> shipments, String status, String userId) {
		if(!CollectionUtils.isEmpty(shipments)) {
			shipments.forEach(ship ->{
				ShipmentCreationRequest shipment = repository.findByRequestNumber(ship.getAttribute11());

			if (OTMConstants.APPROVED.equals(status)) {
				List<OrderReleases> orderReleases = ship.getOrderReleases();
				updateShipmentAndOrdersRequestId(ship.getAttribute11(), ship.getShipmentGID());
			} else {
				repository.updateShipmentApprovalStatus(ship.getAttribute11(), status, dateUtil.getCurrentISTLocalDateTime());
			}
			if(Objects.nonNull(shipment)) {
				String track = ship.getShipmentGID() + ":" + userId + ":" + status;
				String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
				repository.updateShipmentApprovalTracking(ship.getAttribute11(), approvalTracking, dateUtil.getCurrentISTLocalDateTime());
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(ship.getShipmentGID());}},
						otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentEquipmentPending(), "D");
			}
		});
		
		return shipments;
		}
		return null;
	}
	
	public SchemaWrapper getShipmentEqchangeDetailsFromOtm(String requestId) {
		if (Objects.nonNull(requestId)) {
			String query = MessageFormat.format(shipmentEqChangeDetailsQuery, new Object[] { requestId });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentCancellationSchemaWrapper.class);
		} else {
			return null;
		}
	}
	
	public SchemaWrapper getOpenMarketFromOtm(String market) {
		if (Objects.nonNull(market)) {
			String query = MessageFormat.format(openMarketQuery, new Object[] { StringUtils.upperCase("ULF."+market.replace("ULF.", ""))  });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("SERVPROV", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ServprovSchemaWrapper.class);
		} else {
			return null;
		}
	}
	
	public SchemaWrapper getEqmtDetailsFromOtm(ShipmentCancellation shpmt) {
		if (Objects.nonNull(shpmt)) {
			String query = MessageFormat.format(equipmentChangeQuery, new Object[] { shpmt.getSourceLocationGid(), shpmt.getSourceLocationGid(), shpmt.getDestLoctionGid(),  shpmt.getDestLoctionGid()});

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("RATE_GEO", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString, RateGeoSchemaWrapper.class);
			 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 RateGeoSchemaWrapper orderReleaseRefnums = ((RateGeoSchemaWrapper) dbServletMappedPojo);
				 orderReleaseRefnums.setShipment(shpmt);
				 List<RateGeo> rateGeo = orderReleaseRefnums.getRateGeo();
				 Map<String, List<RateGeo>> eqmtGroupGids = new HashMap<>();
				 Map<String, List<RateGeo>> servprovGids = new HashMap<>();
				 rateGeo.forEach(ratege -> {
					 String equgid = ratege.getEquipmentGroupProfileGid();
					 if(eqmtGroupGids.containsKey(equgid)) {
						 List<RateGeo> list = eqmtGroupGids.get(equgid);
						 list.add(ratege);
					 } else {
						 List<RateGeo> list = new ArrayList<>();
						 list.add(ratege);
						 eqmtGroupGids.put(equgid, list);
					 }
				 });
				 rateGeo.forEach(ratege -> {
					 String sergid = ratege.getServprovGid();
					 if(servprovGids.containsKey(sergid)) {
						 List<RateGeo> list = servprovGids.get(sergid);
						 list.add(ratege);
					 } else {
						 List<RateGeo> list = new ArrayList<>();
						 list.add(ratege);
						 servprovGids.put(sergid, list);
					 }
				 });
				 orderReleaseRefnums.setEqmtGroupGids(eqmtGroupGids);
				 orderReleaseRefnums.setServprovGids(servprovGids);
				 return orderReleaseRefnums;
			 }
		} 
			return null;
	}
	
	
	private Float getLoadabiltyCalculation(String shipid, final String eqpmtid, ShipmentUnAssign shipment) {
		Float load = 0f;
		String query = MessageFormat.format(equipmentgroupUnassignGetQuery,
				new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {
					{
						add(eqpmtid);
					}
				}) });
		String dbString = dbServletRestUtil.postGetQueryToDBServlet("EQUIPMENT_GROUP", query);
		SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
				EquipmentGroupUnAssignSchemaWrapper.class);
		if (Objects.nonNull(dbServletMappedPojo)
				&& Objects.isNull(dbServletMappedPojo.getError())) {
			List<EquipmentGroupUnAssign> equipmentGroups = ((EquipmentGroupUnAssignSchemaWrapper) dbServletMappedPojo)
					.getEquipmentGroups();
			if (!CollectionUtils.isEmpty(equipmentGroups)) {
				EquipmentGroupUnAssign equipmentGroupUnAssign = equipmentGroups.get(0);
				if (Objects.nonNull(equipmentGroupUnAssign)
						&& Objects.nonNull(equipmentGroupUnAssign.getEffVolumeUomCode())
						&& Objects.nonNull(equipmentGroupUnAssign.getEffWeightUomCode())
						&& NumberUtils.isCreatable(equipmentGroupUnAssign.getEffWeight())
						&& NumberUtils.isCreatable(equipmentGroupUnAssign.getEffVolume())
						&& NumberUtils.isCreatable(shipment.getTotalWeight())
						&& NumberUtils.isCreatable(shipment.getTotalVolume())) {
					Float effweight = Float.parseFloat(equipmentGroupUnAssign.getEffWeight())
							/ getFractionValue(equipmentGroupUnAssign.getEffWeightUomCode());
					Float effvolume = Float.parseFloat(equipmentGroupUnAssign.getEffVolume())
							/ getFractionValue(equipmentGroupUnAssign.getEffVolumeUomCode());
					Float weight = (Float.parseFloat(shipment.getTotalWeight())
							/ getFractionValue(shipment.getTotalWeightUomCode()));
					Float volume = (Float.parseFloat(shipment.getTotalVolume())
							/ getFractionValue(shipment.getTotalVolumeUomCode()));
					Float perWeight = (weight / effweight) * 100;
					Float perVolume = (volume / effvolume) * 100;
						
						if (perWeight > perVolume) {
							load = perWeight;
						} else {
							load = perVolume;
						}
					

				}
			}
		}
		return load;
	}
	
	private void getLoadabilityPercentage(String shipid, String loadabilityPercentageQuery,
			Map<String, String> loadabilityPercentage) {
		String query = MessageFormat.format(loadabilityPercentageQuery,
				new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {
					{
						add(shipid);
					}
				}) });
		String dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
		SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
				LocationRefnumSchemaWrapper.class);
		List<String> gids = new ArrayList<>();
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
					.getLocationRefnums();
			if (!CollectionUtils.isEmpty(locationRefnums)) {

				locationRefnums.forEach(loc -> {

					loadabilityPercentage.put(loc.getLocationRefnumQualGid(), loc.getLocationRefNumValue());

				});
			}
		}

	}	
}
