package com.unilever.otmbulkautomation.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.Depot;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.domain.UserDetail;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.service.CustomUserDetailsService;
import com.unilever.otmbulkautomation.service.OTMService;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.ExcelUtils;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

@RestController
public class UserDetailsController {

	@Autowired
	UserRepository users;

	@Autowired
	OTMService otmService;
	
	@Autowired
	OTMShipmentConstants otmConstants;
	
	@Autowired
	CustomUserDetailsService userService;
	
	@Autowired
	ExcelUtils excelUtils;
	
	@Autowired
	EmailUtil emailUtil;
	
	@GetMapping("user/details")
	public ResponseEntity<Object> getUserDetails(HttpServletRequest request) {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		Optional<User> findByUsername = users.findByUsername(username);
		ModelMap userData = new ModelMap();
		if(findByUsername.isPresent()) {
			User user = findByUsername.get();
			userData.put("userData", user);
			userData.put("blockTimings", false);
			List<Depot> locations = user.getLocations();
			if (!CollectionUtils.isEmpty(locations)) {
				List<String> depoitIds = locations.stream().map(location ->{
					if(Objects.nonNull(location.getDepotId()) && !location.getDepotId().contains(otmConstants.getDomainName()+".")) {
						location.setDepotId(otmConstants.getDomainName()+"."+location.getDepotId());
					} 
					return location.getDepotId();
				} ).collect(Collectors.toList());
				if (OTMConstants.REQUESTER.equals(user.getRole())) {
					
					boolean userBlockingTime = otmService.getUserBlockingTime(depoitIds);

					userData.put("blockTimings", userBlockingTime);
					if (userBlockingTime) {
						userData.put("userData", null);
					}
				}
			}
		}
		return new ResponseEntity<>(userData, HttpStatus.OK);
	}

	@PostMapping("admin/upload")
	public String submit(@RequestParam("file") MultipartFile file, @RequestParam("dataType") String dataType) throws IOException {
//	   if("USER".equals(dataType)) {
//		   List<User> usersData = excelUtils.getUsersData(file.getInputStream());
//		   userService.importAuthData(usersData);
//	   } else {
//		   List<UserDetail> userDetailsData = excelUtils.getUserDetailsData(file.getInputStream());
//		   userService.importDepotData(userDetailsData);
//	   }
		return "Success";
	}
	
	@PostMapping("admin/mail")
	public void mailimage(@RequestParam("file") MultipartFile file) throws IOException, MessagingException {
		emailUtil.sendEmailWithAttachment("Testing", "<html>\n" + 
				"<head>\n" + 
				"  <style>\n" + 
				"    \n" + 
				"  </style>\n" + 
				"  </head>\n" + 
				"  <body>\n" + 
				"<img src='data:image/jpeg;base64,"+new String(Base64.getEncoder().encode(file.getBytes()), StandardCharsets.UTF_8)+"'>"+
				"</body>\n" + 
				"\n" + 
				"</html>","shashank.bhat@birlasoft.com");
	}
	
	@GetMapping("admin/email")
	public void testEmail(@RequestParam("to") String to) throws MessagingException, UnsupportedEncodingException {
		emailUtil.sendEmailWithAttachment("Testing", "<html>\n" + 
				"<head>\n" + 
				"  <style>\n" + 
				"    \n" + 
				"  </style>\n" + 
				"  </head>\n" + 
				"  <body>\n" + 
				"\n" + 
				"<input type=\"button\" value=\"Approve\">\n" + 
				"\n" + 
				"</body>\n" + 
				"\n" + 
				"</html>", to);
	}
	
	@GetMapping("admin/proxy")
	public String testEmailProxy()  {
		try {
		emailUtil.sendEmailWithProxy("Testing", "<html>\n" + 
				"<head>\n" + 
				"  <style>\n" + 
				"    \n" + 
				"  </style>\n" + 
				"  </head>\n" + 
				"  <body>\n" + 
				"\n" + 
				"<input type=\"button\" value=\"Approve\">\n" + 
				"\n" + 
				"</body>\n" + 
				"\n" + 
				"</html>","hema.sathya.balarama.murthy.r@oracle.com");
		} catch(Exception e) {
			return e.getMessage();
		}
		return "success";
	}
}
