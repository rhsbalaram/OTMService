package com.unilever.otmbulkautomation.util;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentCancellation;
import com.unilever.otmbulkautomation.security.JwtTokenProvider;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class OTMResponseUtil {
	
	private static final String RES_FORMAT = "(?i)(?s)(.*?)<otm:RemarkText>(.*?)</otm:RemarkText>(?s)(.*)";
	private static final String REQ_FORMAT = "(?i)(?s)(.*?)<otm:Attribute11>(.*?)</otm:Attribute11>(?s)(.*)";
	private static final String SHP_FORMAT = "(?s)(.*?)<otm:FlexFieldNumbers><otm:AttributeNumber5>(.*?)</otm:AttributeNumber5></otm:FlexFieldNumbers>(?s)(.*)";
	private static final String SHP_NUMBER = "(?i)(?s)(.*?)<otm:ShipmentGid><otm:Gid><otm:DomainName>ULF</otm:DomainName><otm:Xid>(.*?)</otm:Xid></otm:Gid></otm:ShipmentGid>(?s)(.*)";
	// LTL
	private static final String SECURE_RESOURCES_NOT_STARTED = "SECURE RESOURCES_NOT STARTED";
	private static final String SECURE_RESOURCES_WITHDRAWN = "SECURE RESOURCES_WITHDRAWN";
	private static final String TENDER_CALL_NO_CALL = "TENDER CALL_NO CALL";
	private static final String TENDER_CALL_CANCEL = "TENDER CALL_CANCEL";
	// FTL
	private static final String SECURE_RESOURCES_ACCEPTED = "SECURE RESOURCES_ACCEPTED";
	private static final String SECURE_RESOURCES_TENDERED = "SECURE RESOURCES_TENDERED";
	private static final String TENDER_CALL_TENDER = "TENDER CALL_TENDER";

	@Autowired
	ResourceLoader resourceLoader;
	
	@Autowired
	JwtTokenProvider jwtTokenProvider;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	CommonUtils commonUtils;
	
	@Value("${otm.ojet.server}")
	String ojetUrl;
	
	@Value("${otm.image.delimeter}")
    private String imageDelimiter;

	private String TenderCallFormat;

	private String SecureResourceFormat;
	
	private String email;
	
	private String email_new;

	private String email_trucktype;
	
	private String confirmation;

	@PostConstruct
	public void loadDBServletQueryFile() throws IOException {
		log.info("Loading static file contents");
		this.SecureResourceFormat = "(?i)(?s)(.*?)"
				+ new String(FileCopyUtils.copyToByteArray(
						resourceLoader.getResource("classpath:templates/SecureResorceFormat.xml").getInputStream()))
				+ "(?s)(.*)";
		this.TenderCallFormat = "(?i)(?s)(.*?)"
				+ new String(FileCopyUtils.copyToByteArray(
						resourceLoader.getResource("classpath:templates/TenderCallFormat.xml").getInputStream()))
				+ "(?s)(.*)";
		
		this.email_trucktype = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/email_trucktype.html").getInputStream()));
		this.email_new = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/email_newFormat.html").getInputStream()));
		this.email = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/email.html").getInputStream()));
		this.confirmation = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/mailConfirmation.html").getInputStream()));

	}

	public String getRequestId(String otmResponse) {
		return otmResponse.replaceAll(REQ_FORMAT, "$2");
	}
	
	public String getResponseType(String otmResponse) {
		return otmResponse.replaceAll(RES_FORMAT, "$2");
	}
	
	public String getShipmentId(String otmResponse) {
		return otmResponse.replaceAll(SHP_NUMBER, "$2");
	}
	
	public String getShipmentCount(String otmResponse) {
		if(otmResponse.matches(SHP_FORMAT))
			return otmResponse.replaceAll(SHP_FORMAT, "$2");
		else
			return null;
	}
	
	public String getConfirmationHtml(String confirm) {
		return MessageFormat.format(confirmation, new Object[] {ojetUrl,confirm});
	}
	
	public String getEmail(ShipmentApproval shipmentApproval, String username, String image) {
		 String token = jwtTokenProvider.createToken(username, "Approver");
		 shipmentApproval.getCreatedDate();
		 String html = "<tr><td>"+dateUtil.getCurrentISTString(shipmentApproval.getCreatedDate())+"</td>";
		 html+="<td>Creation</td>";
		 html+="<td>"+shipmentApproval.getAttribute11()+"</td>";
		 html+="<td>"+shipmentApproval.getShipmentGID()+"</td>";
		 html+="<td>"+shipmentApproval.getSourceLocationGID()+"</td>";
		 html+="<td>"+shipmentApproval.getDestLocationGID()+"</td>";
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalWeight())) {
			 Float weight = Float.parseFloat(shipmentApproval.getTotalWeight())/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalVolume())) {
			 Float vol = Float.parseFloat(shipmentApproval.getTotalVolume())/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		
		 html+="<td>"+shipmentApproval.getFirstEquipmnetGroupGID()+"</td>";

		 html+="<td>"+shipmentApproval.getServprovGID()+"</td>";
		 html+="<td>"+shipmentApproval.getReason()+"</td>";
		 html+="<td>"+commonUtils.getShipmentType(shipmentApproval.getShipmentType())+"</td>";
		 html+="<td>"+shipmentApproval.getTown()+"</td>";
		 html+="<td>"+shipmentApproval.getClusterId()+"</td></tr>";
		 html=html.replaceAll("ULF\\.", "");
		 
		 String shipmentGID = shipmentApproval.getShipmentGID();
		 String url = ojetUrl+"/OTMAutomationAPI/otm/shipmentApproval/?token="+token+"&shipmentId="+shipmentGID+"&requestId="+shipmentApproval.getAttribute11()+"&userId="+username+"&status=";
		 String format = MessageFormat.format(email, new Object[] {html,url+"Approved",url+"Rejected", ojetUrl});
		 if(Objects.nonNull(image)) {
			 format = format.replace("</table>", getImageTag(image));
		 }
		 return format;
	}
	
	public String getEmailforApproval(List<ShipmentApproval> shipmentApprovals, String username, String reason, String requestId, String mailtype) {
		 String token = jwtTokenProvider.createToken(username, "Approver");
		 String html="";
		 for(ShipmentApproval shipmentApproval : shipmentApprovals) {
		 html+= "<tr><td>"+dateUtil.getCurrentISTString(shipmentApproval.getCreatedDate())+"</td>";
		 html+="<td>"+mailtype+"</td>";
		 html+="<td>"+requestId+"</td>";
		 html+="<td>"+shipmentApproval.getShipmentGID()+"</td>";
		 html+="<td>"+shipmentApproval.getSourceLocationGID()+"</td>";
		 html+="<td>"+shipmentApproval.getDestLocationGID()+"</td>";
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalWeight())) {
			 Float weight = Float.parseFloat(shipmentApproval.getTotalWeight())/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalVolume())) {
			 Float vol = Float.parseFloat(shipmentApproval.getTotalVolume())/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		
		 html+="<td>"+shipmentApproval.getFirstEquipmnetGroupGID()+"</td>";

		 html+="<td>"+shipmentApproval.getServprovGID()+"</td>";
		 html+="<td>"+reason+"</td>";

		 html+="<td>"+commonUtils.getShipmentType(shipmentApproval.getShipmentType())+"</td>";
		 html+="<td>"+shipmentApproval.getTown()+"</td>";
		 html+="<td>"+shipmentApproval.getClusterId()+"</td></tr>";
		 }
		 html=html.replaceAll("ULF\\.", "");
		 //String shipmentGID = shipmentApproval.getShipmentGID();
		 String url = ojetUrl+"/OTMAutomationAPI/otm/shipmentCancel/?token="+token+"&requestId="+requestId+"&userId="+username+"&status=";
		return MessageFormat.format(email, new Object[] {html,url+"Approved",url+"Rejected", ojetUrl});
	}
	
	public String getEmailForAssign(ShipmentApproval shipmentApproval, String username, ShipmentCreationRequestLog reqLog) {
		 String token = jwtTokenProvider.createToken(username, "Approver");
		 String wght = "";
		 String volume = "";
		 String equp = "";

		 if(Objects.nonNull(reqLog) && Objects.nonNull(reqLog.getOrdersNumbers())) {
			 String[] split = reqLog.getOrdersNumbers().split("-");
			 if(split.length>2) {
				String plannedvalues =  split[2];
				String[] split2 = plannedvalues.split(":");
				if(split2.length>2) {
					wght = split2[0];
					volume = split2[1];
					equp = split2[2];
				}
			 }
		 }
		 String html = "<tr><td>"+dateUtil.getCurrentISTString(shipmentApproval.getCreatedDate())+"</td>";
		 html+="<td>Assign</td>";
		 html+="<td>"+shipmentApproval.getAttribute11()+"</td>";
		 html+="<td>"+shipmentApproval.getShipmentGID()+"</td>";
		 html+="<td>"+shipmentApproval.getSourceLocationGID()+"</td>";
		 html+="<td>"+shipmentApproval.getDestLocationGID()+"</td>";
		 if(NumberUtils.isCreatable(wght)) {
			 Float weight = Float.parseFloat(wght)/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalWeight())) {
			 Float weight = Float.parseFloat(shipmentApproval.getTotalWeight())/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 if(NumberUtils.isCreatable(volume)) {
			 Float vol = Float.parseFloat(volume)/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalVolume())) {
			 Float vol = Float.parseFloat(shipmentApproval.getTotalVolume())/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 html +="<td>"+equp+"</td>";

		 html+="<td>"+shipmentApproval.getFirstEquipmnetGroupGID()+"</td>";
		 html +="<td>"+shipmentApproval.getServprovGID()+"</td>";

		 html+="<td>"+shipmentApproval.getServprovGID()+"</td>";
		 html+="<td>"+shipmentApproval.getReason()+"</td>";
		 html+="<td>"+commonUtils.getShipmentType(shipmentApproval.getShipmentType())+"</td>";
		 html+="<td>"+shipmentApproval.getTown()+"</td>";
		 html+="<td>"+shipmentApproval.getClusterId()+"</td></tr>";
		 html=html.replaceAll("ULF\\.", "");
		 String shipmentGID = shipmentApproval.getShipmentGID();
		 String url = ojetUrl+"/OTMAutomationAPI/otm/shipmentAssign/?token="+token+"&shipmentId="+shipmentGID+"&requestId="+shipmentApproval.getAttribute11()+"&userId="+username+"&status=";
		return MessageFormat.format(email_trucktype, new Object[] {html,url+"Approved",url+"Rejected", ojetUrl});
	}
	
	public String getEmailForEQChange(ShipmentApproval shipmentApproval, String username, String eqpgid, String sergid, String type) {
		 String token = jwtTokenProvider.createToken(username, "Approver");
		 shipmentApproval.getCreatedDate();
		 String html = "<tr><td>"+dateUtil.getCurrentISTString(shipmentApproval.getCreatedDate())+"</td>";
		 html+="<td>"+type+"</td>";
		 html+="<td>"+shipmentApproval.getAttribute11()+"</td>";
		 html+="<td>"+shipmentApproval.getShipmentGID()+"</td>";
		 html+="<td>"+shipmentApproval.getSourceLocationGID()+"</td>";
		 html+="<td>"+shipmentApproval.getDestLocationGID()+"</td>";
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalWeight())) {
			 Float weight = Float.parseFloat(shipmentApproval.getTotalWeight())/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 html +="<td></td>";
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalVolume())) {
			 Float vol = Float.parseFloat(shipmentApproval.getTotalVolume())/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 html +="<td></td>";
		 html+="<td>"+shipmentApproval.getFirstEquipmnetGroupGID()+"</td>";
		 html+="<td>"+eqpgid+"</td>";

		 html+="<td>"+shipmentApproval.getServprovGID()+"</td>";
		 html+="<td>"+sergid+"</td>";

		 html+="<td>"+shipmentApproval.getReason()+"</td>";
		 html+="<td>"+commonUtils.getShipmentType(shipmentApproval.getShipmentType())+"</td>";
		 html+="<td>"+shipmentApproval.getTown()+"</td>";
		 html+="<td>"+shipmentApproval.getClusterId()+"</td></tr>";
		 html=html.replaceAll("ULF\\.", "");
		 String shipmentGID = shipmentApproval.getShipmentGID();
		 String url = ojetUrl+"/OTMAutomationAPI/otm/eqchange/?token="+token+"&shipmentId="+shipmentGID+"&requestId="+shipmentApproval.getAttribute11()+"&userId="+username+"&status=";
		return MessageFormat.format(email_trucktype, new Object[] {html,url+"Approved",url+"Rejected", ojetUrl});
	}
	
	public String getEmailforUnAssign(List<ShipmentApproval> shipmentApprovals, String username, String reason, String requestId, Map<String, String> unAssignmentplannedValues, String image) {
		 String token = jwtTokenProvider.createToken(username, "Approver");
		 String html="";
		 for(ShipmentApproval shipmentApproval : shipmentApprovals) {
		 html+= "<tr><td>"+dateUtil.getCurrentISTString(shipmentApproval.getCreatedDate())+"</td>";
		 html+="<td>Unassign</td>";
		 html+="<td>"+requestId+"</td>";
		 html+="<td>"+shipmentApproval.getShipmentGID()+"</td>";
		 html+="<td>"+shipmentApproval.getSourceLocationGID()+"</td>";
		 html+="<td>"+shipmentApproval.getDestLocationGID()+"</td>";
		 if(NumberUtils.isCreatable(shipmentApproval.getTotalWeight())) {
			 Float weight = Float.parseFloat(shipmentApproval.getTotalWeight())/1000000f;
			 html+="<td>"+String.format("%.03f", weight)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 String planedValues = unAssignmentplannedValues.get(shipmentApproval.getShipmentGID());
		 String planedWeight = "";
		 String planedVolume = "";
		 if(Objects.nonNull(planedValues)) {
			 String[] split = planedValues.split(":");
			 if(split.length>1) {
				 planedWeight=String.format("%.03f", Float.parseFloat(split[0]));
				 planedVolume =String.format("%.03f", Float.parseFloat(split[1])) ;
			 }
		 }
		 html+="<td>"+planedWeight+"</td>";

		 if(NumberUtils.isCreatable(shipmentApproval.getTotalVolume())) {
			 Float vol = Float.parseFloat(shipmentApproval.getTotalVolume())/1000000f;
			 html+="<td>"+String.format("%.03f", vol)+"</td>";
		 } else {
			 html +="<td></td>";
		 }
		 html+="<td>"+planedVolume+"</td>";

		 html+="<td>"+shipmentApproval.getFirstEquipmnetGroupGID()+"</td>";

		 html+="<td>"+shipmentApproval.getServprovGID()+"</td>";
		 html+="<td>"+reason+"</td>";

		 html+="<td>"+commonUtils.getShipmentType(shipmentApproval.getShipmentType())+"</td>";
		 html+="<td>"+shipmentApproval.getTown()+"</td>";
		 html+="<td>"+shipmentApproval.getClusterId()+"</td></tr>";
		 }
		 html=html.replaceAll("ULF\\.", "");
		 //String shipmentGID = shipmentApproval.getShipmentGID();
		 String url = ojetUrl+"/OTMAutomationAPI/otm/shipmentUnAssign/?token="+token+"&requestId="+requestId+"&userId="+username+"&status=";
		 String format = MessageFormat.format(email_new, new Object[] {html,url+"Approved",url+"Rejected", ojetUrl});
		if(Objects.nonNull(image)) {
			 format = format.replace("</table>", getImageTag(image));
		 }
		return format;
	}

	public String getTenderCall(String otmResponse) {
		return otmResponse.replaceAll(TenderCallFormat, "$2");
	}

	public String getSecureResource(String otmResponse) {
		return otmResponse.replaceAll(SecureResourceFormat, "$2");
	}

	public String getShipmentType(String tenderCall, String secureResource) {
		if (TENDER_CALL_TENDER.equals(tenderCall) && (SECURE_RESOURCES_ACCEPTED.equals(secureResource)
				|| SECURE_RESOURCES_TENDERED.equals(secureResource))) {
			return "FTL";
		}
		if ((TENDER_CALL_NO_CALL.equals(tenderCall) || TENDER_CALL_CANCEL.equals(tenderCall))
				&& (SECURE_RESOURCES_NOT_STARTED.equals(secureResource)
						|| SECURE_RESOURCES_WITHDRAWN.equals(secureResource))) {
			return "LTL";
		}
		return null;
	}
	
	private String getImageTag(String image) {
		String[] images = image.split(imageDelimiter);
		List<String> list = Arrays.asList(images);
		StringBuilder imagetag = new StringBuilder("</table>");
		list.forEach( img -> {
			 imagetag.append("<img src=\""+img+"\">");
		});
		return imagetag.toString();
	}
}
