package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.Dual;
import com.unilever.otmbulkautomation.schema.DualSchemaWrapper;
import com.unilever.otmbulkautomation.schema.EquipmentGroupUnAssign;
import com.unilever.otmbulkautomation.schema.EquipmentGroupUnAssignSchemaWrapper;
import com.unilever.otmbulkautomation.schema.LocationRefNum;
import com.unilever.otmbulkautomation.schema.LocationRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderMovement;
import com.unilever.otmbulkautomation.schema.OrderMovementSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnum;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAttributeUpdate;
import com.unilever.otmbulkautomation.schema.ShipmentAttributesUpdates;
import com.unilever.otmbulkautomation.schema.ShipmentCancellationSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentRefnum;
import com.unilever.otmbulkautomation.schema.ShipmentRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentResponseSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentUnAssign;
import com.unilever.otmbulkautomation.schema.ShipmentUnAssignSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentUnassignService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.unassign.movement.getQuery}")
	private String shipmentUnassignMovGetQuery;
	
	@Value("${otm.shipmentrefNum.getQuery}")
	private String shipmentrefNumGetQuery;
	
	@Value("${otm.unassign.shipment.getQuery}")
	private String shipmentUnassignGetQuery;
	
	
	@Value("${otm.unassign.equipmentgroup.getQuery}")
	private String equipmentgroupUnassignGetQuery;
	
	
	@Value("${otm.unassign.locationrefnum.getQuery}")
	private String locRefnumUnassignGetQuery;
	
	
	@Value("${otm.orderrelease.refnum.query}")
	private String ordRefnumUnassignGetQuery;
	
	
	@Value("${otm.unassign.shipment.details.getQuery}")
	private String shipmentUnAssignDetailsQuery;
	
	@Value("${otm.loadability.check.query1}")
	private String loadabilityCheckQuery1;
	
	@Value("${otm.loadabilty.check.query2}")
	private String loadabilityCheckQuery2;
	
	
	@Value("${otm.loadabilty.percentage.query}")
	private String loadabilityPercentageCheck;
	
	@Value("${otm.loadabilty.percentage.query1}")
	private String loadabilityPercentageCheck1;
	
	@Value("${otm.loadabilty.percentage.query2}")
	private String loadabilityPercentageCheck2;
	
	@Value("${otm.loadabilty.ordertype.query}")
	private String loadabilityordertype;
	
	@Value("${otm.loadabilty.lastloc.query}")
	private String loadabilitylastLoc;
	
	@Value("${otm.loadabilty.planparam.query}")
	private String loadabilityPlanparam;
	
	@Value("${otm.loadabilty.utiliz.query}")
	private String loadabilityUtilz;
	
	
	
	@Value("${otm.loadabilty.ptl.query}")
	private String loadabilityPtlCheck;
	
	@Value("${otm.loadabilty.orders.shipmentcount.query}")
	private String loadabilityOrderShipmentCountQuery;
	
	@Value("${otm.loadability.shipment.droppoints.query}")
	private String loadabilityShipmentDropQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	OTMService otmservice;
	
	@Autowired
	OTMShipmentConstants otmShpConstants;
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;
	
	@Autowired
	OrderReleaseService orderReleaseService;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	UserRepository userRepo;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	@Autowired
	DBServletPojoMapper mapper;
	
	@Autowired
	DBServletRestUtil restUtil;
	
	ObjectMapper objMapper = new ObjectMapper();
		
	
	public ShipmentCreationRequest postShipmentForApproval(String username, OrderReleasesSchemaWrapper orders) {
		String orderReleaseType = orders.getOrderReleaseType();
		String reason = orders.getReason();
		List<OrderReleases> orderReleases = orders.getOrderReleases();
		ShipmentCreationRequest shipmentCreationRequest = new ShipmentCreationRequest();
		Map<String, List<OrderReleases>> unAssignmentOrders = new HashMap<>();
		Map<String, List<String>> unAssignmentordersListMap = new HashMap<>();
		Map<String, ShipmentUnAssign> unAssignmentshipments = new HashMap<>();
		Map<String, EquipmentGroupUnAssign> unAssignmentEqup = new HashMap<>();
		Map<String, String> unAssignmentlocrefnum = new HashMap<>();
		Map<String, Map<String, String>> loadabilityPercentage = new HashMap<>();
		Map<String, String> unAssignmentplannedValues = new HashMap<>();
		List<String> logList = new ArrayList<>();
		Set<String> eqpGrpIds = new HashSet<>();
		List<String> locgids = new ArrayList<>();
		List<String> locxids = new ArrayList<>();
		List<String> destlocgids = new ArrayList<>();

		List<String> ordgids = new ArrayList<>();
		try {
			if (!CollectionUtils.isEmpty(orderReleases) && Objects.nonNull(orderReleaseType)) {
				orderReleases.stream().forEach(ord -> {
					if (Objects.nonNull(ord.getFirstEqupmentGroupGid())) {
						eqpGrpIds.add(ord.getFirstEqupmentGroupGid());
					}
					if (Objects.nonNull(ord.getSourceLocationGID())) {
						locgids.add(ord.getSourceLocationGID());
						destlocgids.add(ord.getDestinationLocationGID());
						locxids.add(ord.getSourceLocationGID().replace("ULF.", ""));
					}
					if (Objects.nonNull(ord.getOrderReleaseGID())) {
						ordgids.add(ord.getOrderReleaseGID());
					}
					if (Objects.nonNull(ord.getShipmentGid())) {
						if (unAssignmentOrders.containsKey(ord.getShipmentGid())) {
							List<OrderReleases> list = unAssignmentOrders.get(ord.getShipmentGid());
							List<String> orderList = unAssignmentordersListMap.get(ord.getShipmentGid());
							list.add(ord);
							orderList.add(ord.getOrderReleaseGID());
						} else {
							List<OrderReleases> ords = new ArrayList<>();
							List<String> listorders = new ArrayList<>();
							listorders.add(ord.getOrderReleaseGID());
							unAssignmentordersListMap.put(ord.getShipmentGid(), listorders);
							ords.add(ord);
							unAssignmentOrders.put(ord.getShipmentGid(), ords);
						}
					}
				});
				Set<String> shipids = unAssignmentOrders.keySet();
				for (String shipid : shipids) {
					String query = MessageFormat.format(shipmentUnassignMovGetQuery, new Object[] { shipid });
					String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_MOVEMENT", query);
					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							OrderMovementSchemaWrapper.class);
					if (Objects.isNull(dbServletMappedPojo.getError())) {
						List<OrderMovement> orderMovements = ((OrderMovementSchemaWrapper) dbServletMappedPojo)
								.getOrderMovements();
						if (unAssignmentOrders.containsKey(shipid)&& orderMovements.size() == unAssignmentOrders.get(shipid).size()) {
							shipmentCreationRequest.setFailureReason("Please use Cancellation module");
							return shipmentCreationRequest;
						}

					}

				}
//				String loadabilityPercentageRefNum = getLoadabilityPercentageRefNum(orderReleaseType);
//				if (StringUtils.isNotBlank(loadabilityPercentageRefNum) && !locgids.isEmpty()) {
//					String query = MessageFormat.format(locRefnumUnassignGetQuery,
//							new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(locgids)),
//									loadabilityPercentageRefNum });
//					String dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
//					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
//							LocationRefnumSchemaWrapper.class);
//					List<String> gids = new ArrayList<>();
//					if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
//						List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
//								.getLocationRefnums();
//						if (!CollectionUtils.isEmpty(locationRefnums)) {
//							locationRefnums.forEach(loc -> {
//								unAssignmentlocrefnum.put(loc.getLocationGid(), loc.getLocationRefNumValue());
//							});
//						}
//					}
//				}
				if (!CollectionUtils.isEmpty(shipids)) {
					String query = MessageFormat.format(shipmentUnassignGetQuery,
							new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(shipids)) });
					String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							ShipmentUnAssignSchemaWrapper.class);
					List<String> gids = new ArrayList<>();
					if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
						List<ShipmentUnAssign> shipments = ((ShipmentUnAssignSchemaWrapper) dbServletMappedPojo)
								.getShipments();
						if (!CollectionUtils.isEmpty(shipments)) {
							shipments.forEach(shp -> {
								unAssignmentshipments.put(shp.getShipmentGid(), shp);
							});
						}
					}
				}
				if (!CollectionUtils.isEmpty(eqpGrpIds)) {
					String query = MessageFormat.format(equipmentgroupUnassignGetQuery,
							new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(eqpGrpIds)) });
					String dbString = dbServletRestUtil.postGetQueryToDBServlet("EQUIPMENT_GROUP", query);
					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							EquipmentGroupUnAssignSchemaWrapper.class);
					List<String> gids = new ArrayList<>();
					if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
						List<EquipmentGroupUnAssign> equipmentGroups = ((EquipmentGroupUnAssignSchemaWrapper) dbServletMappedPojo)
								.getEquipmentGroups();
						if (!CollectionUtils.isEmpty(equipmentGroups)) {
							equipmentGroups.forEach(equp -> {
								unAssignmentEqup.put(equp.getEquipmentGroupGid(), equp);
							});
						}
					}
				}
				boolean needApproval = false;
				boolean needLoadabilityCheck = false;
				//***** new loadability logic 
				if (!CollectionUtils.isEmpty(shipids)) {
					String query = MessageFormat.format(loadabilityCheckQuery1,
							new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(shipids)) });
					String dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
					SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							DualSchemaWrapper.class);
					if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
						 query = MessageFormat.format(loadabilityCheckQuery2,
								new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(shipids)) });
						 dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
						 dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
								DualSchemaWrapper.class);
						if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
							needLoadabilityCheck = true;
						}
					}
				}
				if (needLoadabilityCheck) {
					Map<String, String> loadabiltyCalculation = getLoadabiltyCalculation(shipids,
							logList, unAssignmentOrders, unAssignmentshipments, unAssignmentEqup,
							unAssignmentplannedValues);
					if (OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseType)) {
						getLoadabilityPercentage(shipids, loadabilityPercentageCheck, loadabilityPercentage);
						// PTL check
						boolean ptlCheck = false;
						if (!CollectionUtils.isEmpty(shipids)) {
							String query = MessageFormat.format(loadabilityPtlCheck, new Object[] {
									commonUtil.getCommaDelimiterString(new ArrayList<String>(shipids)) });
							String dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
							SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
									DualSchemaWrapper.class);
							if (Objects.nonNull(dbServletMappedPojo)
									&& Objects.isNull(dbServletMappedPojo.getError())) {
								ptlCheck = true;
							}
						}
						if (ptlCheck) {
							Map<String, Float> ordersShipmentcount = new HashMap<>();
							if (!CollectionUtils.isEmpty(shipids)) {
								for (String shipid : unAssignmentordersListMap.keySet()) {
									String query = MessageFormat.format(loadabilityOrderShipmentCountQuery,
											new Object[] { commonUtil
													.getCommaDelimiterString(unAssignmentordersListMap.get(shipid)) });
									String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
									SchemaWrapper dbServletMappedPojo = dbServletPojoMapper
											.getDBServletMappedPojo(dbString, ShipmentUnAssignSchemaWrapper.class);
									List<String> gids = new ArrayList<>();
									if (Objects.nonNull(dbServletMappedPojo)
											&& Objects.isNull(dbServletMappedPojo.getError())) {
										List<ShipmentUnAssign> shipments = ((ShipmentUnAssignSchemaWrapper) dbServletMappedPojo)
												.getShipments();
										float totalCount = 0f;
										if (!CollectionUtils.isEmpty(shipments)) {
											for (ShipmentUnAssign ord : shipments) {
												if (Objects.nonNull(ord)
														&& NumberUtils.isCreatable(ord.getTotalShipUnitCount())) {
													totalCount += Float.parseFloat(ord.getTotalShipUnitCount());
												}
											}
											ordersShipmentcount.put(shipid, totalCount);
											if (loadabilityPercentage.containsKey(shipid)) {
												Map<String, String> pertmap = loadabilityPercentage.get(shipid);
												if (pertmap.containsKey("ULF.MINIMUM_CASE_LOAD")) {
													String pertage = pertmap.get("ULF.MINIMUM_CASE_LOAD");
													if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
														float percentage = Float.parseFloat(pertage);
														ShipmentUnAssign shipmentUnAssign = unAssignmentshipments
																.get(shipid);
														String totalShipUnitCount = shipmentUnAssign
																.getTotalShipUnitCount();
														if (Objects.nonNull(totalShipUnitCount)
																&& NumberUtils.isCreatable(totalShipUnitCount)) {
															float remShipUnit = Float.parseFloat(totalShipUnitCount)
																	- totalCount;
															if (remShipUnit < percentage) {
																needApproval = true;
																break;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						} else {
							boolean dropCheck = true;
							float customDecValue = 0f;
							float loadPercentage = 0f;
							if (!CollectionUtils.isEmpty(shipids)) {
								for (String shipid : shipids) {
									if (loadabilityPercentage.containsKey(shipid)) {
										Map<String, String> pertmap = loadabilityPercentage.get(shipid);
										if (pertmap.containsKey("ULF.ULF_CUST_DELCARED_VALUE")) {
											String pertage = pertmap.get("ULF.ULF_CUST_DELCARED_VALUE");
											if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
												customDecValue = Float.parseFloat(pertage);
											}
										}
										if (pertmap.containsKey("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE")) {
											String pertage = pertmap
													.get("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE");
											if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
												loadPercentage = Float.parseFloat(pertage);
											}
										}
										if (customDecValue == 0f && loadPercentage == 0f) {
											dropCheck = false;
										}
									}
								}
							}
							if (dropCheck && !CollectionUtils.isEmpty(shipids)) {
								for (String shipid : shipids) {
									Map<String, Set<String>> dropmap = new HashMap();
									String query = MessageFormat.format(loadabilityShipmentDropQuery,
											new Object[] { shipid });
									String dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM",
											query);
									SchemaWrapper dbServletMappedPojo = dbServletPojoMapper
											.getDBServletMappedPojo(dbString, LocationRefnumSchemaWrapper.class);
									Set<String> gids = new HashSet<>();
									Set<String> destgids = new HashSet<>();

									if (Objects.nonNull(dbServletMappedPojo)
											&& Objects.isNull(dbServletMappedPojo.getError())) {
										List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
												.getLocationRefnums();
										if (!CollectionUtils.isEmpty(locationRefnums)) {

											locationRefnums.forEach(refnum -> {
												gids.add(refnum.getLocationGid());
											});
											List<OrderReleases> list = unAssignmentOrders.get(shipid);
											if (!CollectionUtils.isEmpty(list)) {
												list.forEach(ord -> {
													destgids.add(ord.getDestinationLocationGID());
												});
												gids.removeAll(destgids);
												if (gids.size() > 1) {
													dropCheck = false;
												}
											}
										}
									}
								}
							}
							if (dropCheck) {
								
								if (!CollectionUtils.isEmpty(shipids)) {
									for (String shipid : shipids) {
										String calculatedValues = loadabiltyCalculation.get(shipid);
										if (Objects.nonNull(calculatedValues)) {
											String[] splitValues = calculatedValues.split(":");
											Float perVal = 0f;
											Float decareVal = 0f;
											if (Objects.nonNull(splitValues[0])
													&& NumberUtils.isCreatable(splitValues[0])) {
												perVal = Float.parseFloat(splitValues[0]);
											}
											if (Objects.nonNull(splitValues[1])
													&& NumberUtils.isCreatable(splitValues[1])) {
												decareVal = Float.parseFloat(splitValues[1]);
											}
											if (perVal < loadPercentage && decareVal < customDecValue) {
												needApproval = true;
												break;
											}
										}
									}
								}
							} else {
								getLoadabilityPercentage(shipids, loadabilityPercentageCheck1, loadabilityPercentage);
								float solp = 0f;
								float solmp = 0f;
								float mainper = 0f;
								float maxpert = 0f;
								if (!CollectionUtils.isEmpty(shipids)) {
									
									for (String shipid : shipids) {
										if (loadabilityPercentage.containsKey(shipid)) {
											Map<String, String> pertmap = loadabilityPercentage.get(shipid);
											if (pertmap.containsKey("ULF.ULF_SOB_BULK_PLAN_LOADABILITY")) {
												String pertage = pertmap.get("ULF.ULF_SOB_BULK_PLAN_LOADABILITY");
												if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
													solp = Float.parseFloat(pertage);
												}
											}
											if (pertmap
													.containsKey("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE")) {
												String pertage = pertmap
														.get("ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE");
												if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
													solmp = Float.parseFloat(pertage);
												}
											}
											mainper = solp;
											if (solp == 0f) {
												mainper = solmp;
											}
											String calculatedValues = loadabiltyCalculation.get(shipid);
											if (Objects.nonNull(calculatedValues)) {
												String[] splitValues = calculatedValues.split(":");
												Float perVal = 0f;
												if (Objects.nonNull(splitValues[0])
														&& NumberUtils.isCreatable(splitValues[0])) {
													perVal = Float.parseFloat(splitValues[0]);
												}
												if (pertmap
														.containsKey("ULF.ULF_SECONDARY_OUTBOUND_MAX_LOADABILITY_PERCENTAGE")) {
													String maxper = pertmap
															.get("ULF.ULF_SECONDARY_OUTBOUND_MAX_LOADABILITY_PERCENTAGE");
													if (Objects.nonNull(maxper) && NumberUtils.isCreatable(maxper)) {
														maxpert = Float.parseFloat(maxper);
													}
												}
												if ((perVal < mainper && maxpert == 0f) || (perVal < mainper && perVal < maxpert)) {
													
													needApproval = true;
													break;
												}
											}
										}
									}
								}
							}
						}
					} else {
						getLoadabilityPercentage(shipids, loadabilityPercentageCheck2, loadabilityPercentage);
						float plp = 0f;
						Float perVal = 0f;
						if (!CollectionUtils.isEmpty(shipids)) {
							for (String shipid : shipids) {
								if (loadabilityPercentage.containsKey(shipid)) {
									Map<String, String> pertmap = loadabilityPercentage.get(shipid);
									if (pertmap.containsKey("ULF.ULF_PALLET_LOADABILITY_PERCENT")) {
										String pertage = pertmap.get("ULF.ULF_PALLET_LOADABILITY_PERCENT");
										if (Objects.nonNull(pertage) && NumberUtils.isCreatable(pertage)) {
											plp = Float.parseFloat(pertage);
										}
									}
								}
								String calculatedValues = loadabiltyCalculation.get(shipid);
								if (Objects.nonNull(calculatedValues)) {
									String[] splitValues = calculatedValues.split(":");
									if (Objects.nonNull(splitValues[0]) && NumberUtils.isCreatable(splitValues[0])) {
										perVal = Float.parseFloat(splitValues[0]);
									}

								}
								String orderType = "";
								List<Dual> dual = null;
								Dual dualObj = null;
								String query = MessageFormat.format(loadabilityordertype, new Object[] { shipid });
								String dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
								SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
										DualSchemaWrapper.class);
								if (Objects.nonNull(dbServletMappedPojo)
										&& Objects.isNull(dbServletMappedPojo.getError())) {
									dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
									dualObj = dual.get(0);
									if (Objects.nonNull(dualObj)) {
										orderType = dualObj.getOutput();
									}
								}
								query = MessageFormat.format(loadabilitylastLoc, new Object[] { shipid });
								dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
								dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
										DualSchemaWrapper.class);
								if (Objects.nonNull(dbServletMappedPojo)
										&& Objects.isNull(dbServletMappedPojo.getError())) {
									dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
									dualObj = dual.get(0);
									if (Objects.nonNull(dualObj)) {
										String lastpickup = dualObj.getOutput();
										query = MessageFormat.format(loadabilityPlanparam,
												new Object[] { shipid, lastpickup });
										dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
										dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
												DualSchemaWrapper.class);
										if (Objects.nonNull(dbServletMappedPojo)
												&& Objects.isNull(dbServletMappedPojo.getError())) {
											dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
											dualObj = dual.get(0);
											if (Objects.nonNull(dualObj)) {
												String loadpercentage = dualObj.getOutput();
												ShipmentUnAssign shipmentUnAssign = unAssignmentshipments.get(shipid);

												if (Objects.nonNull(shipmentUnAssign)
														&& "ULF.ULF_PLANNING_PARAMETER_ERU"
																.equals(shipmentUnAssign.getPlanningParameterSetGid())
														&& OTMConstants.PRIMARY_OUTBOUND_DELIVERY
																.equals(orderReleaseType)
														&& orderType.equals("PT")) {
													query = MessageFormat.format(loadabilityUtilz,
															new Object[] { shipid });
													dbString = dbServletRestUtil.postGetQueryToDBServlet("DUAL", query);
													dbServletMappedPojo = dbServletPojoMapper
															.getDBServletMappedPojo(dbString, DualSchemaWrapper.class);
													if (Objects.nonNull(dbServletMappedPojo)
															&& Objects.isNull(dbServletMappedPojo.getError())) {
														dual = ((DualSchemaWrapper) dbServletMappedPojo).getDual();
														dualObj = dual.get(0);
														if (Objects.nonNull(dualObj)) {
															String eruPerctge = dualObj.getOutput();
															if (Objects.nonNull(eruPerctge)
																	&& NumberUtils.isCreatable(eruPerctge)) {
																float euperVal = Float.parseFloat(eruPerctge) * 100;
																if (euperVal < plp) {
																	if (Objects.nonNull(loadpercentage) && NumberUtils
																			.isCreatable(loadpercentage)) {
																		float loadperVal = Float
																				.parseFloat(loadpercentage) * 100;
																		if (perVal < loadperVal) {
																			needApproval = true;
																		}
																	}
																}
															}
														}
													}
												} else {
													if (Objects.nonNull(loadpercentage)
															&& NumberUtils.isCreatable(loadpercentage)) {
														float loadperVal = Float.parseFloat(loadpercentage) * 100;
														if (perVal < loadperVal) {
															needApproval = true;
														}
													}
												}
											}
										}
									}
								}

							}
						}
					}
				}
				//***********
				

				shipmentCreationRequest.setUsername(username);
				shipmentCreationRequest.setStatus(OTMConstants.OPEN);
				if (needApproval) {
					shipmentCreationRequest.setStatus(OTMConstants.APPROVAL_PENDING);
				}
				shipmentCreationRequest.setRequestType("Unassign");
				shipmentCreationRequest.setReasons(reason);
				LocalDateTime currentISTLocalDateTime = dateUtil.getCurrentISTLocalDateTime();
				shipmentCreationRequest.setCreatedDateTime(currentISTLocalDateTime);
				shipmentCreationRequest.setModifiedDateTime(currentISTLocalDateTime);
				shipmentCreationRequest.setNumberOfOrders(shipids.size());
				shipmentCreationRequest.setNumberOfShipments(shipids.size());
				String shipmentRequestId = commonUtil
						.getSequencePrefix(String.valueOf(repository.getShipmentRequestValue()));
				shipmentCreationRequest.setRequestNumber(shipmentRequestId);

				shipmentCreationRequest.setDepotId(String.join(",", locgids));
				shipmentCreationRequest.setShipmentType(orderReleaseType);
				shipmentCreationRequest.setImage(orders.getImage());
				ShipmentCreationRequestLog shipmentlog = new ShipmentCreationRequestLog();
				shipmentlog.setRequestNumber(shipmentRequestId);
				shipmentlog.setOrdersNumbers(String.join(",", logList));
				repositoryLog.save(shipmentlog);
				repository.save(shipmentCreationRequest);
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"Unassign creation with req id : " + shipmentRequestId + " shipments : " + logList, "INFO"));
				deleteShipmentRefnum(new ArrayList<String>(shipids));
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>(shipids),
						otmShpConstants.getShipmentUnAssignGid(), shipmentRequestId, "I");
				deleteOrderReleaseRefnum(ordgids);
				createOrderReleaseRefnum(ordgids, shipmentRequestId);
				if (needApproval) {
					updateShipmentRequestId(shipmentRequestId, new ArrayList<String>(shipids));
					shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>(shipids),
							otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentUnassignPending(), "I");
					String shpmtType = commonUtil.getShipmentType(orderReleaseType);
					List<User> users = userRepo.findBySourceLocation(locxids, "Approver", shpmtType);
					ShipmentApprovalSchemaWrapper approvalShipmentsFromOtm = otmservice
							.getApprovalShipmentsFromOtm(new ArrayList<String>(shipids));

					if (!CollectionUtils.isEmpty(users)
							&& !CollectionUtils.isEmpty(approvalShipmentsFromOtm.getShipments())) {
						List<String> emails = users.stream().map(user -> user.getEmailId())
								.collect(Collectors.toList());

						for (User user : users) {
							String module = user.getModule();
							//if (Objects.nonNull(module) && StringUtils.containsIgnoreCase(module, "modification")) {
								emailUtil.sendEmailWithAttachment("OTM Delivery Removal - Action",
										otmUtil.getEmailforUnAssign(approvalShipmentsFromOtm.getShipments(),
												user.getUsername(), reason, shipmentRequestId,
												unAssignmentplannedValues, orders.getImage()),
										user.getEmailId());
						//	}
						}
						logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
								"sending Email for UnAssign req id : " + shipmentRequestId + " for users : " + emails,
								"INFO"));

					}
				}

				else {
					updateShipmentAndOrdersRequestId(shipmentRequestId, new ArrayList<String>(shipids), ordgids);
				}

			}
		} catch (Exception e) {
			shipmentCreationRequest.setStatus("Failed");
			shipmentCreationRequest.setFailureReason("Unassign Creation Error");
			repository.updateShipmentResponses(shipmentCreationRequest.getRequestNumber(), null,
					shipmentCreationRequest.getStatus(), null, shipmentCreationRequest.getFailureReason(),
					shipmentCreationRequest.getNumberOfShipments(), dateUtil.getCurrentISTLocalDateTime());
			logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
					"Error  for Unassignment req id : " + shipmentCreationRequest.getRequestNumber() + e.getMessage(),
					"ERROR"));
		}
		return shipmentCreationRequest;
	}
		
	
	private String getLoadabilityPercentageRefNum(String orderType) {
		switch(orderType) {
		case OTMConstants.SECONDARY_OUTBOUND_DELIVERY: return "ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE";
		case OTMConstants.PRIMARY_OUTBOUND_DELIVERY: return "ULF.ULF_PRIMARY_OUTBOUND_LOADABILITY_PERCENTAGE";
		case OTMConstants.SECONDARY_DIRECT_DISPATCH_DELIVERY: return "ULF.ULF_DIRECT_DISPATCH_LOADABILITY_PERCENTAGE";
		default : return "";
		}
	}
	
	private float getFractionValue(String code) {
		switch(code) {
		case "GRM": return 1000000f;
		case "KG": return 1000f;
		case "CMQ": return 1000000f;
		case "DMQ": return 1000f;
		case "HLT": return 10f;
		default : return 1000000f;
		}
	}
	
	private void deleteShipmentRefnum(List<String> shipgids) {
		String refquery = MessageFormat.format(shipmentrefNumGetQuery,
				new Object[] { commonUtil.getCommaDelimiterString(shipgids),
						otmShpConstants.getShipmentUnAssignGid() });
		String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", refquery);
		SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,
				ShipmentRefnumSchemaWrapper.class);
		if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
			List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo)
					.getShipmentRefnums();
			if (!CollectionUtils.isEmpty(shipmentRefnums)) {
				String dbServletMappedXml = mapper
						.getDBServletMappedXml(((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo));
				String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D",
						dbServletMappedXml);
				if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
					log.error("Error Deleting the " + otmShpConstants.getShipmentUnAssignGid()
							+ " shipmentids : " + shipgids);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
							"Error Deleting the " + otmShpConstants.getShipmentUnAssignGid()
									+ " shipmentids : " + shipgids,
							"ERROR"));
				}
			}
		}
	}
	
	
	private void deleteOrderReleaseRefnum(List<String> orderids) {
		String refquery = MessageFormat.format(ordRefnumUnassignGetQuery,
				new Object[] { 
						otmShpConstants.getOrderReleaseUnassignRefNumQualGid(), commonUtil.getCommaDelimiterString(orderids) });
		String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE_REFNUM", refquery);
		SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,
				OrderReleaseRefnumSchemaWrapper.class);
		if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
			 List<OrderReleaseRefnum> orderReleaseRefnums = ((OrderReleaseRefnumSchemaWrapper) refdbServletMappedPojo)
					.getOrderReleaseRefnums();
			if (!CollectionUtils.isEmpty(orderReleaseRefnums)) {
				String dbServletMappedXml = mapper
						.getDBServletMappedXml(((OrderReleaseRefnumSchemaWrapper) refdbServletMappedPojo));
				String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D",
						dbServletMappedXml);
				if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
					log.error("Error Deleting the " + otmShpConstants.getOrderReleaseUnassignRefNumQualGid()
							+ " orderids : " + orderids);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
							"Error Deleting the " + otmShpConstants.getOrderReleaseUnassignRefNumQualGid()
									+ " orderids : " + orderids,
							"ERROR"));
				}
			}
		}
	}
	
	/*
	 * createOrderReleaseRefnum
	 */
	public void createOrderReleaseRefnum(List<String> orderReleasesList, String requestId) {
		log.info("START createOrderReleaseRefnum");
		ArrayList<OrderReleaseRefnum> refnumList = new ArrayList<OrderReleaseRefnum>();
		orderReleasesList.forEach(orderRelease -> {
			OrderReleaseRefnum orderReleaseRefnum = new OrderReleaseRefnum();
			orderReleaseRefnum.setOrderReleaseGid(orderRelease);
			orderReleaseRefnum.setOrderReleaseRefnumQualGid(otmShpConstants.getOrderReleaseUnassignRefNumQualGid());
			orderReleaseRefnum.setOrderReleaseRefnumValue(requestId);
			orderReleaseRefnum.setDomainName(otmShpConstants.getDomainName());
			refnumList.add(orderReleaseRefnum);
		});
		OrderReleaseRefnumSchemaWrapper orderReleaseRefnumSchemaWrapper = new OrderReleaseRefnumSchemaWrapper();
		orderReleaseRefnumSchemaWrapper.setOrderReleaseRefnums(refnumList);
		String dbServletMappedXml = mapper.getDBServletMappedXml(orderReleaseRefnumSchemaWrapper);
		String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("I", dbServletMappedXml);
		if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
			logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), otmShpConstants.getOrderReleaseUnassignRefNumQualGid() +" Error creating OrderReleaseRefnum"+orderReleasesList+" req id : "+requestId, "ERROR"));
		}
		log.info("END createOrderReleaseRefnum");
	}
	
	
	public void updateShipmentAndOrdersRequestId(String shipmentRequestId, List<String> shipids, List<String> orders) {
		
		for (String gid : shipids) {
			try {
				ShipmentAttributesUpdates attrUpdate = new ShipmentAttributesUpdates();
				attrUpdate.setAttribute11(shipmentRequestId);
				attrUpdate.setAttribute12("UNASSIGN");
				attrUpdate.setShipmentXid(gid.replaceAll("ULF.", ""));
				String update = objMapper.writeValueAsString(attrUpdate);
				String rest = "shipments/" + gid;
				dbServletRestUtil.postQueryToRestOTM(rest, update);
			} catch (Exception e) {
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"Error Updating attribute11 rest :" + gid + " requestid : " + shipmentRequestId,
						"ERROR"));
			}
		}
	}
	
	public void updateShipmentRequestId(String shipmentRequestId, List<String> shipids) {
		
		for (String gid : shipids) {
			try {
				ShipmentAttributeUpdate attrUpdate = new ShipmentAttributeUpdate();
				attrUpdate.setAttribute11(shipmentRequestId);
				attrUpdate.setShipmentXid(gid.replaceAll("ULF.", ""));
				String update = objMapper.writeValueAsString(attrUpdate);
				String rest = "shipments/" + gid;
				dbServletRestUtil.postQueryToRestOTM(rest, update);
			} catch (Exception e) {
				logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
						"Error Updating attribute11 rest :" + gid + " requestid : " + shipmentRequestId,
						"ERROR"));
			}
		}
	}
	
	public SchemaWrapper getOrderForShipmentUnAssign(String reqestId, String shipmentid) {
		ShipmentCreationRequestLog findByRequestNumber = repositoryLog.findByRequestNumber(reqestId);
		if(Objects.nonNull(findByRequestNumber)) {
			String ordersNumbers = findByRequestNumber.getOrdersNumbers();
			String[] split = ordersNumbers.split(",");
			List<String> shipmentordIds = Arrays.asList(split);
			for(String id : shipmentordIds) {
				String[] ordship = id.split("-");
				if(ordship.length>2) {
					if(ordship[0].equals(shipmentid)) {
						String[] orders = ordship[2].split(":");
						List<String> ordersList = Arrays.asList(orders);
						return orderReleaseService.getOrderReleasesFromOtmForUnAssignmentApproval(ordersList);
					}
				}
			}
		}
		return null;
	}
	
	public List<ShipmentApproval> postUnAssignByShipment(List<ShipmentApproval> shipments, String status, String userId) {
		if(!CollectionUtils.isEmpty(shipments)) {
			shipments.forEach(ship ->{
				ShipmentCreationRequest shipment = repository.findByRequestNumber(ship.getAttribute11());

			if (OTMConstants.APPROVED.equals(status)) {
				ShipmentCreationRequestLog findByRequestNumber = repositoryLog.findByRequestNumber(ship.getAttribute11());
				List<String> ordersList = null;
				if(Objects.nonNull(findByRequestNumber)) {
					String ordersNumbers = findByRequestNumber.getOrdersNumbers();
					String[] split = ordersNumbers.split(",");
					List<String> shipmentordIds = Arrays.asList(split);
					for(String id : shipmentordIds) {
						String[] ordship = id.split("-");
						if(ordship.length>2) {
							if(ordship[0].equals(ship.getShipmentGID())) {
								String[] orders = ordship[2].split(":");
								ordersList = Arrays.asList(orders);
							}
						}
					}
				}
				List<OrderReleases> orderReleases = ship.getOrderReleases();
				if(!CollectionUtils.isEmpty(orderReleases)) {
					List<String> ordlist = orderReleases.stream().map(ord -> ord.getOrderReleaseGID()).collect(Collectors.toList());
					if(Objects.nonNull(ordersList)) {
						List<String> ordgids = ordersList.stream().filter(ordgid -> !ordlist.contains(ordgid)).collect(Collectors.toList());
						if(!CollectionUtils.isEmpty(ordgids)) {
							deleteOrderReleaseRefnum(ordgids);
						}
					}

					updateShipmentAndOrdersRequestId(ship.getAttribute11(), new ArrayList<String>() {{add(ship.getShipmentGID());}}, ordlist);
					
				} else {
					if(Objects.nonNull(ordersList)) {
						updateShipmentAndOrdersRequestId(ship.getAttribute11(), new ArrayList<String>() {{add(ship.getShipmentGID());}}, ordersList);
					}

				}

			} else {
				
				repository.updateShipmentApprovalStatus(ship.getAttribute11(), status, dateUtil.getCurrentISTLocalDateTime());
			}
			if(Objects.nonNull(shipment)) {
				String track = ship.getShipmentGID() + ":" + userId + ":" + status;
				String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
				repository.updateShipmentApprovalTracking(ship.getAttribute11(), approvalTracking, dateUtil.getCurrentISTLocalDateTime());
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(ship.getShipmentGID());}},
						otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentUnassignPending(), "D");
			}
		});
		
		return shipments;
		}
		return null;
	}
	
	public SchemaWrapper getShipmentDetailsFromOtm(String requestId) {
		if (Objects.nonNull(requestId)) {
			String query = MessageFormat.format(shipmentUnAssignDetailsQuery, new Object[] { requestId });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentResponseSchemaWrapper.class);
		} else {
			return null;
		}
	}
	
	private Map<String,String> getLoadabiltyCalculation(Set<String> shipids, List<String> logList,
			Map<String, List<OrderReleases>> unAssignmentOrders, Map<String, ShipmentUnAssign> unAssignmentshipments,
			Map<String, EquipmentGroupUnAssign> unAssignmentEqup,
			Map<String, String> unAssignmentplannedValues) {
			Map<String,String> shipPercentage = new HashMap();
		for (String shipid : shipids) {
			List<OrderReleases> ordList = unAssignmentOrders.get(shipid);
			OrderReleases order = ordList.get(0);
			String sourceLocationGID = order.getSourceLocationGID();
			String firstEqupmentGroupGid = order.getFirstEqupmentGroupGid();
			String locgid = order.getSourceLocationGID();
			Float weight = 0f;
			Float volume = 0f;
			Float declaredvalue = 0f;
			List<String> ordsList = new ArrayList<>();
			for (OrderReleases ords : ordList) {
				String totalWeight = ords.getTotalWeight();
				String totalVolume = ords.getTotalVolume();
				String totalDeclaredValue = ords.getTotalDeclaredValue();
				ordsList.add(ords.getOrderReleaseGID());
				if (Objects.nonNull(totalWeight) && NumberUtils.isCreatable(totalWeight)) {
					weight += Float.parseFloat(totalWeight) / 1000000f;
				}
				if (Objects.nonNull(totalVolume) && NumberUtils.isCreatable(totalVolume)) {
					volume += Float.parseFloat(totalVolume) / 1000000f;
				}
				if (Objects.nonNull(totalDeclaredValue) && NumberUtils.isCreatable(totalDeclaredValue)) {
					declaredvalue += Float.parseFloat(totalDeclaredValue);
				}
			}
			ShipmentUnAssign shipmentUnAssign = unAssignmentshipments.get(shipid);
			if (Objects.nonNull(shipmentUnAssign) && Objects.nonNull(shipmentUnAssign.getTotalVolumeUomCode())
					&& Objects.nonNull(shipmentUnAssign.getTotalWeightUomCode())
					&& NumberUtils.isCreatable(shipmentUnAssign.getTotalWeight())
					&& NumberUtils.isCreatable(shipmentUnAssign.getTotalVolume())) {
				weight = (Float.parseFloat(shipmentUnAssign.getTotalWeight())
						/ getFractionValue(shipmentUnAssign.getTotalWeightUomCode())) - weight;
				volume = (Float.parseFloat(shipmentUnAssign.getTotalVolume())
						/ getFractionValue(shipmentUnAssign.getTotalVolumeUomCode())) - volume;
				if(NumberUtils.isCreatable(shipmentUnAssign.getTotalDeclaredValue())
						&& NumberUtils.isCreatable(shipmentUnAssign.getTotalDeclaredValue())) {
					declaredvalue = Float.parseFloat(shipmentUnAssign.getTotalDeclaredValue()) - declaredvalue;
				}

			}
			EquipmentGroupUnAssign equipmentGroupUnAssign = unAssignmentEqup.get(firstEqupmentGroupGid);
			if (Objects.nonNull(equipmentGroupUnAssign) && Objects.nonNull(equipmentGroupUnAssign.getEffVolumeUomCode())
					&& Objects.nonNull(equipmentGroupUnAssign.getEffWeightUomCode())
					&& NumberUtils.isCreatable(equipmentGroupUnAssign.getEffWeight())
					&& NumberUtils.isCreatable(equipmentGroupUnAssign.getEffVolume())) {
				Float effweight = Float.parseFloat(equipmentGroupUnAssign.getEffWeight())
						/ getFractionValue(equipmentGroupUnAssign.getEffWeightUomCode());
				Float effvolume = Float.parseFloat(equipmentGroupUnAssign.getEffVolume())
						/ getFractionValue(equipmentGroupUnAssign.getEffVolumeUomCode());
				Float perWeight = (weight / effweight) * 100;
				Float perVolume = (volume / effvolume) * 100;
				if(perWeight > perVolume) {
					shipPercentage.put(shipid, perWeight + ":" + declaredvalue);
				} else {
					shipPercentage.put(shipid, perVolume + ":" + declaredvalue);
				}
				
//				String per = unAssignmentlocrefnum.get(sourceLocationGID);
//				if (Objects.nonNull(per) && NumberUtils.isCreatable(per)) {
//					float percent = Float.parseFloat(per);
//					if (percent > perVolume && percent > perWeight) {
//						//needApproval = true;
//					}
//				}

			}
			String ordstring = StringUtils.join(ordsList, ":");
			unAssignmentplannedValues.put(shipid, weight + ":" + volume);
			logList.add(shipid + "-" + weight + ":" + volume + "-" + ordstring);
		}
		return shipPercentage;
	}
	
	private void getLoadabilityPercentage(Set<String> shipids, String loadabilityPercentageQuery, Map<String, Map<String, String>> loadabilityPercentage) {
		if (!CollectionUtils.isEmpty(shipids)) {
			String query = MessageFormat.format(loadabilityPercentageQuery,
					new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>(shipids)) });
			String dbString = dbServletRestUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
			SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,
					LocationRefnumSchemaWrapper.class);
			List<String> gids = new ArrayList<>();
			if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				List<LocationRefNum> locationRefnums = ((LocationRefnumSchemaWrapper) dbServletMappedPojo)
						.getLocationRefnums();
				if (!CollectionUtils.isEmpty(locationRefnums)) {
					locationRefnums.forEach(loc -> {
						if(loadabilityPercentage.containsKey(loc.getShipmentGid())) {
							Map<String, String> refnumdata = loadabilityPercentage.get(loc.getShipmentGid());
							refnumdata.put(loc.getLocationRefnumQualGid(), loc.getLocationRefNumValue());
						} else {
							Map<String,String> map = new HashMap<>();
							map.put(loc.getLocationRefnumQualGid(), loc.getLocationRefNumValue());
							loadabilityPercentage.put(loc.getShipmentGid(), map);
						}
						
					});
				}
			}
		}
	}
}
