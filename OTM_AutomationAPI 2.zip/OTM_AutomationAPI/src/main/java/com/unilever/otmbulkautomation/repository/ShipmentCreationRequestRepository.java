package com.unilever.otmbulkautomation.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;

@Transactional
public interface ShipmentCreationRequestRepository extends JpaRepository<ShipmentCreationRequest, Long>, JpaSpecificationExecutor<ShipmentCreationRequest> {

	@Query(value="select shipment_creation_request_seq.nextval from dual", nativeQuery=true)
	public long getShipmentRequestValue();
	
	@Modifying
	@Query("update ShipmentCreationRequest s set s.responses = :responses, s.status = :status, s.shipmentStatus = :shipmentStatus, s.failureReason =:failureReason, s.numberOfShipments = :numberOfShipments, s.modifiedDateTime = :modifiedDateTime where s.requestNumber= :requestId")
	public void updateShipmentResponses(@Param("requestId") String requestId, @Param("responses") String responses, @Param("status") String status, @Param("shipmentStatus") String shipmentType, @Param("failureReason") String failureReason,  @Param("numberOfShipments") Integer numberOfShipments, @Param("modifiedDateTime") LocalDateTime modifiedDateTime);
	
	@Modifying
	@Query("update ShipmentCreationRequest s set s.status = :status, s.modifiedDateTime = :modifiedDateTime where s.requestNumber= :requestId")
	public void updateShipmentApprovalStatus(@Param("requestId") String requestId,  @Param("status") String status, @Param("modifiedDateTime") LocalDateTime modifiedDateTime);
	
	@Modifying
	@Query("update ShipmentCreationRequest s set s.approvalTracking = :approvalTracking, s.modifiedDateTime = :modifiedDateTime where s.requestNumber= :requestId")
	public void updateShipmentApprovalTracking(@Param("requestId") String requestId,  @Param("approvalTracking") String approvalTracking, @Param("modifiedDateTime") LocalDateTime modifiedDateTime);
	
	
	public ShipmentCreationRequest findByRequestNumber(String requestNumber);
	
	@Query("select s from ShipmentCreationRequest s where s.requestNumber in (:requestNumber)")
	public List<ShipmentCreationRequest> findRequestNumberByRequestNumberInAndNotStatus(@Param("requestNumber") Set<String> requestNumber);
	
	@Query("select s from ShipmentCreationRequest s where s.requestNumber in (:requestNumber) and s.status in (:status)")
	public List<ShipmentCreationRequest> findRequestNumberByRequestNumberInAndStatusIn(@Param("requestNumber") Set<String> requestNumber, @Param("status") List<String> status);
	
	
	@Procedure(procedureName = "RESET_SEQ")
	void resetSequence(String p_seq_name);
}
