package com.unilever.otmbulkautomation.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Component
public class DBServletAPI {
	
	public static void main(String[] args) throws Exception {
		double random = Math.random();
	callDBServlet("With locationAndShipid as (SELECT location_gid,shipment_gid FROM shipment_stop WHERE stop_type = 'D' AND shipment_gid in ('ULF.5522862635') AND stop_num IN ( SELECT MAX(stop_num) FROM shipment_stop WHERE stop_type = 'D' AND shipment_gid in ('ULF.5522862635') )) SELECT LOCATION_REFNUM_QUAL_GID,LOCATION_REFNUM_VALUE, (select shipment_gid from locationAndShipid where location_gid = location_gid ) as shipment_gid FROM LOCATION_REFNUM WHERE LOCATION_GID IN (SELECT location_gid FROM locationAndShipid) AND LOCATION_REFNUM_QUAL_GID IN ('ULF.ULF_CUST_DELCARED_VALUE','ULF.MINIMUM_CASE_LOAD','ULF.ULF_SECONDARY_OUTBOUND_LOADABILITY_PERCENTAGE')","SHIPMENT");
	}
	
//	public static void main(String[] args) {	
//		 LocalDateTime parse = OffsetDateTime.parse("2020-10-08T18:30:25+05:30").atZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();//for UTC format
//		 LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
//		 Duration between = Duration.between(parse, now);
//		 if(parse.isAfter(now)||parse.isEqual(now)) {
//			 System.out.println(between.toHours());
//		 }
//		 
//		 // OffsetDateTime parse = OffsetDateTime.parse("2019-06-13T19:00:00+05:33");
//		int time =  (parse.getHour()*10000)+(parse.getMinute()*100)+(parse.getSecond());
//		String start = "23:30:00.0000000";
//		String end = "01:20:22.0000000";
//		String starNnumeric = start.replaceAll(":", "").replaceAll(".0000000", "");
//		String endNnumeric = end.replaceAll(":", "").replaceAll(".0000000", "");
//		int starttime = Integer.parseInt(starNnumeric);
//		int endtime = Integer.parseInt(endNnumeric);
//
//		
//		if(endtime > starttime && time >= starttime && time <= endtime) {
//			System.out.println("true");
//		}
//		if(endtime < starttime && (time >= starttime || time <= endtime)) {
//			System.out.println("true");
//		}
//	}
	
	public static String callDBServlet(String sql,String root) throws Exception {
        long a=System.currentTimeMillis();
		String jsonPrintString = "";
		int PRETTY_PRINT_INDENT_FACTOR = 4;
		StringBuffer result = new StringBuffer("");
		try {
		 //"select * from order_release_refnum_qual where rownum < 2";
		
		

		HttpURLConnection connection;
		// System.out.println("reaching here ");
		String url ="https://otmgtm-test-a578804.otm.us2.oraclecloud.com/GC3/glog.integration.servlet.DBXMLServlet?command=xmlExport";
		connection = (HttpURLConnection) new URL(url).openConnection();
		// System.out.println("reaching here 2");

		connection.setDoOutput(true);
		// connection.setRequestProperty("Content-Type", "multipart/form-data;
		// boundary=" + boundary);
		// cecsadminportal@glesbymarks.com/Vendors@454
		
		String username = "ULF.INTEGRATION_TEST_DETELE";
		String password = "Changeme@123";
		String userPassword = username + ":" + password; // prod
		byte[] encodeBase64 = Base64.encodeBase64(userPassword.getBytes());
		connection.setRequestMethod("POST");
		connection.addRequestProperty("Authorization", "Basic " + new String(encodeBase64));
		connection.addRequestProperty("Content-Type", "application/xml");
		connection.setUseCaches(true);
		String body = "<sql2xml>\n" + 
				" <Query>\n" + 
				" <RootName>"+root+"</RootName>\n" + 
				" <Statement>"+sql+"</Statement>\n" + 
				" </Query>\n" + 
				"</sql2xml>";
		OutputStream os = connection.getOutputStream();
		OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
		osw.write(body);
		osw.flush();
		osw.close();
		os.close();
		//connection.
		
		BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		String inputLine;
		
		while ((inputLine = in.readLine()) != null) {
			System.out.println("****" + inputLine);
			result = result.append(inputLine);
		}
		in.close();
		connection.disconnect();
/*		final HttpClient client = new Client("username", "password", "");
		final Response res = client.post(
		"https://otmgtm-a615324-dev1.otm.us2.oraclecloud.com/GC3/glog.integration.servlet.DBXMLServlet?command=xmlExport",
		"rootName=SHIPMENTS&sqlQuery=" + URLEncoder.encode(sql), "application/xml");
		String result = res.getBody().toString();*/
		long b=System.currentTimeMillis();
        System.out.println("---------Time took: "+(b-a));
		//System.out.println("Result: " + result);
//		if(StringUtils.containsIgnoreCase(result.toString(), "<error>")) {
//			String replaceAll = result.toString().replaceAll("(?i)<error>(.*?)</error>", "$1");
//			System.out.println(replaceAll);
//			return replaceAll;
//		} else if(StringUtils.containsIgnoreCase(result.toString(), "<dbxml:TRANSACTION_SET>")) {
//			String replaceAll = result.toString().replaceAll("(?i).*?<dbxml:TRANSACTION_SET>(.*?)</dbxml:TRANSACTION_SET>.*", "<SchemaWrapper><entities>"+"$1"+"</entities></SchemaWrapper>");
//			System.out.println(replaceAll);
//	        JAXBContext jc =  JAXBContext.newInstance(OrderReleaseSchemaWrapper.class);
//	        Marshaller createMarshaller = jc.createMarshaller();
//	        Unmarshaller createUnmarshaller = jc.crejateUnmarshaller();
//	        StringReader reader = new StringReader(replaceAll);
//	        System.out.println("---------------");long currentTimeMillis = System.currentTimeMillis();
//	        OrderReleaseSchemaWrapper order= (OrderReleaseSchemaWrapper)createUnmarshaller.unmarshal(reader);
//	        System.out.println(order);
//	        StringWriter stringWriter = new StringWriter();
//	        createMarshaller.marshal(order,stringWriter);
//	        System.out.println(stringWriter);
//	        System.out.println("---------------time taken 1:" + (System.currentTimeMillis() - currentTimeMillis));
//
//			XmlMapper xmlMapper = new XmlMapper();
//			//xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//			//xmlMapper.registerModule(new JaxbAnnotationModule());
//	        System.out.println("---------------");long currentTimeMillis1 = System.currentTimeMillis();
//			OrderReleaseSchemaWrapper readValue = xmlMapper.readValue(replaceAll,OrderReleaseSchemaWrapper.class);
//			System.out.println(readValue);
//			xmlMapper.registerModule(new JaxbAnnotationModule());
//			String writeValueAsString = xmlMapper.writeValueAsString(readValue);
//			System.out.println(writeValueAsString);
//	        System.out.println("---------------time taken 2:" + (System.currentTimeMillis() - currentTimeMillis1));
//
//		}
		
		
/*		JSONObject xmlJSONObj = XML.toJSONObject(result.toString());
		JSONObject xmlJSONObj1 = null;
		JSONObject xmlJSONObj2 = null;
		Iterator<String> keys = xmlJSONObj.keys();
		while (keys.hasNext()) {
		String key = keys.next();
		xmlJSONObj1 = (JSONObject) xmlJSONObj.get(key);
		}
		System.out.println("json 1 is "+xmlJSONObj1.toString());
		Iterator<String> keys1 = xmlJSONObj1.keys();
		while (keys1.hasNext()) {
		String key = keys1.next();
		if (key.equals("dbxml:TRANSACTION_SET")) {
		xmlJSONObj2 = (JSONObject) xmlJSONObj1.get(key);
		break;
		}
		}
		System.out.println("json 2 is "+xmlJSONObj2.toString());
		System.out.println(xmlJSONObj2.get("LOCATION") instanceof JSONArray);
		Iterator<String> keys2 = xmlJSONObj2.keys();
		while (keys2.hasNext()) {
		String key = (String) keys2.next();
		}
		if (xmlJSONObj2.get("LOCATION") instanceof JSONArray) {
		jsonPrintString = xmlJSONObj2.getJSONArray("LOCATION").toString(4);
		} else {
		JSONArray jsonArray = new JSONArray();
		jsonArray.put(xmlJSONObj2.get("LOCATION"));
		xmlJSONObj2.put("LOCATION", jsonArray);
		}
		jsonPrintString = xmlJSONObj2.getJSONArray("LOCATION").toString(4);
		System.out.println("final string is "+jsonPrintString);*/
		} catch (Exception e) {
		e.printStackTrace();
		}
		return result.toString();
		}


}
