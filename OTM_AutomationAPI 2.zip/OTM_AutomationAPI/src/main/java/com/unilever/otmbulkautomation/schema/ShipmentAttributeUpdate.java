package com.unilever.otmbulkautomation.schema;

import lombok.Data;

@Data
public class ShipmentAttributeUpdate
{
    private String shipmentXid;
	
	private String attribute11;

}