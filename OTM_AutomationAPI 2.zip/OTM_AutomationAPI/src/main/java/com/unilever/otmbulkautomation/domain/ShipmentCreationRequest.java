package com.unilever.otmbulkautomation.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "SHIPMENT_REQUEST_CREATION")
public class ShipmentCreationRequest {

	@Id
	@Column(name = "REQUEST_NUMBER")
	//@SequenceGenerator(name = "SHIPMENT_CREATION_REQUEST_SEQ", sequenceName = "SHIPMENT_CREATION_REQUEST_SEQ", allocationSize = 1)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SHIPMENT_CREATION_REQUEST_SEQ")
	private String requestNumber;

	@Column(name = "USERNAME")
	private String username;

	@Column(name = "REQUEST_TYPE")
	private String requestType;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "FAILURE_REASON")
	private String failureReason;

	@Column(name = "CREATED_TIMESTAMP")
	private LocalDateTime createdDateTime;

	@Column(name = "MODIFIED_TIMESTAMP")
	private LocalDateTime modifiedDateTime;
	
	@Column(name = "REASONS")
	private String reasons;
	
	@Column(name = "RESPONSES")
	@Lob
	private String responses;
	
	@Column(name = "NUMBER_OF_ORDERS")
	private Integer numberOfOrders;
	
	@Column(name = "SHIPMENT_TYPE")
	private String shipmentType;
	
	@Column(name = "NUMBER_OF_SHIPMENTS")
	private Integer numberOfShipments;
	
	@Column(name = "DEPOT_ID")
	private String depotId;
	
	@Column(name = "SHIPMENT_STATUS")
	private String shipmentStatus;
	
	@Column(name = "APPROVAL_TRACKING")
	@Lob
	private String approvalTracking;
	
	@Column(name = "IMAGE")
	@Lob
	private String image;
}
