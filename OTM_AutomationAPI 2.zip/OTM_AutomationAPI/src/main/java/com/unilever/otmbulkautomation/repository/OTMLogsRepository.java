package com.unilever.otmbulkautomation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;

public interface OTMLogsRepository extends JpaRepository<OtmLogs, Long> {

}
