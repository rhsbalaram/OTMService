package com.unilever.otmbulkautomation.schema;

import lombok.Data;

@Data
public class ShipmentAttributesUpdates
{
    private String shipmentXid;
	
	private String attribute11;
	
	private String attribute12;


}