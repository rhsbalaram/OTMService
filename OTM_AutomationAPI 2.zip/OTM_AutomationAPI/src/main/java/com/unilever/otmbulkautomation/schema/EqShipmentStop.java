package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT_STOP")
public class EqShipmentStop
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
    private String shipmentGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "LOCATION_GID")
    private String LocationGid;

	@JacksonXmlProperty(isAttribute = true, localName = "STOP_TYPE")
    private String stopType;

	@JacksonXmlProperty(isAttribute = true, localName = "EQUIPMENT_GROUP_PROFILE_GID")
    private String equimentGroupProfileGid;

	@JacksonXmlProperty(isAttribute = true, localName = "EQUIPMENT_GID")
    private String equpmentGid;

	
	
	
}