package com.unilever.otmbulkautomation.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.schema.RateGeoSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentCancellation;
import com.unilever.otmbulkautomation.service.ShipmentCancellationService;
import com.unilever.otmbulkautomation.service.ShipmentEqchangeService;
import com.unilever.otmbulkautomation.service.ShipmentRequestService;

@RestController
@RequestMapping("/user/shipment")
public class ShipmentEqChangeController {
	
	@Autowired
	ShipmentEqchangeService shipmentEqchangeService;
	
	@Autowired
	ShipmentRequestService shipmentRequestService;
	
	@Autowired
	ShipmentCancellationService shipmentCancellationService;
	
	@PostMapping("/eqchange")
	public ResponseEntity<Object> getShipmentForCancel(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("orderReleaseType") String orderReleaseTypeGid, @RequestBody(required=false) List<String> shipments) throws Exception{
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		SchemaWrapper orderReleasesFromOtm = shipmentCancellationService.getShipmentsFromOtm(sourceLocation, orderReleaseTypeGid, shipments);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}
	
	@PostMapping("/eqchange/equipments")
	public ResponseEntity<Object> getShipmentOrderForUnassign(@RequestBody ShipmentCancellation shipment) throws Exception{
		  SchemaWrapper orderForShipmentUnAssign = shipmentEqchangeService.getEqmtDetailsFromOtm(shipment);
		 return new ResponseEntity(orderForShipmentUnAssign,HttpStatus.OK);
	}
	
	
	@PostMapping("/eqchange/submit")
	public ResponseEntity<Object> postShipmentForApproval(@RequestBody RateGeoSchemaWrapper rateGeo) throws Exception{
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		  ShipmentCreationRequest postShipmentForApproval = shipmentEqchangeService.postShipmentForApproval(username,rateGeo);
		 return new ResponseEntity(postShipmentForApproval,HttpStatus.OK);
	}
	
	@GetMapping(value = "/eqchanged")
	public ResponseEntity getShipments(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("shipment") String shipment, @RequestParam("shipmentType") String shipmentType, @RequestParam("requestDate") String requestDate,  @RequestParam("requestId") String requestId) {
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		List<ShipmentCreationRequest> list = new ArrayList<>();
		List<ShipmentCreationRequest> createdShipments1 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Truck Type Change");
		List<ShipmentCreationRequest> createdShipments2 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "TSP Change");
		List<ShipmentCreationRequest> createdShipments3 = shipmentRequestService.getCreatedShipments(sourceLocation, shipment, shipmentType, requestDate, requestId, "Truck Type & TSP Change");
		list.addAll(createdShipments1);
		list.addAll(createdShipments2);
		list.addAll(createdShipments3);

		
		
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping(value = "/eqchanged/detail")
	public ResponseEntity getShipmentdetails(@RequestParam("requestId") String requestId) {
		SchemaWrapper shipmentDetailsFromOtm = shipmentEqchangeService.getShipmentEqchangeDetailsFromOtm(requestId);
		return new ResponseEntity<>(shipmentDetailsFromOtm, HttpStatus.OK);
	}
	
	@GetMapping(value = "/eqchange/openMarket")
	public ResponseEntity getOpenMarket(@RequestParam("marketId") String marketId) {
		SchemaWrapper shipmentDetailsFromOtm = shipmentEqchangeService.getOpenMarketFromOtm(marketId);
		return new ResponseEntity<>(shipmentDetailsFromOtm, HttpStatus.OK);
	}

}
