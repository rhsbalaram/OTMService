package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT_REFNUM")
public class ShipmentRefnum
{
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
    private String shipmentGid;

	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_REFNUM_QUAL_GID")
    private String refnumQualGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DOMAIN_NAME")
    private String domainName;

	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_REFNUM_VALUE")
    private String refnumValue;
}
