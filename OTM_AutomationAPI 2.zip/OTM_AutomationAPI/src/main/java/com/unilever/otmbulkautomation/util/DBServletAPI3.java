//package com.unilever.otmbulkautomation.util;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.io.OutputStreamWriter;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.net.URLEncoder;
//import java.util.Iterator;
//
//import org.apache.tomcat.util.codec.binary.Base64;
//import org.json.JSONArray;
//import org.json.JSONObject;
//import org.json.XML;
//import org.springframework.stereotype.Component;
//
//@Component
//public class DBServletAPI3 {
//	
//	public static void main(String[] args) throws Exception {
//		callDBServlet("UPDATE LOCATION SET LOCATION_NAME = 'Location Name - SEEMA SALES CORPORATION' WHERE LOCATION_GID = 'ULF.131565'");
//	}
//	public static String callDBServlet(String sql) throws Exception {
//        long a=System.currentTimeMillis();
//		String jsonPrintString = "";
//		int PRETTY_PRINT_INDENT_FACTOR = 4;
//		StringBuffer result = new StringBuffer("");
//		try {
//		 //"select * from order_release_refnum_qual where rownum < 2";
//		
//		
//
//		HttpURLConnection connection;
//		// System.out.println("reaching here ");
//		String url ="https://otmgtm-test-a578804.otm.us2.oraclecloud.com/GC3/glog.integration.servlet.WMServlet";
//		connection = (HttpURLConnection) new URL(url).openConnection();
//		// System.out.println("reaching here 2");
//
//		connection.setDoOutput(true);
//		// connection.setRequestProperty("Content-Type", "multipart/form-data;
//		// boundary=" + boundary);
//		// cecsadminportal@glesbymarks.com/Vendors@454
//		
//		String username = "ULF.INTEGRATION_TEST_DETELE";
//		String password = "CHANGEME";
//		String userPassword = username + ":" + password; // prod
//		byte[] encodeBase64 = Base64.encodeBase64(userPassword.getBytes());
//		connection.setRequestMethod("POST");
//		connection.addRequestProperty("Authorization", "Basic " + new String(encodeBase64));
//		connection.addRequestProperty("Content-Type", "text/xml");
////		String body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
////				"<xml2sql Version=\"20B\">\n" + 
////				"   <TransactionCode>I</TransactionCode>\n" + 
////				"   <TRANSACTION_SET>\n" + 
////				"      <LOCATION LOCATION_GID=\"ULF.99999\" LOCATION_XID=\"99999\" LOCATION_NAME=\"TESTING SALES CORPORATION\" CITY=\"R355\" PROVINCE=\"MAHARASHTRA\" PROVINCE_CODE=\"13\" POSTAL_CODE=\"440016\" COUNTRY_CODE3_GID=\"IND\" ZONE1=\"MHA-WADI\" TIME_ZONE_GID=\"Asia/Calcutta\" LAT=\"21.14888\" LON=\"79.00330\" IS_TEMPORARY=\"N\" IS_MAKE_APPT_BEFORE_PLAN=\"N\" IS_SHIPPER_KNOWN=\"N\" IS_ADDRESS_VALID=\"U\" IS_LTL_SPLITABLE=\"N\" BB_IS_NEW_STORE=\"N\" EXCLUDE_FROM_ROUTE_EXECUTION=\"N\" IS_TEMPLATE=\"N\" DESCRIPTION=\"CUSTOMER\" IS_FIXED_ADDRESS=\"N\" PRIMARY_ADDRESS_LINE_SEQ=\"1\" ATTRIBUTE1=\"RR\" ATTRIBUTE2=\"WEST\" IS_ACTIVE=\"Y\" ADDRESS_UPDATE_DATE=\"2020-05-07 07:10:57.0\" DOMAIN_NAME=\"ULF\" />\n" + 
////				"   </TRANSACTION_SET>\n" + 
////				"</xml2sql>";
////		String body = "<xml2sql Version=\"20B\">\n" + 
////				"<TransactionCode>I</TransactionCode> \n" + 
////				"<TRANSACTION_SET> \n" + 
////				"<PROCESS_CONTROL_REQUEST  PROCESS_CONTROL_REQUEST_ID=\"418922\" TOPIC_ALIAS_GID=\"BuildBuySideShipments\" TOPIC_PARAMETERS=\"-usePartition false -role ADMIN -planningParamSetGid ULF.ULF_PLANNING_PARAMETER -shipmentsSuppressed false -user ULF.INTEGRATION -savedQuery SHPCRT00001\" NEXT_PROCESS_TIME=\"2020-05-18 06:56:23.0\"  DOMAIN_NAME=\"ULF\" /> \n" + 
////				"</TRANSACTION_SET> \n" + 
////				"</xml2sql>";
//		String body ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
//				"<Transmission xmlns:otm=\"http://xmlns.oracle.com/apps/otm/transmission/v6.4\" xmlns:gtm=\"http://xmlns.oracle.com/apps/gtm/transmission/v6.4\">\n" + 
//				"    <TransmissionBody>\n" + 
//				"        <GLogXMLElement>\n" + 
//				"            <ShipmentStatus>\n" + 
//				"                <ShipmentRefnum>\n" + 
//				"                    <ShipmentRefnumQualifierGid>\n" + 
//				"                        <Gid>\n" + 
//				"                            <Xid>GLOG</Xid>\n" + 
//				"                        </Gid>\n" + 
//				"                    </ShipmentRefnumQualifierGid>\n" + 
//				"                    <ShipmentRefnumValue>ULF.5519542530</ShipmentRefnumValue>\n" + 
//				"                </ShipmentRefnum>\n" + 
//				"                <StatusLevel>SHIPMENT</StatusLevel>\n" + 
//				"                <StatusCodeGid>\n" + 
//				"                    <Gid>\n" + 
//				"                        <DomainName>ULF</DomainName>\n" + 
//				"                        <Xid>SA</Xid>\n" + 
//				"                    </Gid>\n" + 
//				"                </StatusCodeGid>\n" + 
//				"                <TimeZoneGid>\n" + 
//				"                    <Gid>\n" + 
//				"                        <Xid>Asia/Calcutta</Xid>\n" + 
//				"                    </Gid>\n" + 
//				"                </TimeZoneGid>\n" + 
//				"                <EventDt>\n" + 
//				"                    <GLogDate>20200622154250</GLogDate>\n" + 
//				"                </EventDt>\n" + 
//				"            </ShipmentStatus>\n" + 
//				"        </GLogXMLElement>\n" + 
//				"    </TransmissionBody>\n" + 
//				"</Transmission>";
//		System.out.println(body);
//		OutputStream os = connection.getOutputStream();
//		OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
//		osw.write(body);
//		osw.flush();
//		osw.close();
//		os.close();
//		//connection.
//		
//		BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//		String inputLine;
//		
//		while ((inputLine = in.readLine()) != null) {
//			System.out.println("****" + inputLine);
//			result = result.append(inputLine);
//		}
//		in.close();
//		connection.disconnect();
///*		final HttpClient client = new Client("username", "password", "");
//		final Response res = client.post(
//		"https://otmgtm-a615324-dev1.otm.us2.oraclecloud.com/GC3/glog.integration.servlet.DBXMLServlet?command=xmlExport",
//		"rootName=SHIPMENTS&sqlQuery=" + URLEncoder.encode(sql), "application/xml");
//		String result = res.getBody().toString();*/
//		long b=System.currentTimeMillis();
//        System.out.println("---------Time took: "+(b-a));
//		System.out.println("Result: " + result);
//		
//		
///*		JSONObject xmlJSONObj = XML.toJSONObject(result.toString());
//		JSONObject xmlJSONObj1 = null;
//		JSONObject xmlJSONObj2 = null;
//		Iterator<String> keys = xmlJSONObj.keys();
//		while (keys.hasNext()) {
//		String key = keys.next();
//		xmlJSONObj1 = (JSONObject) xmlJSONObj.get(key);
//		}
//		System.out.println("json 1 is "+xmlJSONObj1.toString());
//		Iterator<String> keys1 = xmlJSONObj1.keys();
//		while (keys1.hasNext()) {
//		String key = keys1.next();
//		if (key.equals("dbxml:TRANSACTION_SET")) {
//		xmlJSONObj2 = (JSONObject) xmlJSONObj1.get(key);
//		break;
//		}
//		}
//		System.out.println("json 2 is "+xmlJSONObj2.toString());
//		System.out.println(xmlJSONObj2.get("LOCATION") instanceof JSONArray);
//		Iterator<String> keys2 = xmlJSONObj2.keys();
//		while (keys2.hasNext()) {
//		String key = (String) keys2.next();
//		}
//		if (xmlJSONObj2.get("LOCATION") instanceof JSONArray) {
//		jsonPrintString = xmlJSONObj2.getJSONArray("LOCATION").toString(4);
//		} else {
//		JSONArray jsonArray = new JSONArray();
//		jsonArray.put(xmlJSONObj2.get("LOCATION"));
//		xmlJSONObj2.put("LOCATION", jsonArray);
//		}
//		jsonPrintString = xmlJSONObj2.getJSONArray("LOCATION").toString(4);
//		System.out.println("final string is "+jsonPrintString);*/
//		} catch (Exception e) {
//		e.printStackTrace();
//		}
//		return result.toString();
//		}
//
//
//}
