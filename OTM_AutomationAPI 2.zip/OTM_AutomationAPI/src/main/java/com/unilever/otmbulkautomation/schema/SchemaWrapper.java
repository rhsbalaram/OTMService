package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
public class SchemaWrapper {
	@JsonInclude(Include.NON_NULL)
	private String error;
}
