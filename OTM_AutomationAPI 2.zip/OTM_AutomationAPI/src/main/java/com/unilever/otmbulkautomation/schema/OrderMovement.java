package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "ORDER_MOVEMENT")
public class OrderMovement
{
	@JacksonXmlProperty(isAttribute = true, localName = "ORDER_RELEASE_GID")
    private String orderReleaseGid;

}