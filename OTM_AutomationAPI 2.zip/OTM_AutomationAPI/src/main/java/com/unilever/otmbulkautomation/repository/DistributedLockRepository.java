package com.unilever.otmbulkautomation.repository;

import javax.persistence.LockModeType;
import javax.persistence.QueryHint;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

import com.unilever.otmbulkautomation.domain.DistributedLock;

public interface DistributedLockRepository extends JpaRepository<DistributedLock, String>{

	@Modifying
	@Query("update DistributedLock d set d.flag = :flag where d.scenario= :scenario")
	public void updateShipmentResponses(@Param("flag") String flag, @Param("scenario") String scenario);
	
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@QueryHints({@QueryHint(name = "javax.persistence.lock.timeout", value = "60000")})
	public DistributedLock findByScenario(String scenario);
	
}
