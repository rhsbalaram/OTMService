package com.unilever.otmbulkautomation.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "OTM_DISTRIBUTED_LOCK")
public class DistributedLock {

	@Id
	@Column(name = "SCENARIO")
	private String scenario;

	@Column(name = "FLAG")
	private String flag;

}
