//package com.unilever.otmbulkautomation.schema;
//
//import java.util.List;
//
//import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlElementWrapper;
//
//import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
//
//import lombok.Data;
//@Data
//@JacksonXmlRootElement(localName="SchemaWrapper")
//public class OrderReleaseSchemaWrapper {
//	@XmlElementWrapper(name="entities")
//	@XmlElement(name="ORDER_RELEASE")
//    private List<ORDER_RELEASE> entities;
//    
//}