package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAttributeUpdate;
import com.unilever.otmbulkautomation.schema.ShipmentCancellation;
import com.unilever.otmbulkautomation.schema.ShipmentCancellationSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentRefnum;
import com.unilever.otmbulkautomation.schema.ShipmentRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentCancellationService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.cancellation.getQuery}")
	private String shipmentcancellationGetQuery;
	
	@Value("${otm.shipmentrefNum.getQuery}")
	private String shipmentrefNumGetQuery;
	
	@Value("${otm.cancel.details.getQuery}")
	private String shipmentCancelDetailsQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	OTMService otmservice;
	
	@Autowired
	OTMShipmentConstants otmShpConstants;
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	UserRepository userRepo;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	@Autowired
	DBServletPojoMapper mapper;
	
	@Autowired
	DBServletRestUtil restUtil;
	
	ObjectMapper objMapper = new ObjectMapper();
		
	public SchemaWrapper getShipmentsFromOtm(List<String> sourceLocationGIDs, String orderReleaseTypeGid, List<String> shipments) {
		if (Objects.nonNull(sourceLocationGIDs) && Objects.nonNull(orderReleaseTypeGid)) {
			String query = "";
			if(!CollectionUtils.isEmpty(sourceLocationGIDs)) {
				String shipmentCondition = "";
				if(!CollectionUtils.isEmpty(shipments)) {
					shipmentCondition = "AND SHIPMENT_XID IN ("+commonUtil.getCommaDelimiterString(shipments)+")";
				}
				query = MessageFormat.format(shipmentcancellationGetQuery,
						new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), orderReleaseTypeGid, shipmentCondition, dateUtil.getISTDateMinusDays(2) });
			} else {
				return null;
			}
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentCancellationSchemaWrapper.class);
			 validations.valideShipmentForCancellation(dbServletMappedPojo);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public  ShipmentCreationRequest postShipmentForApproval(String username, ShipmentCancellationSchemaWrapper shipmentCancellation){
		String orderReleaseType = shipmentCancellation.getOrderReleaseType();
		String reason = shipmentCancellation.getReason();
		List<ShipmentCancellation> approvals = shipmentCancellation.getShipments();
		ShipmentCreationRequest shipmentCreationRequest = new ShipmentCreationRequest();
		if(!CollectionUtils.isEmpty(approvals)) {
			List<String> shipmentids = approvals.stream().map(shp -> shp.getShipmentGid()).collect(Collectors.toList());
			String query = MessageFormat.format(shipmentrefNumGetQuery,
					new Object[] { commonUtil.getCommaDelimiterString(shipmentids), otmShpConstants.getShipmentPendingGid() });
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentRefnumSchemaWrapper.class);
			 List<String> gids = new ArrayList<>();
			 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) dbServletMappedPojo).getShipmentRefnums();
				 if(!CollectionUtils.isEmpty(shipmentRefnums)) {
					   List<String> collect = shipmentRefnums.stream().map(refnum -> refnum.getShipmentGid()).collect(Collectors.toList());
					   gids.addAll(collect);
				 }
			}
			 List<String> validgids = new ArrayList<>();
			 List<String> depotids = new ArrayList<>();
			 Set<String> validdepotids = new HashSet<>();

			 List<ShipmentCancellation> validApprovals = approvals.stream().filter(appr -> !gids.contains(appr.getShipmentGid())).map(validshp ->{
				 validgids.add(validshp.getShipmentGid());
				 depotids.add(validshp.getSourceLocationGid().replaceAll("ULF.", ""));
				 validdepotids.add(validshp.getSourceLocationGid());
				 return validshp;
			 }).collect(Collectors.toList());
			 if(!CollectionUtils.isEmpty(validApprovals)) {
				 	shipmentCreationRequest.setUsername(username);
					shipmentCreationRequest.setStatus(OTMConstants.APPROVAL_PENDING);
					shipmentCreationRequest.setRequestType("Cancellation");
					shipmentCreationRequest.setReasons(reason);
					LocalDateTime currentISTLocalDateTime = dateUtil.getCurrentISTLocalDateTime();
					shipmentCreationRequest.setCreatedDateTime(currentISTLocalDateTime);
					shipmentCreationRequest.setModifiedDateTime(currentISTLocalDateTime);
					shipmentCreationRequest.setNumberOfOrders(validApprovals.size());
					shipmentCreationRequest.setNumberOfShipments(validApprovals.size());
					String shipmentRequestId = commonUtil.getSequencePrefix(String.valueOf(repository.getShipmentRequestValue()));
					shipmentCreationRequest.setRequestNumber(shipmentRequestId);

					shipmentCreationRequest.setDepotId(String.join(",", validdepotids));
					shipmentCreationRequest.setShipmentType(orderReleaseType);

					ShipmentCreationRequestLog shipmentlog = new ShipmentCreationRequestLog();
					shipmentlog.setRequestNumber(shipmentRequestId);
					shipmentlog.setOrdersNumbers(String.join(",", validgids));
					repositoryLog.save(shipmentlog);
					repository.save(shipmentCreationRequest);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Cancellation creation with req id : "+shipmentRequestId+" shipments : "+validgids, "INFO"));
					String shpmtType = commonUtil.getShipmentType(orderReleaseType);
					List<User> users = userRepo.findBySourceLocation(depotids, "Approver", shpmtType);
					ShipmentApprovalSchemaWrapper approvalShipmentsFromOtm = otmservice.getApprovalShipmentsFromOtm(validgids);

					if (!CollectionUtils.isEmpty(users) && !CollectionUtils.isEmpty(approvalShipmentsFromOtm.getShipments())) {
						List<String> emails = users.stream().map(user -> user.getEmailId()).collect(Collectors.toList());
						try {
							shipmentCreationFacade.createOrDeleteShipmentRefnum(validgids, otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentCancelPending(), "I");
							String refquery = MessageFormat.format(shipmentrefNumGetQuery,
									new Object[] { commonUtil.getCommaDelimiterString(validgids), otmShpConstants.getShipmentCancellationGid() });
							 String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", refquery);
							 SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,  ShipmentRefnumSchemaWrapper.class);
							 if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
								 List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo).getShipmentRefnums();
								 if(!CollectionUtils.isEmpty(shipmentRefnums)) {
									String dbServletMappedXml = mapper.getDBServletMappedXml(((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo));
									String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D", dbServletMappedXml);
									if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
										log.error("Error Deleting the "+ otmShpConstants.getShipmentCancellationGid() + " shipmentids : " + validgids);
										logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Error Deleting the "+ otmShpConstants.getShipmentCancellationGid() + " shipmentids : " + validgids, "ERROR"));
									}
								}
							}
								
							shipmentCreationFacade.createOrDeleteShipmentRefnum(validgids, otmShpConstants.getShipmentCancellationGid(), shipmentRequestId, "I");
							for (String gid : validgids) {
								try {
								ShipmentAttributeUpdate attrUpdate = new ShipmentAttributeUpdate();
								attrUpdate.setAttribute11(shipmentRequestId);
								attrUpdate.setShipmentXid(gid.replaceAll("ULF.", ""));
								String update = objMapper.writeValueAsString(attrUpdate);
								String rest = "shipments/" + gid;
								dbServletRestUtil.postQueryToRestOTM(rest, update);
								} catch(Exception e) {
									logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Error Updating attribute11 rest :"+ gid + " requestid : " + shipmentRequestId, "ERROR"));
								}
							}
						for (User user : users) {
							String module = user.getModule();
							//if (Objects.nonNull(module) && StringUtils.containsIgnoreCase(module, "cancellation")) {
								emailUtil.sendEmailWithAttachment("OTM Shipment Cancellation - Action",
										otmUtil.getEmailforApproval(approvalShipmentsFromOtm.getShipments(),
												user.getUsername(), reason, shipmentRequestId, "Cancellation"),
										user.getEmailId());
							//}
						}
							logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "sending Email for Cancellation req id : "+shipmentRequestId + " for users : "+ emails , "INFO"));
							
						} catch (Exception e) {  
							shipmentCreationRequest.setStatus("Failed");
							shipmentCreationRequest.setFailureReason("Cancellation Creation Error");
							shipmentCreationFacade.createOrDeleteShipmentRefnum(validgids, otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentCancelPending(), "D");
							shipmentCreationFacade.createOrDeleteShipmentRefnum(validgids, otmShpConstants.getShipmentCancellationGid(), shipmentRequestId, "D");
							repository.updateShipmentResponses(shipmentCreationRequest.getRequestNumber(), null,
									shipmentCreationRequest.getStatus(), null, shipmentCreationRequest.getFailureReason(),
									shipmentCreationRequest.getNumberOfShipments(), dateUtil.getCurrentISTLocalDateTime());
							log.error("Error sending email to : {} with exception : {}", emails.toArray(), e.getMessage());
							logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Error sending for Cancellation req id : "+shipmentRequestId + " for users : "+ emails + e.getMessage(), "ERROR"));
						}
					}
			 }
			 return shipmentCreationRequest;
		}
		return shipmentCreationRequest;
	}
		
	public List<ShipmentApproval> postCancellationByShipmentId(List<ShipmentApproval> shipments, String status, String userId) {
		if(!CollectionUtils.isEmpty(shipments)) {
			

			shipments.forEach(ship ->{
				ShipmentCreationRequest shipment = repository.findByRequestNumber(ship.getAttribute11());

			if (OTMConstants.APPROVED.equals(status)) {
				dbServletRestUtil.postShipmentStatusToWMServlet(ship.getShipmentGID(),
						"SC", dateUtil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));

			} else {
				
					repository.updateShipmentApprovalStatus(ship.getAttribute11(), status, dateUtil.getCurrentISTLocalDateTime());
			}
			if(Objects.nonNull(shipment)) {
				String track = ship.getShipmentGID() + ":" + userId + ":" + status;
				String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
				repository.updateShipmentApprovalTracking(ship.getAttribute11(), approvalTracking, dateUtil.getCurrentISTLocalDateTime());
				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(ship.getShipmentGID());}},
						otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentCancelPending(), "D");
				
			}
		});
		
		return shipments;
		}
		return null;
	}
	
	public SchemaWrapper getShipmentCancelledDetailsFromOtm(String requestId) {
		if (Objects.nonNull(requestId)) {
			String query = MessageFormat.format(shipmentCancelDetailsQuery, new Object[] { requestId });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentCancellationSchemaWrapper.class);
		} else {
			return null;
		}
	}
}
