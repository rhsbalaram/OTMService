package com.unilever.otmbulkautomation.util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.HttpHost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.client.RestTemplate;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class DBServletRestUtil {

	RestTemplate restTemplate;

	HttpHeaders httpHeaders;

	@Value("${otm.automation.server}")
	private String otmServer;

	@Value("${otm.automation.username}")
	private String username;

	@Value("${otm.automation.password}")
	private String password;

	@Value("${otm.dbservlet.getQueryURI}")
	private String getQueryURI;
	
	@Value("${otm.dbservlet.insertQueryURI}")
	private String insertQueryURI;
	
	@Value("${otm.wmservlet.postQueryURI}")
	private String postWMServletURI;
	
	@Value("${otm.restapi.postQueryURI}")
	private String restOTMURI;
	
	@Autowired
	ResourceLoader resourceLoader;

	private String dbServletQueryFormat;
	
	private String dbServletTransactionFormat;
	
	private String wmServletTransactionFormat;


	@PostConstruct
	public void loadDBServletQueryFile() throws IOException {
		log.info("Loading static file contents");
		this.dbServletQueryFormat = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/DBServletQuery.xml").getInputStream()));
		this.dbServletTransactionFormat = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/DBServletTransaction.xml").getInputStream()));
		this.wmServletTransactionFormat = new String(FileCopyUtils.copyToByteArray(
				resourceLoader.getResource("classpath:templates/WMServletTransaction.xml").getInputStream()));
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
        HttpClientBuilder.create()
                .setProxy(new HttpHost("omcscabszedfip.netymuqvv.vcneraqb.oraclevcn.com", 3128, "http"))
                .build()
				);
		this.restTemplate = new RestTemplate(requestFactory);
		log.info("Loading httpHeaders");
		this.httpHeaders = new HttpHeaders() {
			{
				String auth = username + ":" + password;
				byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")));
				String authHeader = "Basic " + new String(encodedAuth);
				set("Authorization", authHeader);
			}
		};

	}

	public String postGetQueryToDBServlet(String root, String query) {
		log.info("postGetQueryToDBServlet Quering with root {} and query {}", root, query);
		String queryBody = MessageFormat.format(dbServletQueryFormat, new Object[] { root, query });
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.addAll(this.httpHeaders);
		httpHeaders.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> request = new HttpEntity<>(queryBody, httpHeaders);
		StopWatch createStarted = StopWatch.createStarted();
		ResponseEntity<String> exchange = restTemplate.exchange(otmServer + getQueryURI, HttpMethod.POST, request,
				String.class);
		createStarted.stop();
		log.info("Time : {} taken for query : {} ", createStarted.getTime(TimeUnit.MILLISECONDS), query);
		log.debug(exchange.getBody());
		log.info(exchange.getStatusCode()); 
		return exchange.getBody();
	}
	
	public String postInsertQueryToDBServlet(String transactinCode, String body) {
		log.info("postinsertQueryToDBServlet Quering with transactinCode {} and body {}", transactinCode, body);
		String queryBody = MessageFormat.format(dbServletTransactionFormat, new Object[] { transactinCode, body });
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.addAll(this.httpHeaders);
		httpHeaders.setContentType(MediaType.TEXT_XML);
		HttpEntity<String> request = new HttpEntity<>(queryBody, httpHeaders);
		StopWatch createStarted = StopWatch.createStarted();
		ResponseEntity<String> exchange = restTemplate.exchange(otmServer + insertQueryURI, HttpMethod.POST, request,
				String.class);
		createStarted.stop();
		log.info("Time : {} taken for insert : {} ", createStarted.getTime(TimeUnit.MILLISECONDS), queryBody);
		log.debug(exchange.getBody());
		log.info(exchange.getStatusCode());
		if (StringUtils.containsIgnoreCase(exchange.getBody(), "<error>")) {
			log.error(exchange.getBody());
			return null;
		} else if (StringUtils.containsIgnoreCase(exchange.getBody(), "<SuccessCount>")) {
			return exchange.getBody().replaceAll("(?i)(?s)(.*?)<SuccessCount>(.*?)</SuccessCount>(?s)(.*)", "$2");
		}

		return exchange.getBody();
	}
	
	
	public String postShipmentStatusToWMServlet(String shipmentGid, String shipmentStatus, String istdate) {
		log.info("postShipmentStatusToWMServlet with  shipmentGid {}, shipmentStatus {}, istdate {}", shipmentGid, shipmentStatus, istdate);
		String queryBody = MessageFormat.format(wmServletTransactionFormat, new Object[] { shipmentGid, shipmentStatus, istdate });
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.addAll(this.httpHeaders);
		httpHeaders.setContentType(MediaType.TEXT_XML);
		HttpEntity<String> request = new HttpEntity<>(queryBody, httpHeaders);
		StopWatch createStarted = StopWatch.createStarted();
		ResponseEntity<String> exchange = restTemplate.exchange(otmServer + postWMServletURI, HttpMethod.POST, request,
				String.class);  
		createStarted.stop();
		log.info("Time : {} taken for insert : {} ", createStarted.getTime(TimeUnit.MILLISECONDS), queryBody);
		log.debug(exchange.getBody());
		log.info(exchange.getStatusCode());
		if (StringUtils.containsIgnoreCase(exchange.getBody(), "<error>")) {
			log.error(exchange.getBody());
			return null;
		} else if (StringUtils.containsIgnoreCase(exchange.getBody(), "<ReferenceTransmissionNo>")) {
			return exchange.getBody().replaceAll("(?i)(?s)(.*?)<ReferenceTransmissionNo>(.*?)</ReferenceTransmissionNo>(?s)(.*)", "$2");
		}
		return exchange.getBody();
	}
	
	public String postQueryToRestOTM(String rest, String query) {
		log.info("postQueryToRestOTM Quering with rest {} and query {}", rest, query);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.addAll(this.httpHeaders);
		httpHeaders.set("Content-Type", "application/vnd.oracle.resource+json; type=singular");
		HttpEntity<String> request = new HttpEntity<>(query, httpHeaders);
		StopWatch createStarted = StopWatch.createStarted();
		ResponseEntity<String> exchange = restTemplate.exchange(otmServer + restOTMURI+ rest, HttpMethod.PATCH, request,
				String.class);
		createStarted.stop();
		log.info("Time : {} taken for query : {} ", createStarted.getTime(TimeUnit.MILLISECONDS), query);
		log.debug(exchange.getBody());
		log.info(exchange.getStatusCode());
		return exchange.getBody();
	}

}
