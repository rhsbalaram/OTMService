package com.unilever.otmbulkautomation.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.service.OrderReleaseService;

@RestController
@RequestMapping("user/order")
public class OrderReleaseController {
	
	@Autowired
	OrderReleaseService orderReleaseService;
	
	
	@PostMapping("/orderReleases")
	public ResponseEntity<Object> getOrderRelsese(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("orderReleaseType") String orderReleaseType, @RequestBody(required=false) List<String> orderReleaseList) throws Exception{
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		SchemaWrapper orderReleasesFromOtm = orderReleaseService.getOrderReleasesFromOtm(sourceLocation, orderReleaseType, orderReleaseList);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}
	
	@PostMapping("/assign")
	public ResponseEntity<Object> getOrderRelseseForAssign(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("orderReleaseType") String orderReleaseType, @RequestBody(required=false) List<String> orderReleaseList) throws Exception{
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		SchemaWrapper orderReleasesFromOtm = orderReleaseService.getOrderReleasesFromOtmForAssignment(sourceLocation, orderReleaseType, orderReleaseList);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}
	
	@PostMapping("/unassign")
	public ResponseEntity<Object> getOrderRelseseForUnAssign(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("orderReleaseType") String orderReleaseType, @RequestBody(required=false) List<String> orderReleaseList) throws Exception{
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		SchemaWrapper orderReleasesFromOtm = orderReleaseService.getOrderReleasesFromOtmForUnAssignment(sourceLocation, orderReleaseType, orderReleaseList);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}

}
