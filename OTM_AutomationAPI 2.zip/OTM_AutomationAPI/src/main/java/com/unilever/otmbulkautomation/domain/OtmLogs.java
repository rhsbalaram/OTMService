package com.unilever.otmbulkautomation.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@Entity
@AllArgsConstructor
@Table(name = "OTM_LOGS")
public class OtmLogs {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LOG_ID")
	private Long logid;
	
	@Column(name = "LOG_DATE")
	private LocalDateTime logDate;

	@Column(name = "LOG_TRACE")
	@Lob
	private String trace;
	
	@Column(name = "LOG_TYPE")
	@Lob
	private String type;
	
}
