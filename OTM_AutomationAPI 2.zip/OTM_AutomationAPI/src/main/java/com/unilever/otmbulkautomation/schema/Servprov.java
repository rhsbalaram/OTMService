package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SERVPROV")
public class Servprov
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "SERVPROV_GID")
    private String serprovGid;
	
}