package com.unilever.otmbulkautomation.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.util.OTMDateUtil;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class DBConfigScheduler {

	@Autowired
	private ShipmentCreationRequestRepository shipmentCreationRepo;
	
	@Autowired
	OTMDateUtil dateutil;
	
	@Scheduled(cron="0 0 0 * * ?",zone="GMT+5:30")
	public void resetShipmentCreationRequestSeq() {
		log.info("DBConfigScheduler for resetShipmentCreationRequestSeq");
		shipmentCreationRepo.resetSequence(OTMConstants.SHIPMENT_CREATION_REQUEST_SEQ);
	}
}
