package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "RATE_GEO")
public class RateGeo
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "EQUIPMENT_GROUP_PROFILE_GID")
    private String equipmentGroupProfileGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "RATE_OFFERING_GID")
    private String rateOfferingGid;

	@JacksonXmlProperty(isAttribute = true, localName = "SERVPROV_ID")
    private String servprovGid;

	@JacksonXmlProperty(isAttribute = true, localName = "RATE_GEO_GID")
    private String rateGeoGid;
	
}