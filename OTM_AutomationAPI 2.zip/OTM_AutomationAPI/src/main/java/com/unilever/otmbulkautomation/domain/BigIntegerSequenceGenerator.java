//package com.unilever.otmbulkautomation.domain;
//
//import java.io.Serializable;
//
//import org.hibernate.engine.spi.SessionImplementor;
//import org.hibernate.id.enhanced.SequenceStyleGenerator;
//
//public class BigIntegerSequenceGenerator
//    extends SequenceStyleGenerator
//{
//    @Override
//    public Serializable generate(SessionImplementor session, Object obj)
//    {
//       // ...
//    }
//}