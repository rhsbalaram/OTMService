package com.unilever.otmbulkautomation.repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.util.OTMDateUtil;

public class ShipmentCreationSpecifications {
	
	public static Specification<ShipmentCreationRequest> withRequestId(String requestId) {
	    return ((root, query, builder) -> {
	    	return builder.equal(root.get("requestNumber"), requestId);
	    	});
	}
	
	public static Specification<ShipmentCreationRequest> withRequestType(String requestType) {
	    return ((root, query, builder) -> {
	    	return builder.equal(root.get("requestType"), requestType);
	    	});
	}
	
	public static Specification<ShipmentCreationRequest> withShipment(String shipment) {
	    return ((root, query, builder) -> {
	    	return builder.equal(root.get("shipmentStatus"), shipment);
	    	});
	}
	
	public static Specification<ShipmentCreationRequest> withdepotId(List<String> depotIds) {
	    return ((root, query, builder) -> {
	    List<Predicate> pred = new ArrayList<>();
	    	for(String depotid : depotIds) {
	    		pred.add(builder.like(root.get("depotId"), "%"+depotid+"%"));
	    	}
	    	Predicate[] array = pred.toArray(new Predicate[pred.size()]);
	    	return builder.or(array);
	    	});
	}
	
	public static Specification<ShipmentCreationRequest> withShipmentType(String shipmentType) {
	    return ((root, query, builder) -> {
	    	return builder.equal(root.get("shipmentType"), shipmentType);
	    	});
	}
	
	public static Specification<ShipmentCreationRequest> withShipmentDate(String date) {
	    return ((root, query, builder) -> {
	    	LocalDateTime start = LocalDateTime.parse(date+"000000",OTMDateUtil.OJET_DATE_FORMAT_2);
	    	LocalDateTime nextDay = start.plusDays(1);
	    	return builder.and(builder.greaterThanOrEqualTo(root.get("createdDateTime"), start), builder.lessThan(root.get("createdDateTime"), nextDay));
	    	});
	}

}
