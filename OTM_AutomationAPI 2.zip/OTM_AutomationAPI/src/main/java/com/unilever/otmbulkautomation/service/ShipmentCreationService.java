package com.unilever.otmbulkautomation.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientException;

import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentCreationService {


	@Autowired
	CommonUtils commonUtil;

	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;

	@Autowired
	OTMShipmentConstants otmShipmentConstants;

	@Autowired
	OTMDateUtil dateutil;

	@Autowired
	OTMService otmService;

	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	OTMShipmentConstants otmConstants;
	
	@Autowired
	OTMLogsRepository logsRepo;

	public ShipmentCreationRequest createShipment(String username, List<String> sourceLocations,
			OrderReleasesSchemaWrapper orderReleasesSchema) {
		log.info("START ShipmentCreationRequest");
		ShipmentCreationRequest shipmentCreationRequest = new ShipmentCreationRequest();
		List<String> orderNumbers = new ArrayList<>();
		Set<String> depotids = new HashSet<>();
		List<OrderReleases> orderReleases = orderReleasesSchema.getOrderReleases();
		String orderReleaseType = orderReleasesSchema.getOrderReleaseType();
		// validations
		List<OrderReleases> orderReleasesList = orderReleases.stream().filter(order -> {
			if (Objects.nonNull(order) && order.getSelectable() && CollectionUtils.isEmpty(order.getRemarks())) {
				if (Objects.nonNull(order.getOrderReleaseGID())
						&& !order.getOrderReleaseGID().contains(otmConstants.getDomainName() + ".")) {
					order.setOrderReleaseGID(otmConstants.getDomainName() + "." + order.getOrderReleaseGID());
				}
				depotids.add(order.getSourceLocationGID());
				orderNumbers.add(order.getOrderReleaseGID());
				return true;
			}
			return false;
		}).map(orderrelease -> orderrelease).collect(Collectors.toList());
		sourceLocations = new ArrayList<String>(depotids);
		if (CollectionUtils.isEmpty(orderReleasesList) && CollectionUtils.isEmpty(sourceLocations)) {
			throw new IllegalStateException("Provide valid Orders.");
		}
		if (otmService.getUserBlockingTime(sourceLocations)) {
			throw new IllegalStateException("User Not Allowed. Please try again later !");
		}
		shipmentCreationRequest.setUsername(username);
		shipmentCreationRequest.setStatus(OTMConstants.OPEN);
		shipmentCreationRequest.setRequestType("Creation");
		if (OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseType)) {
			List<String> multiCheck = new ArrayList<String>();
			orderReleasesList.forEach(order -> {
				String locationAttribute = order.getLocationAttribute1();  
				if (StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_CD) && !multiCheck.contains(OTMConstants.CUSTUMER_TYPE_CD)) {
					multiCheck.add(OTMConstants.CUSTUMER_TYPE_CD);
				} else if ((StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_MT)||StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_MT1)) && !multiCheck.contains(OTMConstants.CUSTUMER_TYPE_MT)) {
					multiCheck.add(OTMConstants.CUSTUMER_TYPE_MT);
				} else if(!multiCheck.contains(OTMConstants.CUSTUMER_TYPE_GT)){
					multiCheck.add(OTMConstants.CUSTUMER_TYPE_GT);
				}
			});
			if(multiCheck.size() > 1) {
				shipmentCreationRequest.setRequestType(OTMConstants.BULK_CREATION);
			}
		}
		shipmentCreationRequest.setReasons(orderReleasesSchema.getReason());
		LocalDateTime currentISTLocalDateTime = dateutil.getCurrentISTLocalDateTime();
		shipmentCreationRequest.setCreatedDateTime(currentISTLocalDateTime);
		shipmentCreationRequest.setModifiedDateTime(currentISTLocalDateTime);
		shipmentCreationRequest.setNumberOfOrders(orderReleasesList.size());
		String shipmentRequestId = commonUtil.getSequencePrefix(String.valueOf(repository.getShipmentRequestValue()));
		shipmentCreationRequest.setRequestNumber(shipmentRequestId);

		shipmentCreationRequest.setDepotId(String.join(",", depotids));
		shipmentCreationRequest.setShipmentType(orderReleaseType);
		shipmentCreationRequest.setImage(orderReleasesSchema.getImage());
		
		
		ShipmentCreationRequestLog shipmentlog = new ShipmentCreationRequestLog();
		shipmentlog.setRequestNumber(shipmentRequestId);
		shipmentlog.setOrdersNumbers(String.join(",", orderNumbers));
		repositoryLog.save(shipmentlog);
		repository.save(shipmentCreationRequest);
		logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Bulk Shipment creation with req id : "+shipmentRequestId+" type : "+shipmentCreationRequest.getRequestType(), "INFO"));
		try {
			shipmentCreationFacade.deleteOrderReleaseRefnum(orderReleasesList);
			shipmentCreationFacade.createOrderReleaseRefnum(orderReleasesList, shipmentRequestId);
			if (Objects.nonNull(orderReleaseType)) {
				shipmentCreationFacade.shipmentSegregation(orderReleasesList, sourceLocations, orderReleaseType, shipmentRequestId);
			} else {
				List<OrderReleases> secondaryOutboundType = new ArrayList<OrderReleases>();
				List<OrderReleases> primaryOutboundType = new ArrayList<OrderReleases>();
				List<OrderReleases> secondaryDDType = new ArrayList<OrderReleases>();

				orderReleasesList.forEach(order -> {
					if (StringUtils.equals(order.getOrderReleaseTypeGID(), OTMConstants.SECONDARY_OUTBOUND_DELIVERY)) {
						secondaryOutboundType.add(order);
					} else if (StringUtils.equals(order.getOrderReleaseTypeGID(),
							OTMConstants.PRIMARY_OUTBOUND_DELIVERY)) {
						primaryOutboundType.add(order);
					} else {
						secondaryDDType.add(order);
					}
				});
				shipmentCreationFacade.shipmentSegregation(secondaryOutboundType, sourceLocations, OTMConstants.SECONDARY_OUTBOUND_DELIVERY,
						shipmentRequestId);
				shipmentCreationFacade.shipmentSegregation(primaryOutboundType, sourceLocations, OTMConstants.PRIMARY_OUTBOUND_DELIVERY,
						shipmentRequestId);
				shipmentCreationFacade.shipmentSegregation(secondaryDDType, sourceLocations, OTMConstants.SECONDARY_DIRECT_DISPATCH_DELIVERY,
						shipmentRequestId);
			}
		} catch (Exception e) {
			log.error("Error processing Shipment Creation with exception : {}", e.getMessage());
			orderReleasesList.forEach(order -> order.setCrRequestId(shipmentRequestId));
			shipmentCreationFacade.deleteOrderReleaseRefnum(orderReleasesList);
			shipmentCreationRequest.setStatus("Failed");
			shipmentCreationRequest.setFailureReason(e.getMessage());
			if (e instanceof RestClientException) {
				shipmentCreationRequest.setFailureReason("Unable to connect, please try again later!");
			}
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Bulk Shipment creation Failed with req id : "+shipmentRequestId +" reason : "+ shipmentCreationRequest.getFailureReason(), "ERROR"));
			repository.updateShipmentResponses(shipmentCreationRequest.getRequestNumber(), null,
					shipmentCreationRequest.getStatus(), null, shipmentCreationRequest.getFailureReason(),
					shipmentCreationRequest.getNumberOfShipments(), dateutil.getCurrentISTLocalDateTime());
		}
		log.info("END ShipmentCreationRequest");
		return shipmentCreationRequest;
	}

}
