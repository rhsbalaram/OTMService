package com.unilever.otmbulkautomation.util;

import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class ExcelUtils {

//	public List<List<String>> getExcelRows(InputStream file) {
//		List<List<String>> rows = new ArrayList<>();
//		try {
//			XSSFWorkbook workbook = new XSSFWorkbook(file);
//			Sheet datatypeSheet = workbook.getSheetAt(0);
//			Iterator<Row> iterator = datatypeSheet.iterator();
//			while (iterator.hasNext()) {
//				Row currentRow = iterator.next();
//				Iterator<Cell> cellIterator = currentRow.iterator();
//				List<String> cells = new ArrayList<>();
//				while (cellIterator.hasNext()) {
//					Cell currentCell = cellIterator.next();
//					if (currentCell.getCellType() == CellType.STRING) {
//						cells.add(currentCell.getStringCellValue());
//					} else if (currentCell.getCellType() == CellType.NUMERIC) {
//						cells.add(String.valueOf(currentCell.getNumericCellValue()));
//					}
//				}
//				rows.add(cells);
//			}
//			workbook.close();
//		} catch (IOException e) {
//			log.error("Error reading excel file : {}", e.getMessage());
//		}
//		return rows;
//	}

	
//	public List<User> getUsersData(InputStream file) {
//		List<List<String>> excelRows = getExcelRows(file);
//		return excelRows.stream().filter(rows -> CollectionUtils.isNotEmpty(rows)).map(row -> {
//			User user = new User();
//			user.setUsername(row.get(0));
//			user.setEmailId(row.get(1));
//			user.setRole(row.get(2));
//			return user;
//		}).collect(Collectors.toList());
//	}

//	public List<UserDetail> getUserDetailsData(InputStream file) {
//		List<List<String>> excelRows = getExcelRows(file);
//		return excelRows.stream().filter(rows -> CollectionUtils.isNotEmpty(rows)).map(row -> {
//			UserDetail depot = new UserDetail();
//			depot.setUsername(row.get(0));
//			depot.setDepotId(row.get(1));
//			depot.setShipmentType(row.get(2));
//			return depot;
//		}).collect(Collectors.toList());
//	}
}
