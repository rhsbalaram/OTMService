package com.unilever.otmbulkautomation.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.domain.User;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentApproval;
import com.unilever.otmbulkautomation.schema.ShipmentApprovalSchemaWrapper;
import com.unilever.otmbulkautomation.service.ShipmentApprovalService;
import com.unilever.otmbulkautomation.service.ShipmentCancellationService;
import com.unilever.otmbulkautomation.service.ShipmentEqchangeService;
import com.unilever.otmbulkautomation.service.ShipmentUnassignService;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

@RestController
@RequestMapping("admin/shipment")
public class ShipmentApprovalController {
	
	@Autowired
	ShipmentApprovalService shipmentApprovalService;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMShipmentConstants otmShipmentConstants;
	
	@Autowired
	ShipmentCancellationService shipmentCancellationService;
	
	@Autowired
	ShipmentUnassignService shipmentUnassignService;
	
	@Autowired
	ShipmentEqchangeService shipmentEqchangeService;
	
	@Autowired
	UserRepository users;
	
	@GetMapping("/approve")
	public ResponseEntity<Object> getShipmentApproval(@RequestParam("sourceLocation") Set<String> sourceLocations, @RequestParam("shipmentType") Set<String> shipmentType) throws Exception{
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		Optional<User> findByUsername = this.users.findByUsername(username);
		String module = "";
//		if(findByUsername.isPresent()) {
//			User user = findByUsername.get();
//			 module = user.getModule();
//			if(Objects.isNull(module)) {
//				ShipmentApprovalSchemaWrapper shipmentApprovalSchemaWrapper = new ShipmentApprovalSchemaWrapper();
//				shipmentApprovalSchemaWrapper.setError("No Modules Assigned");
//				return new ResponseEntity(shipmentApprovalSchemaWrapper,HttpStatus.OK);
//			}
//		}
		List<String> sourceLocation = new ArrayList<>(sourceLocations);
		List<String> shipTypes = shipmentType.stream().map(shptype -> commonUtil.getULFShipmentType(shptype)).collect(Collectors.toList());
		SchemaWrapper orderReleasesFromOtm = shipmentApprovalService.getApprovalShipmentsFromOtm(sourceLocation, shipTypes, module);
		return new ResponseEntity(orderReleasesFromOtm,HttpStatus.OK);
	}
	
	@PostMapping("/approve")
	public ResponseEntity<Object> postShipmentApproval(@RequestBody ShipmentApprovalSchemaWrapper shipments) throws Exception{
		String username = SecurityContextHolder.getContext().getAuthentication().getName();

		List<ShipmentApproval> creation = new ArrayList<>();
		List<ShipmentApproval> cancellation = new ArrayList<>();
		List<ShipmentApproval> assign = new ArrayList<>();
		List<ShipmentApproval> unassign = new ArrayList<>();
		List<ShipmentApproval> eqchange = new ArrayList<>();

		shipments.getShipments().stream().forEach(shp -> {
			String refvalue = shp.getRefValue();
			if(StringUtils.equals(otmShipmentConstants.getShipmentCreatePending(), refvalue)) {
				creation.add(shp);
			} else if(StringUtils.equals(otmShipmentConstants.getShipmentCancelPending(), refvalue)) {
				cancellation.add(shp);
			}
			else if(StringUtils.equals(otmShipmentConstants.getShipmentAssignPending(), refvalue)) {
				assign.add(shp);
			}else if(StringUtils.equals(otmShipmentConstants.getShipmentUnassignPending(), refvalue)) {
				unassign.add(shp);
			}
			else if(StringUtils.equals(otmShipmentConstants.getShipmentEquipmentPending(), refvalue)) {
				eqchange.add(shp);
			}
		});
		 List<ShipmentApproval> postShipmentApproval = shipmentApprovalService.postShipmentApproval(creation, shipments.getStatus(), username);
		 List<ShipmentApproval> postAssignShipmentApproval = shipmentApprovalService.postAssignShipmentApproval(assign, shipments.getStatus(), username);
		 List<ShipmentApproval> postCancellationByShipmentId = shipmentCancellationService.postCancellationByShipmentId(cancellation, shipments.getStatus(), username);
		 shipmentUnassignService.postUnAssignByShipment(unassign, shipments.getStatus(), username);
		 shipmentEqchangeService.postEqchangeByShipment(eqchange, shipments.getStatus(), username);
	//	shipments.getShipments().addAll(postShipmentApproval);
	//	shipments.getShipments().addAll(postCancellationByShipmentId);

		 return new ResponseEntity(shipments.getShipments(),HttpStatus.OK);
	}

}
