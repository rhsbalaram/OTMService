package com.unilever.otmbulkautomation.facade;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.DistributedLock;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.repository.DistributedLockRepository;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.schema.LocationRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnum;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.ProcessControlRequest;
import com.unilever.otmbulkautomation.schema.ProcessControlRequestSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SavedQuery;
import com.unilever.otmbulkautomation.schema.SavedQuerySchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentRefnum;
import com.unilever.otmbulkautomation.schema.ShipmentRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.service.OTMService;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentCreationFacade {

	@Autowired
	DBServletPojoMapper mapper;

	@Autowired
	CommonUtils commonUtil;

	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	DistributedLockRepository lock;

	@Autowired
	DBServletRestUtil restUtil;

	@Autowired
	OTMShipmentConstants otmShipmentConstants;

	@Autowired
	OTMDateUtil dateutil;
	
	@Autowired
	OTMService otmService;
	
	@Autowired
	OTMLogsRepository logsRepo;

	/*
	 * segregation based on types.
	 */
	@Transactional
	public void shipmentSegregation(List<OrderReleases> orderReleasesList, List<String> sourceLocations,
			String orderReleaseType, String shipmentRequestId) {
		if (OTMConstants.SECONDARY_OUTBOUND_DELIVERY.equals(orderReleaseType)) {
			List<OrderReleases> cdTypeOrderList = new ArrayList<OrderReleases>();
			List<OrderReleases> mtTypeOrderList = new ArrayList<OrderReleases>();
			List<OrderReleases> gtTypeOrderList = new ArrayList<OrderReleases>();
			orderReleasesList.forEach(order -> {
				String locationAttribute = order.getLocationAttribute1();  
				if (StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_CD)) {
					cdTypeOrderList.add(order);
				} else if (StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_MT)||StringUtils.equals(locationAttribute, OTMConstants.CUSTUMER_TYPE_MT1)) {
					mtTypeOrderList.add(order);
				} else {
					gtTypeOrderList.add(order);
				}
			});
			processShipment(cdTypeOrderList, sourceLocations, shipmentRequestId, "CD");
			processShipment(mtTypeOrderList, sourceLocations, shipmentRequestId, "MT");
			processShipment(gtTypeOrderList, sourceLocations, shipmentRequestId, "GT");

		} else if(OTMConstants.PRIMARY_OUTBOUND_DELIVERY.equals(orderReleaseType)){
			processShipment(orderReleasesList, sourceLocations, shipmentRequestId, "POB");
		} else {
			processShipment(orderReleasesList, sourceLocations, shipmentRequestId, "DD");
		}
	}
	
	/*
	 * Process Shipment Steps
	 */
	private void processShipment(List<OrderReleases> orderReleases, List<String> sourceLocations,
			String shipmentRequestId, String customerType) {
		if (!CollectionUtils.isEmpty(orderReleases)) {
			List<String> orderReleasesList = orderReleases.stream().map(order -> order.getOrderReleaseGID())
					.collect(Collectors.toList());
			CreateSavedQueryInOTM(orderReleasesList,
					otmShipmentConstants.getShipmentCreation() + shipmentRequestId + customerType);
			String locationRefnumParams = getLocationRefnumParams(sourceLocations, customerType);
			//String locationRefnumParams = "ULF.ULF_PLANNING_PARAMETER";
			boolean partitionRequired = false;
			if ("CD".equals(customerType) && otmShipmentConstants.isPartitionLogicRequired()) {
				partitionRequired = isPartitionRequired();
			}
			synchronized (this) {
				DistributedLock maxProcessScenario = lock.findByScenario(otmShipmentConstants.getMaxProcessControlRequestIdScenario());
				if(Objects.isNull(maxProcessScenario)) {
					maxProcessScenario = new DistributedLock();
					maxProcessScenario.setFlag("TRUE");
					maxProcessScenario.setScenario(otmShipmentConstants.getMaxProcessControlRequestIdScenario());
					lock.save(maxProcessScenario);
				}
				ProcessControlRequestSchemaWrapper maxProcessControlRequest = getMaxProcessControlRequestId();
				String postInsertQueryToDBServlet = createProcessControlRequest(maxProcessControlRequest,
						otmShipmentConstants.getShipmentCreation() + shipmentRequestId + customerType,
						locationRefnumParams, partitionRequired);
				if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
					throw new IllegalStateException("Error creating processcontrol request");
				}
			}
		}
	}

	/*
	 * deleteOrderReleaserefnum if present
	 */
	public void deleteOrderReleaseRefnum(List<OrderReleases> orderReleases) {
		log.info("START deleteOrderReleaseRefnum");
		List<OrderReleaseRefnum> refnumList = orderReleases.stream()
				.filter(order -> Objects.nonNull(order.getCrRequestId())).map(orderrelease -> {
					OrderReleaseRefnum orderReleaseRefnum = new OrderReleaseRefnum();
					orderReleaseRefnum.setOrderReleaseGid(orderrelease.getOrderReleaseGID());
					orderReleaseRefnum
							.setOrderReleaseRefnumQualGid(otmShipmentConstants.getOrderReleaseRefNumQualGid());
					orderReleaseRefnum.setOrderReleaseRefnumValue(orderrelease.getCrRequestId());
					orderReleaseRefnum.setDomainName(otmShipmentConstants.getDomainName());
					return orderReleaseRefnum;
				}).collect(Collectors.toList());
		if (!CollectionUtils.isEmpty(refnumList)) {
			OrderReleaseRefnumSchemaWrapper orderReleaseRefnumSchemaWrapper = new OrderReleaseRefnumSchemaWrapper();
			orderReleaseRefnumSchemaWrapper.setOrderReleaseRefnums(refnumList);
			String dbServletMappedXml = mapper.getDBServletMappedXml(orderReleaseRefnumSchemaWrapper);
			String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D", dbServletMappedXml);
			if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
				log.error("Error deleting OrderReleaseRefnum :{}", postInsertQueryToDBServlet);
				logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error deleting OrderReleaseRefnum"+orderReleases, "ERROR"));
			}
		}
		log.info("END deleteOrderReleaseRefnum");
	}

	/*
	 * createOrderReleaseRefnum
	 */
	public void createOrderReleaseRefnum(List<OrderReleases> orderReleasesList, String requestId) {
		log.info("START createOrderReleaseRefnum");
		ArrayList<OrderReleaseRefnum> refnumList = new ArrayList<OrderReleaseRefnum>();
		orderReleasesList.forEach(orderRelease -> {
			OrderReleaseRefnum orderReleaseRefnum = new OrderReleaseRefnum();
			orderReleaseRefnum.setOrderReleaseGid(orderRelease.getOrderReleaseGID());
			orderReleaseRefnum.setOrderReleaseRefnumQualGid(otmShipmentConstants.getOrderReleaseRefNumQualGid());
			orderReleaseRefnum.setOrderReleaseRefnumValue(requestId);
			orderReleaseRefnum.setDomainName(otmShipmentConstants.getDomainName());
			refnumList.add(orderReleaseRefnum);
		});
		OrderReleaseRefnumSchemaWrapper orderReleaseRefnumSchemaWrapper = new OrderReleaseRefnumSchemaWrapper();
		orderReleaseRefnumSchemaWrapper.setOrderReleaseRefnums(refnumList);
		String dbServletMappedXml = mapper.getDBServletMappedXml(orderReleaseRefnumSchemaWrapper);
		String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("I", dbServletMappedXml);
		if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "Error creating OrderReleaseRefnum"+orderReleasesList+" req id : "+requestId, "ERROR"));
		}
		log.info("END createOrderReleaseRefnum");
	}

	/*
	 * CreateSavedQueryInOTM
	 */
	public void CreateSavedQueryInOTM(List<String> orderReleasesList, String requestId) {
		log.info("START CreateSavedQueryInOTM");
		ArrayList<SavedQuery> savedQuries = new ArrayList<SavedQuery>();
		SavedQuery savedQuery = new SavedQuery();
		savedQuery.setDomainName(otmShipmentConstants.getDomainName());
		savedQuery.setSavedQueryGID(otmShipmentConstants.getDomainName() + "." + requestId);
		savedQuery.setSaveQueryXID(requestId);
		savedQuery.setUserQueryName(requestId);
		savedQuery.setQueryName(otmShipmentConstants.getQueryName());
		savedQuery.setUseInFinder("N");
		savedQuery.setIsCondition("Y");
		savedQuery.setIsHiddenForMilestones("N");
		String query = MessageFormat.format(otmShipmentConstants.getOtmSavedQuery(),
				new Object[] { commonUtil.getCommaDelimiterString(orderReleasesList) });
		savedQuery.setSqlCheckOne(query);
		savedQuery.setSqlFindAll(query);
		savedQuries.add(savedQuery);
		SavedQuerySchemaWrapper savedQuerySchemaWrapper = new SavedQuerySchemaWrapper();
		savedQuerySchemaWrapper.setSavedQueries(savedQuries);
		String dbServletMappedXml = mapper.getDBServletMappedXml(savedQuerySchemaWrapper);
		String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("I", dbServletMappedXml);
		if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
			throw new IllegalStateException("Error creating SavedQueryInOTM");
		}
		log.info("END CreateSavedQueryInOTM");
	}

	/*
	 * Getting LocationRefnumParams
	 */
	private String getLocationRefnumParams(List<String> sourceLocationGIDs, String customerType) {
		String paramType = StringUtils.isBlank(customerType) ? otmShipmentConstants.getLocationRefnum()
				: otmShipmentConstants.getLocationRefnum() + "_" + customerType;
		String query = MessageFormat.format(otmShipmentConstants.getLocationParamsQuery(),
				new Object[] { commonUtil.getCommaDelimiterString(sourceLocationGIDs), paramType });
		String dbString = restUtil.postGetQueryToDBServlet("LOCATION_REFNUM", query);
		SchemaWrapper dbServletMappedPojo = mapper.getDBServletMappedPojo(dbString, LocationRefnumSchemaWrapper.class);
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			LocationRefnumSchemaWrapper locationrefValue = (LocationRefnumSchemaWrapper) dbServletMappedPojo;
			return locationrefValue.getLocationRefnums().get(0).getLocationRefNumValue();
		} else {
			throw new IllegalStateException("Error getting LocationRefnumParams for locations : " + sourceLocationGIDs + "customerType : " + customerType);
		}
	}

	/*
	 * Getting is Partition required
	 */
	private boolean isPartitionRequired() {
		String dbString = restUtil.postGetQueryToDBServlet("LOCATION_REFNUM",
				otmShipmentConstants.getIsPartitionRequiredQuery());
		SchemaWrapper dbServletMappedPojo = mapper.getDBServletMappedPojo(dbString, LocationRefnumSchemaWrapper.class);
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * Getting Max ProcessControlRequestId
	 */
	private ProcessControlRequestSchemaWrapper getMaxProcessControlRequestId() {
		String dbString = restUtil.postGetQueryToDBServlet("PROCESS_CONTROL_REQUEST",
				otmShipmentConstants.getMaxProcessControlRequestIdQuery());
		SchemaWrapper dbServletMappedPojo = mapper.getDBServletMappedPojo(dbString,
				ProcessControlRequestSchemaWrapper.class);
		if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
			return (ProcessControlRequestSchemaWrapper) dbServletMappedPojo;
		} else {
			throw new IllegalStateException("Error getting MaxProcessControlRequestId");
		}
	}

	/*
	 * createprocesscontrol
	 */
	private String createProcessControlRequest(ProcessControlRequestSchemaWrapper processcontrol, String requestId,
			String plannedParam, boolean isPartitionRequired) {
		log.info("START createProcessControlRequest");
		ProcessControlRequest processControlRequest = processcontrol.getProcessControlRequests().get(0);
		processControlRequest.setDomainName(otmShipmentConstants.getDomainName());
		processControlRequest.setTopicAliasGid(otmShipmentConstants.getTopicAliasGID());
		String cmd = otmShipmentConstants.getProcessControlCmd();
		if (isPartitionRequired) {
			cmd = otmShipmentConstants.getProcessControlPartitionCmd();
		}
		String command = MessageFormat.format(cmd,
				new Object[] { plannedParam, otmShipmentConstants.getUsername(), requestId });
		processControlRequest.setTopicParameters(command);
		processControlRequest.setNextProcessTime(dateutil.getCurrentUTCDateTime());
		String dbServletMappedXml = mapper.getDBServletMappedXml(processcontrol);
		return restUtil.postInsertQueryToDBServlet("I", dbServletMappedXml);
	}
	
	
	public void createOrDeleteShipmentRefnum(List<String> shipmentGids, String refnumQualGid,String refnumValue, String operation) {
		log.info("START createShipmentRefnum");
		ArrayList<ShipmentRefnum> refnumList = new ArrayList<ShipmentRefnum>();
		shipmentGids.forEach(shipmentGid -> {
			ShipmentRefnum shipmentRefnum = new ShipmentRefnum();
			shipmentRefnum.setDomainName(otmShipmentConstants.getDomainName());
			shipmentRefnum.setRefnumQualGid(refnumQualGid);
			shipmentRefnum.setShipmentGid(shipmentGid);
			shipmentRefnum.setRefnumValue(refnumValue);
			refnumList.add(shipmentRefnum);
		});
		ShipmentRefnumSchemaWrapper shipmentRefnumSchemaWrapper = new ShipmentRefnumSchemaWrapper();
		shipmentRefnumSchemaWrapper.setShipmentRefnums(refnumList);
		String dbServletMappedXml = mapper.getDBServletMappedXml(shipmentRefnumSchemaWrapper);
		String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet(operation, dbServletMappedXml);
		if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
			logsRepo.save(new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), shipmentGids +" Error posting refnum with "+operation + " for "+ refnumQualGid +" value :"+ refnumValue, "ERROR"));
		}
		log.info("END createShipmentRefnum");
	}
}
