package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT")
public class ShipmentXlane
{
	
	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_LOCATION_GID")
    private String sourceLocGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_GEO_HIERARCHY_GID")
    private String sourceGeoHiGid;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_REGION_GID")
    private String sourceRegionGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_GEO_HIERARCHY_GID")
    private String destGeoHiGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_LOCATION_GID")
    private String destLocationGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_REGION_GID")
    private String destRegionGid;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_CITY")
    private String destCity;

	@JacksonXmlProperty(isAttribute = true, localName = "DEST_PROVINCE_CODE")
    private String destprovCode;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_CITY")
    private String sourceCity;

	@JacksonXmlProperty(isAttribute = true, localName = "SOURCE_PROVINCE_CODE")
    private String sourceProvCode;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_STOPS_CONSTRAINT")
    private String totalStopConstraint;

	@JacksonXmlProperty(isAttribute = true, localName = "PICKUP_STOPS_CONSTRAINT")
    private String pickUpStopConstraint;

	@JacksonXmlProperty(isAttribute = true, localName = "DELIVERY_STOPS_CONSTRAINT")
    private String deliveryStopContraint;
	
	
}