package com.unilever.otmbulkautomation.util;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.unilever.otmbulkautomation.common.OTMConstants;
@Component
public class CommonUtils {
	
	@Autowired
	OTMDateUtil dateutil;
	
	public String getCommaDelimiterString(List<String> list) {
		final StringBuffer delimiterString = new StringBuffer();
		list.stream().forEach(id -> {
			StringBuffer each = delimiterString.length() == 0 ? delimiterString.append("'" + id + "'")
					: delimiterString.append(",'" + id + "'");
		});
		return delimiterString.toString();
	}
	

	/**
	 * FUNCTION USED TO GENERATE SEQUENCE PREFIX: DATE+"REQUIRED ZEROs"+requestNumber CODE
	 * 
	 * @param 9
	 * @return DDMMYYYY9999
	 */
	public String getSequencePrefix(String requestNumber) {
		String temp = dateutil.getCurrentUTCDate();
		if (requestNumber.length() < 4) {
			int zeroCount = 4 - requestNumber.length();
			for (int index = 0; index < zeroCount; index++) {
				temp = temp + "0";
			}
		}
		return temp+requestNumber;
	}
	
	public String getShipmentType(String type) {
		if(Objects.nonNull(type)) {
		switch(type) {
		case OTMConstants.PRIMARY_OUTBOUND_DELIVERY : return "POB";
		case OTMConstants.SECONDARY_OUTBOUND_DELIVERY : return "SOB";
		case OTMConstants.SECONDARY_DIRECT_DISPATCH_DELIVERY : return "DD";
		}
		}
		return "";
	}
	
	public String getULFShipmentType(String type) {
		if(Objects.nonNull(type)) {
		switch(type) {
		case  "POB": return OTMConstants.PRIMARY_OUTBOUND_DELIVERY ;  
		case "SOB" : return OTMConstants.SECONDARY_OUTBOUND_DELIVERY ;  
		case "DD" : return OTMConstants.SECONDARY_DIRECT_DISPATCH_DELIVERY;   
		}
		}
		return "";
	}
}
