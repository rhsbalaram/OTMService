package com.unilever.otmbulkautomation.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.unilever.otmbulkautomation.common.DBConfigScheduler;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.security.JwtTokenProvider;
import com.unilever.otmbulkautomation.service.OTMService;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/otm")
@Log4j2
public class OTMController {

	@Autowired
	OTMService otmservice;
	
	@Autowired
	DBConfigScheduler sch;
	
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	@Autowired
	OTMShipmentConstants check;
	
	@Autowired
	OTMResponseUtil otmResponseUtil;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	String text = "";
	
	
	@PostMapping(value = "/bulkUpdateStatus", consumes = { MediaType.ALL_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity updateShipmentStatus(@RequestBody String request) {
		log.info("OTM Response received");
		if(Objects.nonNull(request)) {
			String responseType = otmUtil.getResponseType(request);
			if(StringUtils.equals(responseType, "CANCEL")) {
				otmservice.updateShipmentCancellationStatus(request);
			}
			else if(StringUtils.equals(responseType, "ASSIGN")) {
				otmservice.updateShipmentAssignStatus(request);
			}
			else if(StringUtils.equals(responseType, "UNASSIGN")) {
				otmservice.updateShipmentUnAssignStatus(request);
			}
			else if(StringUtils.equals(responseType, "EQCHANGE")) {
				otmservice.updateShipmentUnAssignStatus(request);
			}
			else {
				otmservice.updateShipmentCreationStatus(request);
			}
		}
		return new ResponseEntity<>("success", HttpStatus.OK); 
	}
	
	@GetMapping(value="/check")
	public void resetSequence() {
		log.info(check.isPartitionLogicRequired());
	}
	
	@GetMapping(value="/checkEmail")
	public void checkEmail1(HttpServletRequest request) {
		this.text = "GET"+request.getQueryString();
	}
	
	@PostMapping(value="/checkEmail", consumes = { MediaType.ALL_VALUE})
	public void checkEmail2(@RequestBody String request) {
		this.text = "POST"+request;
	}
	
	@GetMapping(value="/testEmail")
	public String checkEmail3() {
		return this.text;
	}
	
	@GetMapping(value="/shipmentApproval", produces = "text/html;charset=UTF-8")
	public ResponseEntity status(@RequestParam("token") String token, @RequestParam("shipmentId") String shipmentId,@RequestParam("requestId") String requestId,
			@RequestParam("userId") String userId, @RequestParam("status") String status) {
		String html = "Referring shipment has been outdated.";
		try {
		boolean validateToken = jwtTokenProvider.validateToken(token);
		if(validateToken && Objects.nonNull(shipmentId) && Objects.nonNull(status)) {
			html = otmservice.getShipmentDetailsFromOtm(shipmentId);
			if (OTMConstants.TENDER_NOCALL.equals(html)) {
				String transmission = otmservice.postStatusToOTM(shipmentId, status,requestId, userId);
				if (StringUtils.isNumeric(transmission)) {
					if(OTMConstants.APPROVED.equals(status)) {
						html = "Your Approval request is being processed";
					} else {
						html = "Your Rejection request is being processed";
					}
				} else {
					html = "Something went wrong with this shipment data.";
				}
			}
		}
		}catch (Exception e) {
			//Session Expired;
		}
		
		return new ResponseEntity<>(otmResponseUtil.getConfirmationHtml(html), HttpStatus.OK); 
	}
	
	@GetMapping(value="/shipmentAssign", produces = "text/html;charset=UTF-8")
	public ResponseEntity assign(@RequestParam("token") String token, @RequestParam("shipmentId") String shipmentId,@RequestParam("requestId") String requestId,
			@RequestParam("userId") String userId, @RequestParam("status") String status) {
		String html = "Referring shipment has been outdated.";
		try {
		boolean validateToken = jwtTokenProvider.validateToken(token);
		if(validateToken && Objects.nonNull(shipmentId) && Objects.nonNull(status)) {
			html = otmservice.getShipmentDetailsFromOtm(shipmentId);
			if (OTMConstants.TENDER_CALL_CANCEL.equals(html) || OTMConstants.TENDER_NOCALL.equals(html)) {
				String transmission = otmservice.postAssignStatusToOTM(shipmentId, status,requestId, userId);
				if (StringUtils.isNumeric(transmission)) {
					if(OTMConstants.APPROVED.equals(status)) {
						html = "Your Approval request is being processed";
					} else {
						html = "Your Rejection request is being processed";
					}
				} else {
					html = "Something went wrong with this shipment data.";
				}
			}
		}
		}catch (Exception e) {
			//Session Expired;
		}
		
		return new ResponseEntity<>(otmResponseUtil.getConfirmationHtml(html), HttpStatus.OK); 
	}
	
	//shipmentCancel
	@GetMapping(value="/shipmentCancel", produces = "text/html;charset=UTF-8")
	public ResponseEntity status(@RequestParam("token") String token, @RequestParam("requestId") String requestId,
			@RequestParam("userId") String userId, @RequestParam("status") String status) {
		String html = "Referring shipment has been outdated.";
		try {
		boolean validateToken = jwtTokenProvider.validateToken(token);
		if(validateToken && Objects.nonNull(requestId) && Objects.nonNull(status)) {
			html = otmservice.postCancellationByRequestId(status, requestId, userId);
		}
		}catch (Exception e) {
			//Session Expired;
		}
		
		return new ResponseEntity<>(otmResponseUtil.getConfirmationHtml(html), HttpStatus.OK); 
	}
	
	//shipmentUnassign
	@GetMapping(value = "/shipmentUnAssign", produces = "text/html;charset=UTF-8")
	public ResponseEntity statusUnassign(@RequestParam("token") String token,
			@RequestParam("requestId") String requestId, @RequestParam("userId") String userId,
			@RequestParam("status") String status) {
		String html = "Referring shipment has been outdated.";
		try {
			boolean validateToken = jwtTokenProvider.validateToken(token);
			if (validateToken && Objects.nonNull(requestId) && Objects.nonNull(status)) {
				html = otmservice.postUnassignByRequestId(status, requestId, userId);
			}
		} catch (Exception e) {
			// Session Expired;
		}

		return new ResponseEntity<>(otmResponseUtil.getConfirmationHtml(html), HttpStatus.OK);
	}
	
	//eqchange
		@GetMapping(value = "/eqchange", produces = "text/html;charset=UTF-8")
		public ResponseEntity eqchange(@RequestParam("token") String token,
				@RequestParam("requestId") String requestId, @RequestParam("userId") String userId,
				@RequestParam("status") String status, @RequestParam("shipmentId") String shipmentId) {
			String html = "Referring shipment has been outdated.";
			try {
				boolean validateToken = jwtTokenProvider.validateToken(token);
				if (validateToken && Objects.nonNull(requestId) && Objects.nonNull(status)) {
					html = otmservice.posteqChangeByRequestId(status, requestId, userId, shipmentId);
				}
			} catch (Exception e) {
				// Session Expired;
			}

			return new ResponseEntity<>(otmResponseUtil.getConfirmationHtml(html), HttpStatus.OK);
		}
//	@GetMapping("/video")
//	public ResponseEntity<UrlResource> getFullVideo() throws IOException {
//		UrlResource video = new UrlResource("file:/Users/admin/Downloads/file_example_MP4_1920_18MG.mp4");
//		
//		ResponseEntity<UrlResource> body = ResponseEntity.status(HttpStatus.OK)
//				.contentType(MediaTypeFactory
//						.getMediaType(video)
//						.orElse(MediaType.APPLICATION_OCTET_STREAM))
//				.contentLength(video.contentLength())
//				.body(video);
//		return body;
//	}
//	
//	@GetMapping("/videos")
//	public ResponseEntity<UrlResource> getFullVide() throws IOException {
//		UrlResource video = new UrlResource("file:/Users/admin/Downloads/file_example_MP4_1920_18MG.mp4");
//		
//		ResponseEntity<UrlResource> body = ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
//				.contentType(MediaTypeFactory
//						.getMediaType(video)
//						.orElse(MediaType.APPLICATION_OCTET_STREAM))
//				.contentLength(video.contentLength())
//				.body(video);
//		return body;
//	}
	
}
