package com.unilever.otmbulkautomation.schema;

import lombok.Data;

@Data
public class OrderAttributeUpdate
{
    private String orderReleaseXid;
	
	private String attribute4;

}