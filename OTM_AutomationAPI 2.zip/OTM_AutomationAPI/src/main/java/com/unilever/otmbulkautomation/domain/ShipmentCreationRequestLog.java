package com.unilever.otmbulkautomation.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "SHIPMENT_REQUEST_CREATION_LOG")
public class ShipmentCreationRequestLog {

	@Id
	@Column(name = "REQUEST_NUMBER")
	private String requestNumber;

	@Column(name = "ORDERS_NUMBERS")
	@Lob
	private String ordersNumbers;
	
}
