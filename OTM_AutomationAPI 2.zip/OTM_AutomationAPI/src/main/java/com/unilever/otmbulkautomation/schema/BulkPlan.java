package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "LOCATION_REFNUM")
public class BulkPlan
{
	@JacksonXmlProperty(isAttribute = true, localName = "NUM_OF_SHIPMENTS_BUILT")
    private String numOfShipments;

	@JacksonXmlProperty(isAttribute = true, localName = "QUERY_NAME")
    private String queryName;

	@JacksonXmlProperty(isAttribute = true, localName = "STATE")
    private String state;
}