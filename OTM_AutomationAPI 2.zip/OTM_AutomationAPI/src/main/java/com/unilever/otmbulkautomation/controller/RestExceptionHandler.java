package com.unilever.otmbulkautomation.controller;

import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.ResponseEntity.status;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.security.InvalidJwtAuthenticationException;
import com.unilever.otmbulkautomation.util.OTMDateUtil;

import lombok.extern.log4j.Log4j2;

@Log4j2
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler{
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	OTMDateUtil dateutil;

    @ExceptionHandler(InvalidJwtAuthenticationException.class)
    public ResponseEntity invalidJwtAuthentication(InvalidJwtAuthenticationException ex, WebRequest request) {
        log.debug("handling InvalidJwtAuthenticationException...");
        OtmLogs otmLogs = new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(),"handling InvalidJwtAuthenticationException...","DEBUG");
        logsRepo.save(otmLogs);
        return status(UNAUTHORIZED).build();
    }
    
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity badCredentials(BadCredentialsException ex, WebRequest request) {
        log.debug(ex.getMessage());
        OtmLogs otmLogs = new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(), "BadCredentialsException", "DEBUG");
        logsRepo.save(otmLogs);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.UNAUTHORIZED);
    }
    
    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity illegalStateException(Exception ex, WebRequest request) {
        log.error("illegalStateException  Exception : {}",ex.getMessage());
        OtmLogs otmLogs = new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(),ex.toString(),"ERROR");
        logsRepo.save(otmLogs);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity exception(Exception ex, WebRequest request) {
        log.error("Internal Server Exception : {}",ex);
        OtmLogs otmLogs = new OtmLogs(null, dateutil.getCurrentISTLocalDateTime(),ExceptionUtils.getStackTrace(ex),"ERROR");
        logsRepo.save(otmLogs);
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  
}
