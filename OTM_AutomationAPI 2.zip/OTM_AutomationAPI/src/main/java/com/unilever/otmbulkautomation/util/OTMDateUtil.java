package com.unilever.otmbulkautomation.util;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

@Component
public class OTMDateUtil {
	public static final DateTimeFormatter OTM_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
	public static final DateTimeFormatter OTM_TIME_FORMAT_1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	public static final DateTimeFormatter OTM_DATE_FORMAT = DateTimeFormatter.ofPattern("ddMMyyyy");
	public static final DateTimeFormatter OJET_DATE_FORMAT = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
	public static final DateTimeFormatter OJET_DATE_FORMAT_1 = DateTimeFormatter.ofPattern("dd-MM-yyyyHHmmss");
	public static final DateTimeFormatter OJET_DATE_FORMAT_2 = DateTimeFormatter.ofPattern("yyyy-MM-ddHHmmss");
	public static final DateTimeFormatter OTM_DATE_QUERY_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");


	public boolean isLessThanOrEqual(String toCompare, int dayToAdd, String toCompareWith) {
		LocalDate dateToCompare = LocalDateTime.parse(toCompare, OTM_TIME_FORMAT).plusMinutes(330l).toLocalDate();
		dateToCompare = dateToCompare.plusDays(dayToAdd);
		LocalDate dateToCompareWith = LocalDateTime.parse(toCompareWith, OTM_TIME_FORMAT).plusMinutes(330l).toLocalDate();
		if (dateToCompare.isEqual(dateToCompareWith) || dateToCompare.isBefore(dateToCompareWith)) {
			return true;
		}
		return false;

	}

	public boolean isEqual(String toCompare, int dayToAdd, String toCompareWith) {
		LocalDate dateToCompare = LocalDateTime.parse(toCompare, OTM_TIME_FORMAT).plusMinutes(330l).toLocalDate();
		dateToCompare = dateToCompare.plusDays(dayToAdd);
		LocalDate dateToCompareWith = LocalDateTime.parse(toCompareWith, OTM_TIME_FORMAT).plusMinutes(330l).toLocalDate();
		if (dateToCompare.isEqual(dateToCompareWith)) {
			return true;
		}
		return false;

	}
	
	public boolean isEqualOrGreaterThanCurrent(String toCompare, int daysToSubtract) {
		LocalDate dateToCompare = LocalDateTime.parse(toCompare, OTM_TIME_FORMAT_1).plusMinutes(330l).toLocalDate();
		LocalDate dateToCompareWith = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime().toLocalDate();
		dateToCompareWith = dateToCompareWith.minusDays(daysToSubtract);
		if (dateToCompare.isEqual(dateToCompareWith) || dateToCompare.isAfter(dateToCompareWith)) {
			return true;
		}
		return false;

	}
	
	
	public String getCurrentUTCDateTime() {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC).toLocalDateTime();
		return localDateTime.format(OTM_TIME_FORMAT);
	}
	
	public String getCurrentUTCDate() {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime();
		return localDateTime.format(OTM_DATE_FORMAT);
	}
	
	public String getCurrentISTDate(DateTimeFormatter format) {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime();
		return localDateTime.format(format);
	}
	
	public String getISTDatePlusDays(long days) {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime().plusDays(days);
		return localDateTime.format(OTM_DATE_QUERY_FORMAT);
	}
	
	public String getISTDateMinusDays(long days) {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime().minusDays(days);
		return localDateTime.format(OTM_DATE_QUERY_FORMAT);
	}
	
	public int getCurrentISTHours() {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime();
		return (localDateTime.getHour()*100)+(localDateTime.getMinute());
	}
	
	public String getCurrentISTString(String utcFormat) {
		LocalDateTime localDateTime = LocalDateTime.parse(utcFormat, OTM_TIME_FORMAT_1).plusMinutes(330l);
		return localDateTime.format(OTM_DATE_QUERY_FORMAT);
	}
	
	public int getCurrentISTMinutes() {
		LocalDateTime localDateTime = Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime();
		return localDateTime.getMinute();
	}

	public LocalDateTime getCurrentISTLocalDateTime() {
		 return Instant.now().atOffset(ZoneOffset.UTC.ofHoursMinutes(5, 30)).toLocalDateTime();
	}
	
}
