package com.unilever.otmbulkautomation.service;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unilever.otmbulkautomation.common.OTMConstants;
import com.unilever.otmbulkautomation.domain.OtmLogs;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequest;
import com.unilever.otmbulkautomation.domain.ShipmentCreationRequestLog;
import com.unilever.otmbulkautomation.facade.ShipmentCreationFacade;
import com.unilever.otmbulkautomation.repository.OTMLogsRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestLogRepository;
import com.unilever.otmbulkautomation.repository.ShipmentCreationRequestRepository;
import com.unilever.otmbulkautomation.repository.UserRepository;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnum;
import com.unilever.otmbulkautomation.schema.OrderReleaseRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.OrderReleases;
import com.unilever.otmbulkautomation.schema.OrderReleasesSchemaWrapper;
import com.unilever.otmbulkautomation.schema.RegionDetail;
import com.unilever.otmbulkautomation.schema.RegionDetailSchemaWrapper;
import com.unilever.otmbulkautomation.schema.SchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAssign;
import com.unilever.otmbulkautomation.schema.ShipmentAssignSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentAttributesUpdates;
import com.unilever.otmbulkautomation.schema.ShipmentRefnum;
import com.unilever.otmbulkautomation.schema.ShipmentRefnumSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentResponseSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentStatusSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentStopSchemaWrapper;
import com.unilever.otmbulkautomation.schema.ShipmentXlane;
import com.unilever.otmbulkautomation.schema.ShipmentXlaneSchemaWrapper;
import com.unilever.otmbulkautomation.util.CommonUtils;
import com.unilever.otmbulkautomation.util.DBServletPojoMapper;
import com.unilever.otmbulkautomation.util.DBServletRestUtil;
import com.unilever.otmbulkautomation.util.EmailUtil;
import com.unilever.otmbulkautomation.util.OTMDateUtil;
import com.unilever.otmbulkautomation.util.OTMResponseUtil;
import com.unilever.otmbulkautomation.util.OTMShipmentConstants;
import com.unilever.otmbulkautomation.util.OTMValidations;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class ShipmentAssignService {
	
	@Autowired
	DBServletRestUtil dbServletRestUtil;
	
	@Autowired
	DBServletPojoMapper dbServletPojoMapper;
	
	@Autowired
	OTMValidations validations;
	
	@Value("${otm.assign.shipment.getQuery}")
	private String shipmentAssignQuery;
	
	@Value("${otm.assign.shipment.xlane.getQuery}")
	private String shipmentXlaneQuery;
	
	@Value("${otm.assign.shipment.stop.getQuery}")
	private String shipmentStopQuery;
	
	@Value("${otm.assign.shipment.region.getQuery}")
	private String shipmentRegionQuery;
	
	@Value("${otm.orderrelease.refnum.query}")
	private String ordRefnumUnassignGetQuery;
	
	
	@Value("${otm.assign.shipment.details.getQuery}")
	private String shipAssignDetailsGetQuery;
	
	@Autowired
	CommonUtils commonUtil;
	
	@Autowired
	OTMDateUtil dateUtil;
	
	@Autowired
	OTMService otmservice;
	
	@Autowired
	OTMShipmentConstants otmShpConstants;
	
	@Autowired
	private ShipmentCreationRequestRepository repository;
	
	@Autowired
	ShipmentCreationRequestLogRepository repositoryLog;
	
	@Autowired
	OTMLogsRepository logsRepo;
	
	@Autowired
	UserRepository userRepo;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	ShipmentCreationFacade shipmentCreationFacade;
	
	@Autowired
	OTMResponseUtil otmUtil;
	
	@Autowired
	DBServletPojoMapper mapper;
	
	@Autowired
	DBServletRestUtil restUtil;
	
	@Value("${otm.shipmentrefNum.getQuery}")
	private String shipmentrefNumGetQuery;
	
	@Value("${otm.emailApproval.check.query}")
	private String approvalCheckQuery;
	
	@Value("${otm.assign.details.getQuery}")
	private String shipmentAssignDetailsQuery;
	
	ObjectMapper objMapper = new ObjectMapper();
		
	public SchemaWrapper getShipmentsFromOtm(OrderReleasesSchemaWrapper shipments) {
		if (Objects.nonNull(shipments.getOrderReleaseType()) && !CollectionUtils.isEmpty(shipments.getOrderReleases())) {
			String orderReleaseType = shipments.getOrderReleaseType();
			List<OrderReleases> orderReleases = shipments.getOrderReleases();
			List<String> sourceLocationGIDs = new ArrayList<>();
			List<String> destLocationGIDs = new ArrayList<>();

			orderReleases.forEach(order -> {
				if(Objects.nonNull(order.getSourceLocationGID()))
					sourceLocationGIDs.add(order.getSourceLocationGID());
				if(Objects.nonNull(order.getDestinationLocationGID()))
					destLocationGIDs.add(order.getDestinationLocationGID());
				
			});
			String query = "";
			String shipmentCondition = "";
				if(Objects.nonNull(shipments.getShipmentXid())) {
					shipmentCondition = "AND SHIPMENT_XID IN ('"+shipments.getShipmentXid().replaceAll("ULF.", "")+"')";
				}
				String sourceLocationGIDsString = commonUtil.getCommaDelimiterString(sourceLocationGIDs);
				String destLocationGIDsString = commonUtil.getCommaDelimiterString(destLocationGIDs);
				query = MessageFormat.format(shipmentAssignQuery,
						new Object[] { sourceLocationGIDsString, orderReleaseType, shipmentCondition, dateUtil.getISTDateMinusDays(2), sourceLocationGIDsString, sourceLocationGIDsString, destLocationGIDsString, destLocationGIDsString });
			
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentAssignSchemaWrapper.class);
			 validations.valideShipmentForAssign(dbServletMappedPojo);
			 return dbServletMappedPojo;
		} else {
			return null;
		}
	}
	
	public String validateShipmentsFromOtm(OrderReleasesSchemaWrapper shipments) {
		if (Objects.nonNull(shipments.getOrderReleaseType()) && !CollectionUtils.isEmpty(shipments.getOrderReleases()) && Objects.nonNull(shipments.getShipmentXid())) {
			String shipmentid = "ULF."+shipments.getShipmentXid().replaceAll("ULF.", "");
			String query = MessageFormat.format(shipmentrefNumGetQuery,
					new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {{add(shipmentid);}}), otmShpConstants.getShipmentPendingGid() });
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentRefnumSchemaWrapper.class);
			 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
				 List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) dbServletMappedPojo).getShipmentRefnums();
				 if(!CollectionUtils.isEmpty(shipmentRefnums)) {
					   return "Invalid Shipment - Pending for Approval";
				 }
			}

			 query = MessageFormat.format(approvalCheckQuery, new Object[] { shipmentid });
				dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
				dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentStatusSchemaWrapper.class);
				 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
					 ShipmentStatusSchemaWrapper srsw = (ShipmentStatusSchemaWrapper) dbServletMappedPojo;
					if (!CollectionUtils.isEmpty(srsw.getShipmentStatus())) {
						String statusValueGid = srsw.getShipmentStatus().get(0).getStatusValueGid();
						if (Objects.nonNull(statusValueGid)
								&& !StringUtils.equals(statusValueGid, "ULF."+OTMConstants.TENDER_CALL_TENDER)) {
							return "Invalid Shipment - Not FTL";
						}
					} else return "Invalid Shipment - Not FTL";
				 }
				String enroutCheckQuery = approvalCheckQuery.replace("ULF.TENDER CALL", "ULF.ENROUTE");
				 query = MessageFormat.format(enroutCheckQuery, new Object[] { shipmentid });
					dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
					dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentStatusSchemaWrapper.class);
					 if (Objects.nonNull(dbServletMappedPojo) && Objects.isNull(dbServletMappedPojo.getError())) {
						 ShipmentStatusSchemaWrapper srsw = (ShipmentStatusSchemaWrapper) dbServletMappedPojo;
						if (!CollectionUtils.isEmpty(srsw.getShipmentStatus())) {
							String statusValueGid = srsw.getShipmentStatus().get(0).getStatusValueGid();
							List<String> enroute = new ArrayList<String>();
							enroute.add("ENROUTE_ENROUTE");
							enroute.add("ENROUTE_COMPLETED");
							enroute.add("ENROUTE_PARTIAL");
							//enroute.add("");

							if (Objects.nonNull(statusValueGid)
									&& enroute.contains(statusValueGid.replace("ULF.", ""))) {
								return "Invalid Shipment - Enroute "+ statusValueGid;
							}
						} else return "Invalid Shipment - Enroute";
					 }
			String orderReleaseType = shipments.getOrderReleaseType();
			List<OrderReleases> orderReleases = shipments.getOrderReleases();
			Set<String> sourceLocationGIDs = new HashSet<>();
			Set<String> destLocationGIDs = new HashSet<>();
			List<String> orderreleaseGids = new ArrayList<>();
			List<String> clusterids = new ArrayList<>();

			orderReleases.forEach(order -> {
				orderreleaseGids.add(order.getOrderReleaseGID());
				if(Objects.nonNull(order.getCluster())) {
					clusterids.add(order.getCluster());
				}
				if(Objects.nonNull(order.getSourceLocationGID())) {
					if(Objects.nonNull(order.getPlanFromLocation())) {
						sourceLocationGIDs.add(order.getPlanFromLocation());
					} else {
						sourceLocationGIDs.add(order.getSourceLocationGID());
					}

				}
				if(Objects.nonNull(order.getDestinationLocationGID())) {
					if(Objects.nonNull(order.getPlanToLocation())) {
						destLocationGIDs.add(order.getPlanToLocation());
					} else {
						destLocationGIDs.add(order.getDestinationLocationGID());
					}
				}
				
			});
			query = MessageFormat.format(shipmentXlaneQuery,
						new Object[] { shipments.getShipmentXid().replaceAll("ULF.", "") });
			
			 dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentXlaneSchemaWrapper.class);
			 query = MessageFormat.format(shipmentStopQuery,
						new Object[] { shipments.getShipmentXid().replaceAll("ULF.", "") });
			
			 dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_STOP", query);
			 SchemaWrapper shipmentStop = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentStopSchemaWrapper.class);
			 
			 boolean shipmentAssignmentValidation = validations.shipmentAssignmentValidation(dbServletMappedPojo, shipmentStop, sourceLocationGIDs, destLocationGIDs);
			if (shipmentAssignmentValidation) {
				ShipmentXlaneSchemaWrapper shipmentXlaneSchemaWrapper = ((ShipmentXlaneSchemaWrapper) dbServletMappedPojo);
				List<ShipmentXlane> shipmentXlanes = shipmentXlaneSchemaWrapper.getShipmentXlane();
				String sourceRegionGid = "";
				String destRegionGid = "";
				ShipmentXlane shipmentXlane = shipmentXlanes.get(0);
				String sourceLocGid = shipmentXlane.getSourceLocGid();
				String destLocationGid = shipmentXlane.getDestLocationGid();
				if (Objects.isNull(sourceLocGid)) {
					sourceRegionGid = shipmentXlane.getSourceRegionGid();
					query = MessageFormat.format(shipmentRegionQuery,
							new Object[] { commonUtil.getCommaDelimiterString(orderreleaseGids), sourceRegionGid });
					dbString = dbServletRestUtil.postGetQueryToDBServlet("REGION_DETAIL", query);
					SchemaWrapper region = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							RegionDetailSchemaWrapper.class);
					if (Objects.nonNull(region) && Objects.isNull(region.getError())) {
						List<RegionDetail> regionDetails = ((RegionDetailSchemaWrapper) region).getRegionDetails();
						if (regionDetails.size() != orderreleaseGids.size()) {
							return "Region Validation failed :" + regionDetails;
						}
					} else {
						return "Region Validation failed";
					}
				}
				if (Objects.isNull(destLocationGid)) {
					destRegionGid = shipmentXlane.getDestRegionGid();
					query = MessageFormat.format(
							shipmentRegionQuery.replace("ORL.SOURCE_LOCATION_GID", "ORL.DEST_LOCATION_GID"),
							new Object[] { commonUtil.getCommaDelimiterString(orderreleaseGids), destRegionGid });
					dbString = dbServletRestUtil.postGetQueryToDBServlet("REGION_DETAIL", query);
					SchemaWrapper region = dbServletPojoMapper.getDBServletMappedPojo(dbString,
							RegionDetailSchemaWrapper.class);
					if (Objects.nonNull(region) && Objects.isNull(region.getError())) {
						List<RegionDetail> regionDetails = ((RegionDetailSchemaWrapper) region).getRegionDetails();
						if (regionDetails.size() != orderreleaseGids.size()) {
							return "Region Validation failed :" + regionDetails;
						}
					} else {
						return "Region Validation failed";
					}

				}
				return "success";

			} else {
				 if(Objects.nonNull(dbServletMappedPojo.getError())){
					 return dbServletMappedPojo.getError();
				 } 
			 }
			 return "failed";
		} else {
			 return "failed";
		}
	}
	
	public  ShipmentCreationRequest createOrderAssginForShipment(String username, OrderReleasesSchemaWrapper shipmentAssign){
		String orderReleaseType = shipmentAssign.getOrderReleaseType();
		String reason = shipmentAssign.getReason();
		 List<OrderReleases> orderReleases = shipmentAssign.getOrderReleases();
		 String shipmentXid = shipmentAssign.getShipmentXid();
		ShipmentCreationRequest shipmentCreationRequest = new ShipmentCreationRequest();
		if(!CollectionUtils.isEmpty(orderReleases) && Objects.nonNull(shipmentXid)) {
			String shipgid = "ULF."+shipmentXid.replace("ULF.", "");
			 List<String> validgids = new ArrayList<>();
			 Set<String> validdepotids = new HashSet<>();
			 String plannedValues = "";
			 String query = MessageFormat.format(shipAssignDetailsGetQuery,
						new Object[] { shipgid });
			
			 String dbString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT", query);
			 SchemaWrapper dbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(dbString,  ShipmentAssignSchemaWrapper.class);
			 if(Objects.isNull(dbServletMappedPojo.getError())) {
				 List<ShipmentAssign> shipments = ((ShipmentAssignSchemaWrapper)dbServletMappedPojo).getShipments();
				 ShipmentAssign shp = shipments.get(0);
				 String totalWeight = shp.getTotalWeight();
					String totalVolume = shp.getTotalVolume();
				 plannedValues = totalWeight+":"+totalVolume+":"+shp.getEquipmentGroupGid()+":"+shp.getServprovGid();
			 }
			 List<OrderReleases> validorders = orderReleases.stream().filter(ord -> Objects.nonNull(ord)).map(validord ->{
				 validgids.add(validord.getOrderReleaseGID());
				 validdepotids.add(validord.getSourceLocationGID());
				 return validord;
			 }).collect(Collectors.toList());
			 if(!CollectionUtils.isEmpty(validorders)) {
				 	shipmentCreationRequest.setUsername(username);
					shipmentCreationRequest.setStatus(OTMConstants.OPEN);
					shipmentCreationRequest.setRequestType("Assign");
					shipmentCreationRequest.setReasons(reason);
					LocalDateTime currentISTLocalDateTime = dateUtil.getCurrentISTLocalDateTime();
					shipmentCreationRequest.setCreatedDateTime(currentISTLocalDateTime);
					shipmentCreationRequest.setModifiedDateTime(currentISTLocalDateTime);
					shipmentCreationRequest.setNumberOfOrders(validorders.size());
					shipmentCreationRequest.setNumberOfShipments(1);
					String shipmentRequestId = commonUtil.getSequencePrefix(String.valueOf(repository.getShipmentRequestValue()));
					shipmentCreationRequest.setRequestNumber(shipmentRequestId);

					shipmentCreationRequest.setDepotId(String.join(",", validdepotids));
					shipmentCreationRequest.setShipmentType(orderReleaseType);
					shipmentCreationRequest.setResponses(String.join(",", validgids));
					ShipmentCreationRequestLog shipmentlog = new ShipmentCreationRequestLog();
					shipmentlog.setRequestNumber(shipmentRequestId);
					shipmentlog.setOrdersNumbers(shipgid+"-"+String.join(",", validgids)+"-"+plannedValues);
					repositoryLog.save(shipmentlog);
					repository.save(shipmentCreationRequest);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Assignment  with req id : "+shipmentRequestId+" shipments : "+validgids, "INFO"));
					String shpmtType = commonUtil.getShipmentType(orderReleaseType);
						try {
							deleteOrderReleaseRefnum(validgids);
							createOrderReleaseRefnum(validgids, shipmentRequestId);
							//shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipgid);}}, otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentAssignPending(), "I");
							String refquery = MessageFormat.format(shipmentrefNumGetQuery,
									new Object[] { commonUtil.getCommaDelimiterString(new ArrayList<String>() {{add(shipgid);}}), otmShpConstants.getShipmentAssignGid() });
							 String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("SHIPMENT_REFNUM", refquery);
							 SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,  ShipmentRefnumSchemaWrapper.class);
							 if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
								 List<ShipmentRefnum> shipmentRefnums = ((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo).getShipmentRefnums();
								 if(!CollectionUtils.isEmpty(shipmentRefnums)) {
									String dbServletMappedXml = mapper.getDBServletMappedXml(((ShipmentRefnumSchemaWrapper) refdbServletMappedPojo));
									String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D", dbServletMappedXml);
									if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
										log.error("Error Deleting the "+ otmShpConstants.getShipmentAssignGid() + " shipmentids : " + shipgid);
										logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), "Error Deleting the "+ otmShpConstants.getShipmentAssignGid() + " shipmentids : " + shipgid, "ERROR"));
									}
								}
							}
								
							shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipgid);}}, otmShpConstants.getShipmentAssignGid(), shipmentRequestId, "I");
							
//								OrderAttributeUpdate attrUpdate = new OrderAttributeUpdate();
//								attrUpdate.setAttribute4(shipmentXid);
//								attrUpdate.setOrderReleaseXid(validgids.get(0).replaceAll("ULF.", ""));
//								String update = objMapper.writeValueAsString(attrUpdate);
//								String rest = "orderReleases/" + validgids.get(0);
//								dbServletRestUtil.postQueryToRestOTM(rest, update);
							ShipmentAttributesUpdates attrUpdate = new ShipmentAttributesUpdates();
							attrUpdate.setAttribute11(shipmentRequestId);
							attrUpdate.setAttribute12("ASSIGN");
							attrUpdate.setShipmentXid(shipgid.replaceAll("ULF.", ""));
							String update = objMapper.writeValueAsString(attrUpdate);
							String rest = "shipments/" + shipgid;
							dbServletRestUtil.postQueryToRestOTM(rest, update);
							
							logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), validgids +"Created Assignment  with req id : "+shipmentRequestId + " for shipment : "+ shipmentXid , "INFO"));
							
						} catch (Exception e) {  
							//validorders.forEach(order -> order.setRequestId(shipmentRequestId));
							deleteOrderReleaseRefnum(validgids);
							//shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(shipgid);}}, otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentAssignPending(), "D");
							shipmentCreationRequest.setStatus("Failed");
							shipmentCreationRequest.setFailureReason("Assign Creation Error");
							repository.updateShipmentResponses(shipmentCreationRequest.getRequestNumber(), null,
									shipmentCreationRequest.getStatus(), null, shipmentCreationRequest.getFailureReason(),
									shipmentCreationRequest.getNumberOfShipments(), dateUtil.getCurrentISTLocalDateTime());
							log.error("Error Creation Assignment  with req id  : {} with exception : {}", shipmentRequestId, e.getMessage());
							logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), validgids +"Error Creation Assignment  with req id : : "+shipmentRequestId + "  for shipment : "+ shipmentXid + e.getMessage(), "ERROR"));
						}
					
			 }
			 return shipmentCreationRequest;
		}
		return shipmentCreationRequest;
	}
	
	private void deleteOrderReleaseRefnum(List<String> orderids) {
		String refquery = MessageFormat.format(ordRefnumUnassignGetQuery,
				new Object[] { 
						otmShpConstants.getOrderReleaseAssignRefNumQualGid(), commonUtil.getCommaDelimiterString(orderids) });
		String refqueryString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE_REFNUM", refquery);
		SchemaWrapper refdbServletMappedPojo = dbServletPojoMapper.getDBServletMappedPojo(refqueryString,
				OrderReleaseRefnumSchemaWrapper.class);
		if (Objects.nonNull(refdbServletMappedPojo) && Objects.isNull(refdbServletMappedPojo.getError())) {
			 List<OrderReleaseRefnum> orderReleaseRefnums = ((OrderReleaseRefnumSchemaWrapper) refdbServletMappedPojo)
					.getOrderReleaseRefnums();
			if (!CollectionUtils.isEmpty(orderReleaseRefnums)) {
				String dbServletMappedXml = mapper
						.getDBServletMappedXml(((OrderReleaseRefnumSchemaWrapper) refdbServletMappedPojo));
				String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("D",
						dbServletMappedXml);
				if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
					log.error("Error Deleting the " + otmShpConstants.getOrderReleaseUnassignRefNumQualGid()
							+ " orderids : " + orderids);
					logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(),
							"Error Deleting the " + otmShpConstants.getOrderReleaseAssignRefNumQualGid()
									+ " orderids : " + orderids,
							"ERROR"));
				}
			}
		}
	}
	
	/*
	 * createOrderReleaseRefnum
	 */
	public void createOrderReleaseRefnum(List<String> orderReleasesList, String requestId) {
		log.info("START createOrderReleaseRefnum");
		ArrayList<OrderReleaseRefnum> refnumList = new ArrayList<OrderReleaseRefnum>();
		orderReleasesList.forEach(orderRelease -> {
			OrderReleaseRefnum orderReleaseRefnum = new OrderReleaseRefnum();
			orderReleaseRefnum.setOrderReleaseGid(orderRelease);
			orderReleaseRefnum.setOrderReleaseRefnumQualGid(otmShpConstants.getOrderReleaseAssignRefNumQualGid());
			orderReleaseRefnum.setOrderReleaseRefnumValue(requestId);
			orderReleaseRefnum.setDomainName(otmShpConstants.getDomainName());
			refnumList.add(orderReleaseRefnum);
		});
		OrderReleaseRefnumSchemaWrapper orderReleaseRefnumSchemaWrapper = new OrderReleaseRefnumSchemaWrapper();
		orderReleaseRefnumSchemaWrapper.setOrderReleaseRefnums(refnumList);
		String dbServletMappedXml = mapper.getDBServletMappedXml(orderReleaseRefnumSchemaWrapper);
		String postInsertQueryToDBServlet = restUtil.postInsertQueryToDBServlet("I", dbServletMappedXml);
		if (!StringUtils.isNumeric(postInsertQueryToDBServlet)) {
			logsRepo.save(new OtmLogs(null, dateUtil.getCurrentISTLocalDateTime(), otmShpConstants.getOrderReleaseAssignRefNumQualGid() +" Error creating OrderReleaseRefnum"+orderReleasesList+" req id : "+requestId, "ERROR"));
		}
		log.info("END createOrderReleaseRefnum");
	}
//		
//	public List<ShipmentApproval> postCancellationByShipmentId(List<ShipmentApproval> shipments, String status, String userId) {
//		if(!CollectionUtils.isEmpty(shipments)) {
//			
//
//			shipments.forEach(ship ->{
//				ShipmentCreationRequest shipment = repository.findByRequestNumber(ship.getAttribute11());
//
//			if (OTMConstants.APPROVED.equals(status)) {
//				dbServletRestUtil.postShipmentStatusToWMServlet(ship.getShipmentGID(),
//						"SC", dateUtil.getCurrentISTDate(OTMDateUtil.OJET_DATE_FORMAT));
//
//			} else {
//				try {
//				shipmentCreationFacade.createOrDeleteShipmentRefnum(new ArrayList<String>() {{add(ship.getShipmentGID());}},
//						otmShpConstants.getShipmentPendingGid(), otmShpConstants.getShipmentCancelPending(), "D");
//				} catch(Exception e) {
//					
//				}
//					repository.updateShipmentApprovalStatus(ship.getAttribute11(), status, dateUtil.getCurrentISTLocalDateTime());
//			}
//			if(Objects.nonNull(shipment)) {
//				String track = ship.getShipmentGID() + ":" + userId + ":" + status;
//				String approvalTracking = Objects.isNull(shipment.getApprovalTracking())? track : shipment.getApprovalTracking() +"," + track ;
//				repository.updateShipmentApprovalTracking(ship.getAttribute11(), approvalTracking, dateUtil.getCurrentISTLocalDateTime());
//			
//			}
//		});
//		
//		return shipments;
//		}
//		return null;
//	}
//	
//	
	public SchemaWrapper getShipmentAssignDetailsFromOtm(String requestId) {
		if (Objects.nonNull(requestId)) {
			String query = MessageFormat.format(shipmentAssignDetailsQuery, new Object[] { requestId });

			String dbString = dbServletRestUtil.postGetQueryToDBServlet("ORDER_RELEASE", query);
			return dbServletPojoMapper.getDBServletMappedPojo(dbString, ShipmentResponseSchemaWrapper.class);
		} else {
			return null;
		}
	}
}
