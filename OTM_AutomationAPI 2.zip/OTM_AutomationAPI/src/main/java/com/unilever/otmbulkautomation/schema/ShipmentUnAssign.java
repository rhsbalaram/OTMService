package com.unilever.otmbulkautomation.schema;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;

@Data
@JacksonXmlRootElement(localName = "SHIPMENT")
public class ShipmentUnAssign
{
	
	
	@JacksonXmlProperty(isAttribute = true, localName = "SHIPMENT_GID")
    private String shipmentGid;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_SHIP_UNIT_COUNT")
    private String totalShipUnitCount;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_DECLARED_VALUE")
    private String totalDeclaredValue;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT")
    private String totalWeight;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_WEIGHT_UOM_CODE")
    private String totalWeightUomCode;

	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME")
    private String totalVolume;
	
	@JacksonXmlProperty(isAttribute = true, localName = "TOTAL_VOLUME_UOM_CODE")
    private String totalVolumeUomCode;
	
	
	@JacksonXmlProperty(isAttribute = true, localName = "PLANNING_PARAMETER_SET_GID")
    private String planningParameterSetGid;
	
}